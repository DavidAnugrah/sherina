package com.rs.sherina.Model;

import java.util.ArrayList;
import java.util.List;

public class StoreCityResponse {

    private List<StoreCity> cities = new ArrayList<>();

    public List<StoreCity> getCities() {
        return cities;
    }

    public void setCities(List<StoreCity> cities) {
        this.cities = cities;
    }

    public void merge(StoreCityResponse response) {
        cities.addAll(response.getCities());
    }
}
