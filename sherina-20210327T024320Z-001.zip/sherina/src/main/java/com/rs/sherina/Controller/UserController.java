package com.rs.sherina.Controller;

import java.security.Principal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.rs.sherina.Entity.MstAlamatCustomer;
import com.rs.sherina.Entity.MstAlamatDelivery;
import com.rs.sherina.Entity.MstAlamatPickup;
import com.rs.sherina.Entity.MstCpCustomer;
import com.rs.sherina.Entity.MstCustomerB2b;
import com.rs.sherina.Entity.MstGroupDelivery;
import com.rs.sherina.Entity.MstRole;
import com.rs.sherina.Entity.MstUser;
import com.rs.sherina.Extension.annotation.Route;
import com.rs.sherina.Model.DeliveryMemberRequest;
import com.rs.sherina.Model.GroupDeliveryResponse;
import com.rs.sherina.Model.ListGroupDeliveryResponse;
import com.rs.sherina.Model.Password;
import com.rs.sherina.Model.Role;
import com.rs.sherina.Repository.MstAlamatCustomerRepository;
import com.rs.sherina.Repository.MstAlamatDeliveryRepository;
import com.rs.sherina.Repository.MstAlamatPickupRepository;
import com.rs.sherina.Repository.MstCpCustomerRepository;
import com.rs.sherina.Repository.MstCustomerB2bHistoryRepository;
import com.rs.sherina.Repository.MstCustomerB2bRepository;
import com.rs.sherina.Repository.MstGroupDeliveryRepository;
import com.rs.sherina.Repository.RoleRepository;
import com.rs.sherina.Repository.UserRepository;
import com.rs.sherina.Utils.MD5;

@RestController
@Secured({ Role.ROLE_USER })
public class UserController {

	private static final Logger logger = LoggerFactory.getLogger(UserController.class);

	@PersistenceContext
	private EntityManager em;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private RoleRepository roleRepository;

	@Autowired
	private MstCustomerB2bRepository mstCustomerB2bRepository;

	@Autowired
	private MstAlamatCustomerRepository mstAlamatCustomerRepository;

	@Autowired
	private MstAlamatPickupRepository mstAlamatPickupRepository;

	@Autowired
	private MstAlamatDeliveryRepository mstAlamatDeliveryRepository;

	@Autowired
	private MstGroupDeliveryRepository mstGroupDeliveryRepository;


    @Autowired
    private MstCustomerB2bHistoryRepository customerHistoryRepository;

    @PersistenceContext(type = PersistenceContextType.TRANSACTION)
    private EntityManager entityManager;

	@Autowired
	private MstCpCustomerRepository cpCustomerRepository;

	@GetMapping("/verify")
	@ResponseBody
	public String verifyAction(Principal principal) throws SQLException {
		MstUser checkUser = userRepository.findOneByUsername(principal.getName());
		String checkUser2 = mstCustomerB2bRepository.codeCustomer(checkUser.getUsername());
		ResultSet rs = null;
		Connection con = null;
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://masterdb.alfatrex.id:3306/frontend","atex123","atex5758");  
			Statement stmt=con.createStatement();  
			rs = stmt.executeQuery("select mcus_kode,mcus_sts_aktif from mst_customer where mcus_kode = '"+checkUser2+"'");  
			System.out.println(rs +"execute Query");
			if (rs.next()) {
				int status = rs.getInt(2);
				System.out.println(status +"statusstatus");
				if (status == 0) {
					con.close();
					return "{\"success\": false}";
				}
			}
		}catch(Exception e){ 
				System.out.println("isi dari error : "+e);
			}  
		con.close();
		return "{\"success\": true}";
	}

	@GetMapping("/identify")
	@ResponseBody
	public Map<String, String> identifyAction(Principal principal) {
		String name = userRepository.getNameByUsernameNative(principal.getName());
		Map<String, String> map = new HashMap<String, String>();
		map.put("name", name);
		return map;
	}

	@GetMapping("/address")
	@ResponseBody
	public List<MstAlamatCustomer> getAddressAction(Principal principal) {
		MstCustomerB2b customer = mstCustomerB2bRepository.findOneByUsername(principal.getName());

		return mstAlamatCustomerRepository.findByMstCustomerB2bOrderByIdDesc(customer);
	}

	@GetMapping("/address/{address}")
	@ResponseBody
	public MstAlamatCustomer getAddressAction(@PathVariable("address") MstAlamatCustomer address, Principal principal) {
		MstCustomerB2b customer = mstCustomerB2bRepository.findOneByUsername(principal.getName());
		if (null != address && customer.getId().equals(address.getMstCustomerB2b().getId())) {
			return address;
		}

		return null;
	}

	@Transactional
	@PostMapping("/address")
	@ResponseBody
	public MstAlamatCustomer addressAction(@RequestBody MstAlamatCustomer mstAlamatCustomer, Principal principal) {
		MstCustomerB2b customer = mstCustomerB2bRepository.findOneByUsername(principal.getName());
		mstAlamatCustomer.setMstCustomerB2b(customer);
		MstAlamatPickup pickup = mstAlamatCustomer.getMstAlamatPickup();
		if (null != pickup) {
			pickup.setMstCustomerB2b(customer);
		}
		mstAlamatCustomerRepository.save(mstAlamatCustomer);

		return mstAlamatCustomer;
	}

	@DeleteMapping("/address")
	@ResponseBody
	@Transactional
	public String deleteAddressAction(@RequestBody MstAlamatCustomer mstAlamatCustomer) {
		mstAlamatCustomerRepository.delete(mstAlamatCustomer);

		return "{}";
	}

	@GetMapping("/profile")
	@ResponseBody
	public MstCustomerB2b profileAction(Principal principal) {
		MstCustomerB2b userProfile = mstCustomerB2bRepository.findOneByUsername(principal.getName());
		return userProfile;
	}

	@PostMapping("/profile")
	@ResponseBody
	@Transactional
	public MstCustomerB2b saveProfile(@RequestBody MstCustomerB2b customer, Principal principal) {
		MstUser user = userRepository.findOneByUsername(principal.getName());
		if (null == customer.getUserCreator()) {
			customer.setUserCreator(user);
		}
		if (null == customer.getUserUpdater()) {
			customer.setUserUpdater(user);
		}
		try {
			for (MstCpCustomer temp : customer.getMstCpCustomers()) {
				MstCustomerB2b cust = new MstCustomerB2b();
				if (temp.getIsNew() == true && temp.getIsDeleted()==false) {
					cust.setId(temp.getMcpcEmail().toLowerCase());
					cust.setNpwp(customer.getNpwp());
					cust.setNpwpName(customer.getNpwpName());
					cust.setName(temp.getMcpcNama());
					cust.setEmail(temp.getMcpcEmail());
					cust.setAddress(customer.getAddress());
					cust.setFax(customer.getFax());
					cust.setUrl(customer.getUrl());
					cust.setPhone(customer.getPhone());
					cust.setType("PIC");
					cust.setUserCreator(user);
					mstCustomerB2bRepository.save(cust);

					Set<MstRole> roles = roleRepository.findByNameIn(new String[] { "ROLE_USER" });
					MstUser tempUser = new MstUser();
					tempUser.setUsername(temp.getMcpcEmail().toLowerCase());
					tempUser.setRoles(roles);
					tempUser.setPassword(MD5.encode(temp.getMcpcHp()));
					tempUser.setName(temp.getMcpcNama());
					tempUser.setRemark(customer.getEmail());
					tempUser.setMstCustomerB2b(cust);
					userRepository.save(tempUser);
					
					MstCpCustomer tempCpCustomer = new MstCpCustomer();
					tempCpCustomer.setIsDeleted(false);
					tempCpCustomer.setMcpcHp(temp.getMcpcHp());
					tempCpCustomer.setMcpcEmail(temp.getMcpcEmail());
					tempCpCustomer.setMcpcNama(temp.getMcpcNama());
					tempCpCustomer.setMstCustomerB2b(customer);
					cpCustomerRepository.save(tempCpCustomer);
					
				} else {
					MstUser oldPassword = userRepository.findOneByUsername(temp.getMcpcEmail());
					String compare = new MD5().encode(temp.getMcpcHp());
					if (!compare.equals(oldPassword.getPassword()) && temp.getIsUpdated()==true ) {
						userRepository.updateUser(compare, temp.getMcpcEmail());
					}else {
						//delete pic start
						if (temp.getDeleted()==true) {
							cpCustomerRepository.updatePICbyId(temp.getId().intValue());
//							cpCustomerRepository.deletePICbyId(temp.getId().intValue());
						}else 
						{
							continue;
						}
					}
				}
			}
			user.setName(customer.getName());
			user.setUsername(customer.getEmail());
			userRepository.save(user);
			mstCustomerB2bRepository.updateCustomer(customer.getPhone(), customer.getFax(), customer.getUrl(), customer.getEmail(), customer.getId());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return customer;
	}

	@GetMapping("/pickup")
	@ResponseBody
	public List<MstAlamatPickup> getPickupAction(Principal principal) {
		MstCustomerB2b customer = mstCustomerB2bRepository.findOneByUsername(principal.getName());

//        return mstAlamatPickupRepository.findAllByMstCustomerB2bOrderByIdDesc(customer);
		return mstAlamatPickupRepository.findByMstCustomerB2bAndIsTempOrderByIdDesc(customer, false);
	}

	@GetMapping("/pickup/{pickup}")
	@ResponseBody
	public MstAlamatPickup getPickupAction(@PathVariable("pickup") MstAlamatPickup pickup, Principal principal) {
		MstCustomerB2b customer = mstCustomerB2bRepository.findOneByUsername(principal.getName());

		if (null != pickup && customer.getId().equals(pickup.getMstCustomerB2b().getId())) {
			return pickup;
		}

		return null;
	}

	@PostMapping("/pickup")
	@ResponseBody
	@Transactional
	public MstAlamatPickup pickupAction(@RequestBody MstAlamatPickup pickup, Principal principal) {
		MstCustomerB2b customer = mstCustomerB2bRepository.findOneByUsername(principal.getName());
		pickup.setMstCustomerB2b(customer);
		mstAlamatPickupRepository.save(pickup);

		return pickup;
	}

	@DeleteMapping("/pickup")
	@ResponseBody
	@Transactional
	public String deletePickupAction(@RequestBody MstAlamatPickup pickup) {
		mstAlamatPickupRepository.delete(pickup);

		return "{}";
	}

	@GetMapping({ "/deliveries", "/delivery" })
	@ResponseBody
	public List<MstAlamatDelivery> deliveriesAction(HttpServletRequest request, Principal principal) {
		MstCustomerB2b customer = mstCustomerB2bRepository.findOneByUsername(principal.getName());
		String allowPickup = request.getParameter("allowPickup");
		List<MstAlamatDelivery> deliveries = new ArrayList<MstAlamatDelivery>();

		if (allowPickup != null) {
//            deliveries = mstAlamatDeliveryRepository.findByMstCustomerB2bAndMldeAllowPickupOrderByIdDesc(customer, allowPickup.equals("true"));
			deliveries = mstAlamatDeliveryRepository.findByMstCustomerB2bAndIsTempAndMldeAllowPickupOrderByIdDesc(
					customer, false, allowPickup.equals("true"));
		} else {
			try {
				deliveries = mstAlamatDeliveryRepository.findByMstCustomerB2bAndIsTempOrderByIdDesc(customer, false);
//                deliveries = new ArrayList<MstAlamatDelivery>(customer.getDeliveries());
				logger.info("Success: GET /deliveries");
			} catch (Exception e) {
				logger.error("Error: GET /deliveries", e);
			}
		}

		return deliveries;
	}

	@PostMapping("/delivery")
	@ResponseBody
	@Transactional
	public MstAlamatDelivery deliveryAction(@RequestBody(required = false) MstAlamatDelivery delivery,
			Principal principal) {
		MstCustomerB2b customer = mstCustomerB2bRepository.findOneByUsername(principal.getName());
		delivery.setMstCustomerB2b(customer);
		mstAlamatDeliveryRepository.save(delivery);
		return delivery;
	}

	@DeleteMapping("/delivery")
	@ResponseBody
	@Transactional
	public String deliveryAction(@RequestBody MstAlamatDelivery delivery) {
		mstAlamatDeliveryRepository.delete(delivery);

		return "{}";
	}

	@Route("/delivery-group")
	@ResponseBody
	public Set<GroupDeliveryResponse> deliveryGroups(
			@RequestParam(value = "allowPickup", required = false, defaultValue = "false") Boolean allowPickup,
			@RequestParam(value = "all", required = false, defaultValue = "false") Boolean ignorePickup,
			Principal principal) {
		MstCustomerB2b customer = mstCustomerB2bRepository.findOneByUsername(principal.getName());
		Set<MstGroupDelivery> mstGroupDeliveries;
		try {
			mstGroupDeliveries = customer.getMstGroupDeliveries();
			logger.info("Success: GET /delivery-group");
		} catch (Exception e) {
			mstGroupDeliveries = Collections.emptySet();
			logger.error("Error: GET /delivery-group", e);
		}

		return new ListGroupDeliveryResponse(mstGroupDeliveries, allowPickup, ignorePickup).getAllGroups();
	}

	@GetMapping("/delivery-group/{group}")
	@ResponseBody
	public MstGroupDelivery deliveryGroups(
			@RequestParam(value = "allowPickup", required = false, defaultValue = "false") Boolean allowPickup,
			@RequestParam(value = "ignorePickup", required = false, defaultValue = "false") Boolean ignorePickup,
			@PathVariable("group") MstGroupDelivery group) {
		if (null != group) {
			group.allowCountMembers = allowPickup;
		}

		return group;
	}

	@PostMapping("/delivery-group")
	@ResponseBody
	@Transactional
	public MstGroupDelivery deliveryGroupAction(@RequestBody(required = false) MstGroupDelivery group,
			Principal principal) {
		MstCustomerB2b customer = mstCustomerB2bRepository.findOneByUsername(principal.getName());
		try {
			group.setMstCustomerB2b(customer);
			mstGroupDeliveryRepository.save(group);
			logger.info("Success: DELETE /delivery-group");
		} catch (Exception e) {
			logger.error("Error: DELETE /delivery-group", e);
		}

		return mstGroupDeliveryRepository.findOneById(group.getId());
	}

	@DeleteMapping("/delivery-group")
	@ResponseBody
	public String removeDeliveryGroupAction(@RequestBody(required = false) MstGroupDelivery group) {
		MstGroupDelivery g = mstGroupDeliveryRepository.findOneById(group.getId());
		try {
			if (null != g.getDeliveries()) {
				for (MstAlamatDelivery mstAlamatDelivery : g.getDeliveries()) {
					MstAlamatDelivery del = mstAlamatDeliveryRepository.findOneById(mstAlamatDelivery.getId());
					del.setGroup(null);
					mstAlamatDeliveryRepository.save(del);
				}
			}
			mstGroupDeliveryRepository.deleteDeliveryGroupById(g.getId());
			logger.info("Success: DELETE /delivery-group");
		} catch (Exception e) {
			logger.error("Error: DELETE /delivery-group", e);
		}

		return "{\"success\": true}";
	}

	@Route("/delivery-group/{group}/delivery")
	@ResponseBody
	public List<MstAlamatDelivery> getDeliveryByGroupAction(@PathVariable("group") MstGroupDelivery group) {
		return mstAlamatDeliveryRepository.findByGroup(group);
	}

	@PostMapping("/delivery-group/{group}/delivery")
	@ResponseBody
	public String updateDeliveryChildAction(@PathVariable("group") MstGroupDelivery group,
			@RequestBody(required = false) DeliveryMemberRequest deliveries) {
		Long id = group.getId();
		try {
			if (null != deliveries) {
				group = mstGroupDeliveryRepository.findOneById(id);
				if (null != group && null != group.getDeliveries()) {
					for (MstAlamatDelivery d : group.getDeliveries()) {
						mstAlamatDeliveryRepository.removeGroupById(d.getId());
						logger.info(String.format("Removing %s from group", d.getMldeNamaPenerima()));
					}
				}
				for (Long d : deliveries.getIds()) {
					mstAlamatDeliveryRepository.applyToGroup(group, d);
				}
			}

			logger.info(String.format("Success: POST /delivery-group/%s/delivery", id));
		} catch (Exception e) {
			logger.error(String.format("Error: POST /delivery-group/%s/delivery", id), e);
		}

		return "{\"success\": true}";
	}

	@PostMapping("/profile/password")
	@ResponseBody
	public String updatePasswordAction(@RequestBody Password password, Principal principal) {
		MstUser user = userRepository.findOneByUsername(principal.getName());
		String response = "{\"success\": false}";
		if (null != password.getOldPassword() && user.getPassword().equals(MD5.encode(password.getOldPassword()))) {
			user.setPassword(MD5.encode(password.getNewPassword()));
			userRepository.save(user);
			response = "{\"success\": true}";
		}

		return response;
	}
}
