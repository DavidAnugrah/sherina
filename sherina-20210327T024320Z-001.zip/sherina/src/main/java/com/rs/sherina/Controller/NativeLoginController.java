package com.rs.sherina.Controller;

import com.rs.sherina.Repository.UserRepository;
import com.rs.sherina.Utils.MD5;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@Controller
public class NativeLoginController {
    @Autowired
    private UserRepository userRepository;

    @PostMapping("/oauth/native-login")
    @ResponseBody
    public String checkAction(@RequestBody Map<String, String> map, HttpServletRequest request) {
        String response = "{\"success\": false}";

        if (map.containsKey("username") && map.containsKey("password")) {
            String username = map.get("username");
            String password = map.get("password");
            if (!StringUtils.isEmpty(username) && !StringUtils.isEmpty(password)) {
                Long total = userRepository.findTotalByUsernameAndPassword(username, MD5.encode(password));
                if (total != null && total == 1L) {
                    response = "{\"success\": true}";
                }
            }
        }

        return response;
    }
}
