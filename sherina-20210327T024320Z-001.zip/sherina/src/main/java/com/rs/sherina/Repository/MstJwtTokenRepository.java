package com.rs.sherina.Repository;

import com.rs.sherina.Entity.MstJwtToken;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.security.oauth2.provider.ClientDetails;
import org.springframework.security.oauth2.provider.ClientDetailsService;
import org.springframework.security.oauth2.provider.ClientRegistrationException;

public interface MstJwtTokenRepository extends PagingAndSortingRepository<MstJwtToken, Long>, ClientDetailsService {
    @Override
    @Query("SELECT c FROM MstJwtToken c WHERE c.clientId = ?1")
    ClientDetails loadClientByClientId(String s) throws ClientRegistrationException;
}
