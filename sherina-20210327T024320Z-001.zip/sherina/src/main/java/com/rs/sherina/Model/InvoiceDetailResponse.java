package com.rs.sherina.Model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

public class InvoiceDetailResponse {
    private List<InvoiceDetail> details = new ArrayList<>();

    @JsonProperty("details")
    public List<InvoiceDetail> getDetails() {
        return details;
    }

    @JsonProperty("detail")
    public void setDetails(List<InvoiceDetail> details) {
        this.details = details;
    }
}
