package com.rs.sherina.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rs.sherina.Entity.MstAlamatCustomer;
import com.rs.sherina.Entity.MstAlamatDelivery;
import com.rs.sherina.Entity.MstAlamatPickup;
import com.rs.sherina.Entity.MstCustomerB2b;
import com.rs.sherina.Entity.MstUser;
import com.rs.sherina.Entity.TrsShipment;
import com.rs.sherina.Model.ShipmentResponse;
import com.rs.sherina.Model.StatusResponse;
import com.rs.sherina.Repository.MstAlamatCustomerRepository;
import com.rs.sherina.Repository.MstAlamatDeliveryRepository;
import com.rs.sherina.Repository.MstAlamatPickupRepository;
import com.rs.sherina.Repository.MstCustomerB2bRepository;
import com.rs.sherina.Repository.UserRepository;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@SuppressWarnings("SpellCheckingInspection")
@Service
public class ShipmentBooking {
    @Autowired
    private MstAlamatCustomerRepository customerRepository;

    @Autowired
    private MstAlamatPickupRepository pickupRepository;

    @Autowired
    private MstAlamatDeliveryRepository deliveryRepository;

    @Autowired
    public static final Logger logger = Logger.getLogger(ShipmentBooking.class);
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private MstCustomerB2bRepository mstCustomerB2bRepository;
    
    @Value("${sherina.api.service:}")
    private String serviceUrl;

    @Value("${spring.profiles.active:production}")
    private String profile;

    public ShipmentResponse send(HttpServletRequest request, TrsShipment shipment) {
        return send(request, shipment, false);
    }

    public ShipmentResponse send(HttpServletRequest request, TrsShipment shipment, boolean autoSave) {
        ShipmentResponse response;

        try {
            RestTemplate rest = new RestTemplate();
            MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
            List<MediaType> mediaTypes = new ArrayList<>();
            mediaTypes.add(MediaType.APPLICATION_JSON_UTF8);
            mediaTypes.add(MediaType.APPLICATION_JSON);
            mediaTypes.add(MediaType.TEXT_HTML);
            mediaTypes.add(MediaType.TEXT_PLAIN);
            mediaTypes.add(MediaType.ALL);
            
            converter.setSupportedMediaTypes(mediaTypes);
            rest.getMessageConverters().add(converter);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

            MultiValueMap<String, String> payload = new LinkedMultiValueMap<>();
            String custCode = new String();
            if (shipment.getMstCustomerB2b().getType() != null && shipment.getMstCustomerB2b().getType().equals("PIC")) {
            	MstUser tempUser = userRepository.findOneByUsername(shipment.getMstCustomerB2b().getEmail());
           		MstCustomerB2b customer = mstCustomerB2bRepository.findOneByUsername(tempUser.getRemark());
                custCode = customer.getId();
			}else {
				custCode = shipment.getMstCustomerB2b().getId();
			}
            
            String sipNama = shipment.getTshNamaPengirim();
            String sipAlamat = shipment.getTshAlamatPengirim();
            String sipKodePos = shipment.getTshKodePosPengirim();
            String sipTelpon = shipment.getTshTelponPengirim();
            String sipHandphone = shipment.getTshTelponPengirim();

            MstAlamatCustomer address = shipment.getAddress();
            MstAlamatPickup pickup = shipment.getPickup();
            MstAlamatDelivery delivery = shipment.getDelivery();
            String kodeStore = "";

            if (address != null) {
                if (address.getId() != null) {
                    MstAlamatCustomer address2 = customerRepository.findOneById(address.getId());
                    if (null != address2) {
                        shipment.setAddress(address2);
                        address = address2;
                    }
                }
                sipNama = address.getMlcuNamaPengirim();
                sipKodePos = address.getMlcuKodePos();
                sipAlamat = address.getMlcuAlamat();
                sipTelpon = address.getMlcuTelpon();
                sipHandphone = address.getMlcuTelpon();

                if (null == shipment.getTshMkcmKodePengirim()) {
                    shipment.setTshMkcmKodePengirim(address.getMlcuMkcmKode());
                }

                System.out.println(String.format("Using address %s", address.getId()));
            } else if (pickup != null) {
                if (pickup.getId() != null) {
                    MstAlamatPickup pickup2 = pickupRepository.findOneById(pickup.getId());
                    if (null != pickup2) {
                        shipment.setPickup(pickup2);
                        pickup = pickup2;
                    }
                }
                sipNama = pickup.getMlpiNamaPengirim();
                sipKodePos = pickup.getMlpiKodePos();
                sipAlamat = pickup.getMlpiAlamat();
                sipTelpon = pickup.getMlpiTelpon();
                sipHandphone = pickup.getMlpiTelpon();

                if (null == shipment.getTshMkcmKodePengirim()) {
                    shipment.setTshMkcmKodePengirim(pickup.getMlpiMkcmKode());
                }

                System.out.println(String.format("Using pickup %s", pickup.getId()));
            }

            if (StringUtils.isEmpty(sipKodePos)) {
            	sipKodePos = "00000";
            }

            if (null != delivery) {
                if (null != delivery.getId()) {
                    MstAlamatDelivery delivery1 = deliveryRepository.findOneById(delivery.getId());
                    shipment.setDelivery(delivery1);
                    delivery = delivery1;
                }

                if (StringUtils.isEmpty(shipment.getTshAlamatPenerima())) {
                    shipment.setTshAlamatPenerima(delivery.getMldeAlamatStore());
                    if (StringUtils.isEmpty(shipment.getTshAlamatPenerima())) {
                        shipment.setTshAlamatPenerima(delivery.getMldeAlamat());
                    }
                }

                if (!StringUtils.isEmpty(delivery.getMldeKodeStore())) {
                    kodeStore = delivery.getMldeKodeStore();
                }
            } else if (!StringUtils.isEmpty(shipment.getTshKodeStore())) {
                kodeStore = shipment.getTshKodeStore();
            }


//            String awb = shipment.getTshTransNo();
//            String sipNo = shipment.getTshTransNo();
//            if (!StringUtils.isEmpty(shipment.getTshAwb())) {
//                awb = shipment.getTshAwb();
//            }

            /*if (!StringUtils.isEmpty(shipment.getTshPk())) {
                sipNo = shipment.getTshPk();
            }*/

            if (autoSave) {
                payload.add("tipe", shipment.getTshOrgType().equals("store") ? "a" : "o");
                payload.add("service_code", shipment.getTshMproKode());
                if (!StringUtils.isEmpty(shipment.getTshAwb())) {
                    payload.add("waybill", shipment.getTshAwb());
                }
                if (!StringUtils.isEmpty(shipment.getTshPk())) {
                    payload.add("sip_no", shipment.getTshPk());
                }
            } else {
                payload.add("tipe", "q");
                payload.add("box", "0");
                String orgType = shipment.getTshOrgType().substring(0, 1).toUpperCase();
                String dstType = shipment.getTshDestType().substring(0, 1).toUpperCase();
                String sCode = shipment.getTshMproKode() + orgType + dstType;
                payload.add("service_code", sCode);
            }
            
            payload.add("tipe_drop", shipment.getTshDestType().equals("store") ? "store" : "home");
            payload.add("sms_pincode", shipment.getTshDestType().equals("store") ? "1" : "0");
            payload.add("response", "json");
            payload.add("prefix", "1");
            payload.add("packing", "0");
            payload.add("order_no", shipment.getTshTransNo());
            payload.add("insurance", shipment.getTshNilaiBarang() > 0 ? "1" : "0");
            payload.add("berat", shipment.getTshBeratAktual().toString());
            payload.add("panjang", shipment.getTshPanjang().toString());
            payload.add("lebar", shipment.getTshLebar().toString());
            payload.add("tinggi", shipment.getTshTinggi().toString());
            payload.add("nilai_paket", shipment.getTshNilaiBarang().toString());
            payload.add("sip_kode_kecamatan", shipment.getTshMkcmKodePengirim());
            payload.add("sip_nama", sipNama);
            payload.add("sip_alamat", sipAlamat);
            payload.add("sip_kode_pos", sipKodePos);
            payload.add("sip_telpon", sipTelpon);
            payload.add("sip_handphone", sipHandphone);
            payload.add("sip_kode", custCode);
            payload.add("sip_billing", custCode);
            payload.add("cod", (shipment.getTshCod().intValue()) + "");
            payload.add("sip_email", "");

            payload.add("pen", shipment.getTshNamaPenerima());
            payload.add("pen_alamat", shipment.getTshAlamatPenerima());
            payload.add("pen_handphone", shipment.getTshTelponPenerima());
            payload.add("pen_kode_kecamatan", shipment.getTshMkcmKodePenerima());
            payload.add("pen_kode_store", kodeStore);
            payload.add("pen_kode_pos", shipment.getTshKodePosPenerima());

            payload.add("isi_paket", shipment.getTshIsiPaket());
            payload.add("tipe_bayar", "0");

            if (profile.equalsIgnoreCase("local")) {
                String stringPayload = json_encode(payload);
                StringBuilder log = new StringBuilder();
                log.append(String.format("Sending Transaction Payload: \n%s\n", stringPayload));
                log.append(String.format("SENDING SHIPMENT DATA TO URL: %s\n", serviceUrl));
                log.append("=====================================\n");
                log.append("With params:\n");
                Iterator<String> it = payload.keySet().iterator();
                while (it.hasNext()) {
                    String k = it.next();
                    String v = payload.getFirst(k);
                    log.append(String.format("%s:%s\n", k, v));
                }
                log.append("Copy these parameters to Postman bulk edit to test\n");
                log.append("=====================================\n");
                System.out.println(log.toString() + "\n");
            }

            HttpEntity<MultiValueMap<String, String>> req = new HttpEntity<>(payload, headers);
            response = rest.postForObject(serviceUrl, req, ShipmentResponse.class);
            if (response.getResponseCode() > 0) {
                logger.info(String.format("Failed to fetch booking info. Server message: %s", response.getResponseMessage()));
            } else {
                logger.info(String.format("Success get booking with awb: %s and booking code: %s",
                        response.getWbCode(), response.getBookingCode()));
            }
        } catch (Exception e) {
            logger.error("Failed to post request. Server message: " + e.getMessage());
            response = new ShipmentResponse();
            response.setResponseCode(2);
        }

        return response;
    }

    private String json_encode(Object object) {
        ObjectMapper mapper = new ObjectMapper();
        String json = "{}";

        try {
            json = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(object);
        } catch (Exception e) {
            // ..
        }

        return json;
    }

    public StatusResponse fetch(TrsShipment shipment) {
        StatusResponse response;

        try {
            RestTemplate rest = getTemplate();

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

            MultiValueMap<String, String> payload = new LinkedMultiValueMap<>();
            HttpEntity<MultiValueMap<String, String>> req = new HttpEntity<>(payload, headers);

            payload.add("tipe", "c");
            payload.add("response", "json");
            payload.add("waybill", shipment.getTshAwb());

            response = rest.postForObject(serviceUrl, req, StatusResponse.class);
            if (response.getResponseCode() > 0) {
                logger.info(String.format("Failed to fetch booking status. Server message: %s", response.getResponseMessage()));
            } else {
                logger.info(String.format("Success get booking status: %s", response.getStatus()));
            }
        } catch (Exception e) {
            logger.error("Failed to fetch response. Server message: " + e.getMessage());
            response = new StatusResponse();
            response.setResponseCode(2);
        }

        return response;
    }

    public TrsShipment wrap(TrsShipment shipment) {
        StatusResponse response = this.fetch(shipment);
        if (response.getResponseCode() == 0) {
            shipment.setTshStatus(response.getStatus());
        } else {
            shipment.setTshStatus("PIO");
        }

        return shipment;
    }

    public static RestTemplate getTemplate() {
        RestTemplate rest = new RestTemplate();
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        List<MediaType> mediaTypes = new ArrayList<>();

        mediaTypes.add(MediaType.APPLICATION_JSON_UTF8);
        mediaTypes.add(MediaType.APPLICATION_JSON);
        mediaTypes.add(MediaType.TEXT_HTML);
        mediaTypes.add(MediaType.TEXT_PLAIN);

        converter.setSupportedMediaTypes(mediaTypes);
        rest.getMessageConverters().add(converter);

        return rest;
    }

    public static HttpEntity<MultiValueMap<String, String>> getHttpHeaders(MultiValueMap<String, String> payloads) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", "application/json");

        return new HttpEntity<>(payloads, headers);
    }
}
