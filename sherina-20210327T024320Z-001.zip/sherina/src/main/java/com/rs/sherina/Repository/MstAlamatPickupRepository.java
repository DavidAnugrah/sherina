package com.rs.sherina.Repository;

import com.rs.sherina.Entity.MstAlamatPickup;
import com.rs.sherina.Entity.MstCustomerB2b;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import javax.transaction.Transactional;
import java.util.List;

public interface MstAlamatPickupRepository extends PagingAndSortingRepository<MstAlamatPickup, Long> {
    MstAlamatPickup findOneById(Long id);

    MstAlamatPickup findOneByMstAlamatCustomer(Long id);

    List<MstAlamatPickup> findAllByMstCustomerB2bOrderByIdDesc(MstCustomerB2b customer);

    List<MstAlamatPickup> findByMstCustomerB2bAndIsTempOrderByIdDesc(MstCustomerB2b customer, Boolean temp);

    @Modifying
    @Transactional
    @Query("UPDATE MstAlamatPickup c SET c.isTemp = false WHERE c.isTemp IS NULL")
    void fixingTemporary();
}
