package com.rs.sherina.Service;

import com.rs.sherina.Entity.MstCustomerB2b;
import com.rs.sherina.Entity.MstUser;
import com.rs.sherina.Entity.TrsShipment;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

public class ShipmentUserSpecs implements Specification<TrsShipment> {
    MstCustomerB2b customer;

    public ShipmentUserSpecs(MstUser user) {
        customer = user.getMstCustomerB2b();
    }

    public ShipmentUserSpecs(MstCustomerB2b customer) {
        this.customer = customer;
    }

    @Override
    public Predicate toPredicate(Root<TrsShipment> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
        Predicate predicate1 = criteriaBuilder.equal(root.get("tshTemp"), false);
        if (null == customer) {
            return predicate1;
        }
        Predicate predicate2 = criteriaBuilder.equal(root.get("mstCustomerB2b"), customer);

        return criteriaBuilder.and(predicate1, predicate2);
    }
}
