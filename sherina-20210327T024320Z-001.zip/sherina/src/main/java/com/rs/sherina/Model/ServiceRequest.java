package com.rs.sherina.Model;

public class ServiceRequest {
    public String tipe;

    public String tipe_pickup;

    public String tipe_drop;

    public String sip_kode;

    public String sip_kode_kecamatan;

    public String pen_kode_kecamatan;

    public Long berat;

    public Long panjang;

    public Long lebar;

    public Long tinggi;

    public Long nilai_paket;

    public Long insurance;

    public Long packing;

}
