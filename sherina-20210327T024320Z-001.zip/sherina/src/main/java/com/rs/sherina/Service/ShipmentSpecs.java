package com.rs.sherina.Service;

import com.rs.sherina.Entity.TrsShipment;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

public class ShipmentSpecs implements Specification<TrsShipment> {
    private String awbOrPk;
    private String fieldName;

    public ShipmentSpecs(String awbOrPk, String fieldName) {
        this.awbOrPk = awbOrPk;
        this.fieldName = fieldName;
    }

    @Override
    public Predicate toPredicate(Root<TrsShipment> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
        Predicate predicate = null;
        if (!StringUtils.isEmpty(awbOrPk)) {
            predicate = criteriaBuilder.like(root.get(fieldName), "%" + awbOrPk + "%");
        }

        return predicate;
    }
}
