package com.rs.sherina.Model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.rs.sherina.Utils.DateTime;
import org.springframework.util.StringUtils;

import java.util.Date;

public class DeliveryStatus {

    private String bookingCode;

    private String waybill;

    private String status;

    private String remark;

    private String date;

    private String time;

    private String cityCode;

    private String city;

    private Boolean passed = false;

    @JsonProperty("bookingCode")
    public String getBookingCode() {
        return bookingCode;
    }

    @JsonProperty("booking_code")
    public void setBookingCode(String bookingCode) {
        this.bookingCode = bookingCode;
    }

    public String getWaybill() {
        return waybill;
    }

    public void setWaybill(String waybill) {
        this.waybill = waybill;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.passed = !StringUtils.isEmpty(time);
        this.time = time;
    }

    @JsonProperty("cityCode")
    public String getCityCode() {
        return cityCode;
    }

    @JsonProperty("city_code")
    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public Boolean getPassed() {
        return passed;
    }

    public void setPassed(Boolean passed) {
        this.passed = passed;
    }

    public Date getDateTime() {
        if (time == null || date == null) {
            return null;
        }

        return DateTime.parse(date + " " + time);
    }
}
