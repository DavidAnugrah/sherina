package com.rs.sherina.Entity;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "mst_customer_b2b")
@SuppressWarnings("SpellCheckingInspection")
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
public class MstCustomerB2b {
    @Id
    @Column(name = "mcus_code", length = 20)
    private String id;

    @OneToMany(mappedBy = "mstCustomerB2b", fetch = FetchType.LAZY, cascade = {CascadeType.ALL})
    @OrderBy("id asc")
    @JsonProperty("contacts")
    private Set<MstCpCustomer> mstCpCustomers;

    @JsonIgnore
    @OneToMany(mappedBy = "mstCustomerB2b", fetch = FetchType.LAZY, cascade = {CascadeType.ALL})
    private Set<MstAlamatCustomer> mstAlamatCustomers = new HashSet<>();

    @JsonIgnore
    @OneToMany(mappedBy = "mstCustomerB2b", fetch = FetchType.LAZY, cascade = {CascadeType.ALL})
    private Set<MstAlamatPickup> mstAlamatPickups = new HashSet<>();

    @JsonIgnore
    @OneToMany(mappedBy = "mstCustomerB2b", fetch = FetchType.LAZY, cascade = {CascadeType.ALL})
    private Set<MstAlamatDelivery> deliveries = new HashSet<>();

    @JsonIgnore
    @OneToMany(mappedBy = "mstCustomerB2b", fetch = FetchType.LAZY, cascade = {CascadeType.ALL})
    private Set<TrsShipment> trsShipments = new HashSet<>();

    @JsonIgnore
    @OneToMany(mappedBy = "mstCustomerB2b", fetch = FetchType.LAZY, cascade = {CascadeType.ALL})
    private Set<MstGroupDelivery> mstGroupDeliveries = new HashSet<>();

    @JsonIgnore
    @OneToOne(mappedBy = "mstCustomerB2b", fetch = FetchType.LAZY, cascade = {CascadeType.REMOVE})
    private MstUser user;

    @Column(name = "mcus_name", length = 100)
    private String name;

    @Column(name = "mcus_telp", length = 20)
    private String phone;

    @Column(name = "mcus_fax", length = 20)
    private String fax;

    @Column(name = "mcus_web", length = 50)
    private String url;

    @Column(name = "mcus_email", length = 45)
    private String email;

    @Column(name = "mcus_npwp", length = 30)
    private String npwp;

    @Column(name = "mcus_nama_npwp", length = 100)
    private String npwpName;

    @Column(name = "mcus_address", length = 300)
    private String address;

    @Column(name = "mcus_ponta_id", length = 20)
    private String ponta;

    @Column(name = "mcus_ponta_password", length = 100)
    private String pontaPassword;

    @Column(name = "mcus_ponta_point")
    private Long pontaPoint;

    @Column(name = "mcus_type", length = 12)
    private String type;

    @Column(name = "mcus_temporary")
    private Boolean isTemp = false;

    @JsonIgnore
    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "mcus_create_date")
    private Date created;

    @JsonIgnore
    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "mcus_update_date")
    private Date updated;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "mcus_create_user")
    @JsonIgnore
    private MstUser userCreator;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "mcus_update_user")
    @JsonIgnore
    private MstUser userUpdater;

    public MstCustomerB2b() {}

    public MstCustomerB2b(MstUser creator) {
        this.userCreator = creator;
        this.userUpdater = creator;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Set<MstCpCustomer> getMstCpCustomers() {
    	Set<MstCpCustomer> result = new HashSet<>();
    	if (null != mstCpCustomers) {
        	for (MstCpCustomer temp : mstCpCustomers) {
    			if (temp.getIsDeleted()==false) {
    				result.add(temp);
    			}
    		}
		}
        return result;
    }

    public void setMstCpCustomers(Set<MstCpCustomer> mstCpCustomers) {
        for (MstCpCustomer c : mstCpCustomers) {
        	c.setMstCustomerB2b(this);	
        }
        this.mstCpCustomers = mstCpCustomers;
    }

    public Set<MstAlamatCustomer> getMstAlamatCustomers() {
        return mstAlamatCustomers;
    }

    public void setMstAlamatCustomers(Set<MstAlamatCustomer> mstAlamatCustomers) {
        this.mstAlamatCustomers = mstAlamatCustomers;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void addAddress(MstAlamatCustomer mstAlamatCustomer) {
        mstAlamatCustomer.setMstCustomerB2b(this);
        mstAlamatCustomers.add(mstAlamatCustomer);
    }

    public Set<MstAlamatPickup> getMstAlamatPickups() {
        return mstAlamatPickups;
    }

    public void setMstAlamatPickups(Set<MstAlamatPickup> mstAlamatPickups) {
        for (MstAlamatPickup mstAlamatPickup : mstAlamatPickups) {
            mstAlamatPickup.setMstCustomerB2b(this);
        }
        this.mstAlamatPickups = mstAlamatPickups;
    }

    public Set<MstAlamatDelivery> getDeliveries() {
        return deliveries;
    }

    public void setDeliveries(Set<MstAlamatDelivery> deliveries) {
        for (MstAlamatDelivery mstAlamatDelivery : deliveries) {
            mstAlamatDelivery.setMstCustomerB2b(this);
        }
        this.deliveries = deliveries;
    }

    public Set<TrsShipment> getTrsShipments() {
        return trsShipments;
    }

    public void setTrsShipments(Set<TrsShipment> trsShipments) {
        for (TrsShipment trsShipment : trsShipments) {
            trsShipment.setMstCustomerB2b(this);
        }
        this.trsShipments = trsShipments;
    }

    public Set<MstGroupDelivery> getMstGroupDeliveries() {
        return mstGroupDeliveries;
    }

    public void setMstGroupDeliveries(Set<MstGroupDelivery> mstGroupDeliveries) {
        this.mstGroupDeliveries = mstGroupDeliveries;
    }

    public MstUser getUser() {
        return user;
    }

    public void setUser(MstUser user) {
        this.user = user;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNpwp() {
        return npwp;
    }

    public void setNpwp(String npwp) {
        this.npwp = npwp;
    }

    public String getNpwpName() {
        return npwpName;
    }

    public void setNpwpName(String npwpName) {
        this.npwpName = npwpName;
    }

    public String getPonta() {
        return ponta;
    }

    public void setPonta(String ponta) {
        this.ponta = ponta;
    }

    public String getPontaPassword() {
        return pontaPassword;
    }

    public void setPontaPassword(String pontaPassword) {
        this.pontaPassword = pontaPassword;
    }

    public Long getPontaPoint() {
        return pontaPoint;
    }

    public void setPontaPoint(Long pontaPoint) {
        this.pontaPoint = pontaPoint;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @PrePersist
    @PreUpdate
    private void upSave() {
        if (null == this.userCreator) {
            this.userCreator = this.user;
            this.userUpdater = this.user;
        }
    }

    public MstUser getUserCreator() {
        return userCreator;
    }

    public void setUserCreator(MstUser userCreator) {
        this.userCreator = userCreator;
    }

    public MstUser getUserUpdater() {
        return userUpdater;
    }

    public void setUserUpdater(MstUser userUpdater) {
        this.userUpdater = userUpdater;
    }
}
