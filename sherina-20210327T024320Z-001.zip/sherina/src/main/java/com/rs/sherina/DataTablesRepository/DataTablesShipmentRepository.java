package com.rs.sherina.DataTablesRepository;

import com.rs.sherina.Entity.TrsShipment;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.data.jpa.datatables.repository.DataTablesRepository;
import org.springframework.data.jpa.repository.Query;

public interface DataTablesShipmentRepository extends DataTablesRepository<TrsShipment, Long> {
    DataTablesOutput<TrsShipment> findAll(DataTablesInput input);
}
