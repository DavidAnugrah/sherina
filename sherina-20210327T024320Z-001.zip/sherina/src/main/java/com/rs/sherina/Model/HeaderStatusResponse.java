package com.rs.sherina.Model;

import com.fasterxml.jackson.annotation.JsonProperty;

@SuppressWarnings("SpellCheckingInspection")
public class HeaderStatusResponse {
    private Long code;

    private String message;

    private Long pending;

    private Long otw;

    private Long failed;

    private Long unpaid;

    @JsonProperty("code")
    public Long getCode() {
        return code;
    }

    @JsonProperty("response_code")
    public void setCode(Long code) {
        this.code = code;
    }

    @JsonProperty("message")
    public String getMessage() {
        return message;
    }

    @JsonProperty("response_message")
    public void setMessage(String message) {
        this.message = message;
    }

    @JsonProperty("pending")
    public Long getPending() {
        return pending;
    }

    @JsonProperty("belum_diambil")
    public void setPending(Long pending) {
        this.pending = pending;
    }

    @JsonProperty("otw")
    public Long getOtw() {
        return otw;
    }

    @JsonProperty("dalam_pengiriman")
    public void setOtw(Long otw) {
        this.otw = otw;
    }

    @JsonProperty("failed")
    public Long getFailed() {
        return failed;
    }

    @JsonProperty("gagal")
    public void setFailed(Long failed) {
        this.failed = failed;
    }

    @JsonProperty("unpaid")
    public Long getUnpaid() {
        return unpaid;
    }

    @JsonProperty("belum_dibayar")
    public void setUnpaid(Long unpaid) {
        this.unpaid = unpaid;
    }
}
