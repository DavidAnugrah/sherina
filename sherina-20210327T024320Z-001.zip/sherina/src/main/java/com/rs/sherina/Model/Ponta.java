package com.rs.sherina.Model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.rs.sherina.Utils.DateTime;

import java.util.Date;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Ponta {

    private String mode;

    private String id;

    private String issuer;

    private String name;

    private String message;

    private Integer code;

    private Integer status;

    private String card;

    private String username;

    private String password;

    private String token;

    private Ponta data;

    private String errorCode;

    private String errorMessage;

    private Long memberId;

    private Long totalPoolUnits;

    private Long redeemablePoolUnits;

    private Long eebPoolUnits;

    private Date eebDate;

    private Date birthDate;

    private String email;

    private String phoneNumber;

    private String accountCard;

    private String BirthdayGreeting;

    private String gender;

    private String address1;

    private String city;

    private String zipCode;

    private String checksum;

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIssuer() {
        return issuer;
    }

    public void setIssuer(String issuer) {
        this.issuer = issuer;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("Name")
    public void setMemberName(String name) {
        this.name = name;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Ponta getData() {
        return data;
    }

    public void setData(Ponta data) {
        this.data = data;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    @JsonProperty("errorMessage")
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    public String getErrorMessage() {
        return errorMessage;
    }

    @JsonProperty("ErrorMessage")
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    @JsonProperty("memberId")
    public Long getMemberId() {
        return memberId;
    }

    @JsonProperty("MemberId")
    public void setMemberId(Long memberId) {
        this.memberId = memberId;
    }

    @JsonProperty("totalPoolUnits")
    public Long getTotalPoolUnits() {
        return totalPoolUnits;
    }

    @JsonProperty("TotalPoolUnits")
    public void setTotalPoolUnits(Long totalPoolUnits) {
        this.totalPoolUnits = totalPoolUnits;
    }

    @JsonProperty("redeemablePoolUnits")
    public Long getRedeemablePoolUnits() {
        return redeemablePoolUnits;
    }

    @JsonProperty("RedeemablePoolUnits")
    public void setRedeemablePoolUnits(Long redeemablePoolUnits) {
        this.redeemablePoolUnits = redeemablePoolUnits;
    }

    @JsonProperty("eebPoolUnits")
    public Long getEebPoolUnits() {
        return eebPoolUnits;
    }

    @JsonProperty("EEBPoolUnits")
    public void setEebPoolUnits(Long eebPoolUnits) {
        this.eebPoolUnits = eebPoolUnits;
    }

    @JsonProperty("eebDate")
    public Date getEebDate() {
        return eebDate;
    }

    @JsonProperty("EEBDate")
    public void setEebDate(String eebDate) {
        if (null != eebDate && eebDate.length() >= 8) {
            String year = eebDate.substring(0, 4);
            String month = eebDate.substring(4, 6);
            String day = eebDate.substring(6, 8);
            this.eebDate = DateTime.parse(String.format("%s-%s-%s 00:00:00", year, month, day));
        }
    }

    public String getEebDateFormatted() {
        return DateTime.format(eebDate);
    }

    @JsonProperty("birthDate")
    public Date getBirthDate() {
        return birthDate;
    }

    @JsonProperty("birth_date")
    public void setBirthDate(String birthDate) {
        if (null != birthDate && birthDate.length() >= 8) {
            String year = birthDate.substring(0, 4);
            String month = birthDate.substring(4, 6);
            String day = birthDate.substring(6, 8);
            this.birthDate = DateTime.parse(String.format("%s-%s-%s 00:00:00", year, month, day));
        }
    }

    public String getBirthDateFormatted() {
        return DateTime.format(birthDate);
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @JsonProperty("phoneNumber")
    public String getPhoneNumber() {
        return phoneNumber;
    }

    @JsonProperty("phone_number")
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @JsonProperty("AccountCard")
    public void setAccountCard(String accountCard) {
        this.id = accountCard;
    }

    @JsonProperty("birthdayGreeting")
    public String getBirthdayGreeting() {
        return BirthdayGreeting;
    }

    @JsonProperty("BirthdayGreeting")
    public void setBirthdayGreeting(String birthdayGreeting) {
        BirthdayGreeting = birthdayGreeting;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    @JsonProperty("zipCode")
    public String getZipCode() {
        return zipCode;
    }

    @JsonProperty("zip_code")
    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getCard() {
        return card;
    }

    public void setCard(String card) {
        this.card = card;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getChecksum() {
        return checksum;
    }

    public void setChecksum(String checksum) {
        this.checksum = checksum;
    }
}
