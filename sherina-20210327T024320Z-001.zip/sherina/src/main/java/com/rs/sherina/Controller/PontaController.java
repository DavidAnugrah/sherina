package com.rs.sherina.Controller;

import com.rs.sherina.Entity.MstUser;
import com.rs.sherina.Entity.MstCustomerB2b;
import com.rs.sherina.Repository.MstCustomerB2bRepository;
import com.rs.sherina.Model.Ponta;
import com.rs.sherina.Model.Role;
import com.rs.sherina.Repository.UserRepository;
import com.rs.sherina.Service.PontaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.security.Principal;
import java.util.Map;

@RestController
@RequestMapping("/ponta")
public class PontaController {
    @Autowired
    private PontaService pontaService;

    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private MstCustomerB2bRepository customerRepository;

    @PostMapping("/connect")
    @Secured(Role.ROLE_USER)
    @ResponseBody
    public Ponta connectAction(@RequestBody Map<String, String> params, Principal principal) {
        Ponta ponta = new Ponta();
        MstCustomerB2b customer = customerRepository.findOneByUsername(principal.getName());

        if (null != params
                && !StringUtils.isEmpty(params.get("member_id"))
                && !StringUtils.isEmpty(params.get("password"))) {
            if (!StringUtils.isEmpty(customer.getPonta())) {
                ponta.setMessage("success");
                ponta.setCode(200);
                ponta.setId(customer.getPonta());
                ponta.setData(pointAction(customer.getPonta()));
            } else {
                Ponta request = new Ponta();
                request.setCard(params.get("member_id"));
                request.setPassword(params.get("password"));

//                String token = pontaService.getMemberToken(request);
//                if (null != token) {
//                    ponta.setMessage("success");
//                    ponta.setCode(200);
//                    ponta.setId(request.getCard());
//                    ponta.setData(pointAction(customer.getPonta()));
                Ponta response = pontaService.validate(request);
                if (response.getCode() == 200) {
                    ponta = response;
                    customer.setPonta(request.getCard());
                    customerRepository.save(customer);
                } else {
                    ponta.setMessage("failed");
                    ponta.setErrorMessage("invalid member id or password");
                    ponta.setCode(400);
                }
            }
        } else {
            ponta.setMessage("failed");
            ponta.setErrorMessage("empty member id or password");
            ponta.setCode(400);
        }

        return ponta;
    }

    @DeleteMapping("/disconnect")
    @ResponseBody
    @Secured(Role.ROLE_USER)
    public String disconnectAction(Principal principal) {
        MstCustomerB2b customer = customerRepository.findOneByUsername(principal.getName());
        if (null != customer) {
            customer.setPonta(null);
            customerRepository.save(customer);
            return "{\"success\": true}";
        }

        return "{\"success\": false}";
    }

    @GetMapping("/point/{memberId}")
    public Ponta pointAction(@PathVariable("memberId") String memberId) {
        Ponta ponta = new Ponta();

        if (!StringUtils.isEmpty(memberId)) {
            ponta = pontaService.connect(memberId);
        }

        return ponta;
    }
}
