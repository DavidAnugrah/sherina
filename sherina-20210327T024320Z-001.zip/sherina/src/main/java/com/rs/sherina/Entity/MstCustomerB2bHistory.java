package com.rs.sherina.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.util.Date;

@Entity
@Table(name = "mst_customer_b2b_history")
public class MstCustomerB2bHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "mcus_code", length = 20)
    private String custId;

    @Column(name = "mcus_name", length = 100)
    private String name;

    @Column(name = "mcus_telp", length = 20)
    private String phone;

    @Column(name = "mcus_fax", length = 20)
    private String fax;

    @Column(name = "mcus_web", length = 50)
    private String url;

    @Column(name = "mcus_email", length = 100)
    private String email;

    @Column(name = "mcus_npwp", length = 30)
    private String npwp;

    @Column(name = "mcus_nama_npwp", length = 100)
    private String npwpName;

    @Column(name = "mcus_address", length = 300)
    private String address;

    @Column(name = "mcus_ponta_id", length = 20)
    private String ponta;

    @Column(name = "mcus_ponta_password", length = 100)
    private String pontaPassword;

    @Column(name = "mcus_ponta_point")
    private Long pontaPoint;

    @Column(name = "mcus_type", length = 12)
    private String type;

    @JsonIgnore
    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "mcus_create_date")
    private Date created;

    @JsonIgnore
    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "mcus_update_date")
    private Date updated;

    @ManyToOne
    @JoinColumn(name = "mcus_create_user")
    @JsonIgnore
    private MstUser userCreator;

    @ManyToOne
    @JoinColumn(name = "mcus_update_user")
    @JsonIgnore
    private MstUser userUpdater;

    public MstCustomerB2bHistory () {
    }

    public MstCustomerB2bHistory(MstUser user) {
        if (null != user) {
            this.userCreator = user;
            this.userUpdater = user;
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCustId() {
        return custId;
    }

    public void setCustId(String custId) {
        this.custId = custId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNpwp() {
        return npwp;
    }

    public void setNpwp(String npwp) {
        this.npwp = npwp;
    }

    public String getNpwpName() {
        return npwpName;
    }

    public void setNpwpName(String npwpName) {
        this.npwpName = npwpName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPonta() {
        return ponta;
    }

    public void setPonta(String ponta) {
        this.ponta = ponta;
    }

    public String getPontaPassword() {
        return pontaPassword;
    }

    public void setPontaPassword(String pontaPassword) {
        this.pontaPassword = pontaPassword;
    }

    public Long getPontaPoint() {
        return pontaPoint;
    }

    public void setPontaPoint(Long pontaPoint) {
        this.pontaPoint = pontaPoint;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getUpdated() {
        return updated;
    }

    public void setUpdated(Date updated) {
        this.updated = updated;
    }

    public MstUser getUserCreator() {
        return userCreator;
    }

    public void setUserCreator(MstUser userCreator) {
        this.userCreator = userCreator;
    }

    public MstUser getUserUpdater() {
        return userUpdater;
    }

    public void setUserUpdater(MstUser userUpdater) {
        this.userUpdater = userUpdater;
    }

}
