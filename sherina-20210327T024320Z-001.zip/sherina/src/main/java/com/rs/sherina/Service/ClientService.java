package com.rs.sherina.Service;

import com.rs.sherina.Repository.MstJwtTokenRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.security.oauth2.provider.ClientDetails;
import org.springframework.security.oauth2.provider.ClientDetailsService;
import org.springframework.security.oauth2.provider.ClientRegistrationException;
import org.springframework.stereotype.Service;

@Service
@EnableCaching
public class ClientService implements ClientDetailsService {
    @Autowired
    private MstJwtTokenRepository jwtTokenRepository;

    @Override
    @Cacheable("jwtToken")
    public ClientDetails loadClientByClientId(String s) throws ClientRegistrationException {
        return jwtTokenRepository.loadClientByClientId(s);
    }
}
