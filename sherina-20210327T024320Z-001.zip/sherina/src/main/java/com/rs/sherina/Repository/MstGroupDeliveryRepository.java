package com.rs.sherina.Repository;

import com.rs.sherina.Entity.MstGroupDelivery;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import javax.transaction.Transactional;

public interface MstGroupDeliveryRepository extends PagingAndSortingRepository<MstGroupDelivery, Long> {

    MstGroupDelivery findOneById(Long id);

    @Transactional
    @Modifying
    @Query("DELETE FROM MstGroupDelivery g WHERE g.id = ?1")
    void deleteDeliveryGroupById(Long id);
}
