package com.rs.sherina.Model;

import java.util.ArrayList;
import java.util.List;

public class StoreDistrictResponse {
    private List<StoreDistrict> subDistricts = new ArrayList<>();

    public List<StoreDistrict> getSubDistricts() {
        return subDistricts;
    }

    public void setSubDistricts(List<StoreDistrict> subDistricts) {
        this.subDistricts = subDistricts;
    }

    public void merge(StoreDistrictResponse response) {
        subDistricts.addAll(response.getSubDistricts());
    }
}
