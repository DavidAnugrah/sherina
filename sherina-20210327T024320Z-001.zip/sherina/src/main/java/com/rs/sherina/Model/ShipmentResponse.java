package com.rs.sherina.Model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ShipmentResponse {
    @JsonProperty("response_message")
    private String responseMessage;

    @JsonProperty("response_code")
    private int responseCode;

    @JsonProperty("booking_code")
    private String bookingCode;

    @JsonProperty("waybill")
    private String wbCode;

    @JsonProperty("ship_no")
    private String shipNo;

    @JsonProperty("weight")
    private Double weight;

    @JsonProperty("price")
    private Double price;

    @JsonProperty("total_price")
    private Double subtotal;

    @JsonProperty("insurance")
    private Double insurance;

    @JsonProperty("packing_cost")
    private Double packing;

    @JsonProperty("discount")
    private Double discount;

    @JsonProperty("delivery_cost")
    private Double total;

    @JsonProperty("leadtime")
    private Long days;

    public String getResponseMessage() {
        return responseMessage;
    }

    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }

    public int getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(int responseCode) {
        this.responseCode = responseCode;
    }

    public String getBookingCode() {
        return bookingCode;
    }

    public void setBookingCode(String bookingCode) {
        this.bookingCode = bookingCode;
    }

    public String getWbCode() {
        return wbCode;
    }

    public void setWbCode(String wbCode) {
        this.wbCode = wbCode;
    }

    public String getShipNo() {
        return shipNo;
    }

    public void setShipNo(String shipNo) {
        this.shipNo = shipNo;
    }

    public Double getWeight() {
        return weight;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Double getSubtotal() {
        return subtotal;
    }

    public void setSubtotal(Double subtotal) {
        this.subtotal = subtotal;
    }

    public Double getInsurance() {
        return insurance;
    }

    public void setInsurance(Double insurance) {
        this.insurance = insurance;
    }

    public Double getPacking() {
        return packing;
    }

    public void setPacking(Double packing) {
        this.packing = packing;
    }

    public Double getDiscount() {
        return discount;
    }

    public void setDiscount(Double discount) {
        this.discount = discount;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public Long getDays() {
        return days;
    }

    public void setDays(Long days) {
        this.days = days;
    }

    @JsonProperty("airwaybill")
    public void setAirwayBill(String awb) {
        wbCode = awb;
    }

    @JsonProperty("airwaybill")
    public String getAirwayBill() {
        return wbCode;
    }
}
