package com.rs.sherina.Service;

import com.rs.sherina.Model.Ponta;
import com.rs.sherina.Utils.Json;
import com.rs.sherina.Utils.Sha256;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@SuppressWarnings({"WeakerAccess", "ArraysAsListWithZeroOrOneArgument"})
@Component("pontaService")
@EnableCaching
public class PontaService {

    private final static Logger logger = LoggerFactory.getLogger(PontaService.class);

    @Value("${webretail.config.ponta-user:PONATEX}")
    private String pontaUsername;

    @Value("${webretail.config.ponta-pass:12345^&*90}")
    private String pontaPassword;

    @Value("${webretail.config.ponta-pass:12345}")
    private String pontaSecret;

    @Value("${webretail.config.ponta-login-url:}")
    private String pontaLoginUrl;

    @Value("${webretail.config.ponta-inquiry-url:}")
    private String pontaInquiryUrl;

    @Value("${webretail.config.ponta-issuer:023}")
    private String pontaIssuer;

    @Cacheable(value = "pontaToken", unless = "#result == null")
    public String getToken() {
        logger.info("Geting token...");
        if (StringUtils.isEmpty(pontaLoginUrl)) {
            pontaLoginUrl = "https://uat.ponta.co.id:7071/alfatrex/login";
        }

        String token = null;
        try {
            Ponta request = new Ponta();
            request.setUsername(pontaUsername);
            request.setPassword(pontaPassword);

            ResponseEntity<Ponta> response = doRequest(pontaLoginUrl, request);
            if (response.getStatusCodeValue() == 200) {
                token = response.getBody().getData().getToken();
                logger.info("Success: Token found.. "+token);
            } else {
                logger.error(response.getBody().getMessage());
            }
        } catch (HttpStatusCodeException e) {
            logger.error(e.getResponseBodyAsString());
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

        return token;
    }

    @CacheEvict(value = "pontaToken", allEntries = true)
    public void removeToken() {
    }

    public String getMemberToken(Ponta ponta) {
        if (StringUtils.isEmpty(pontaLoginUrl)) {
            pontaLoginUrl = "https://uat.ponta.co.id:7071/alfatrex/login";
        }
        String memberToken = null;

        try {
            String token = getToken();
            ponta.setToken(token);

            ResponseEntity<Ponta> response = doRequest(pontaLoginUrl, ponta);
            Ponta wrapper = response.getBody();
            if (response.getStatusCodeValue() == 200) {
                memberToken = wrapper.getData().getToken();
                logger.info("Success get member token: "+memberToken);
            } else {
                logger.error(response.getBody().getMessage());
            }
        } catch (HttpStatusCodeException e) {
            logger.error(e.getResponseBodyAsString());
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

        return memberToken;
    }

    public Ponta validate(Ponta request) {
        Ponta result = connect(request.getCard());
        Ponta response = new Ponta();
        response.setCode(400);
        response.setMessage("failed");
        if (!StringUtils.isEmpty(result.getId())
                && !StringUtils.isEmpty(result.getBirthDateFormatted())
                && !StringUtils.isEmpty(request.getPassword())) {
            request.setBirthDate(request.getPassword());
            String userInput = request.getBirthDateFormatted();
            String comparable = result.getBirthDateFormatted();
            if (!StringUtils.isEmpty(userInput) && !StringUtils.isEmpty(comparable) && userInput.equals(comparable)) {
                response.setId(result.getId());
                response.setData(result);
                response.setCode(200);
                response.setMessage("success");
            }
        }

        return response;
    }

    public Ponta connect(String id) {
        if (StringUtils.isEmpty(pontaInquiryUrl)) {
            pontaInquiryUrl = "https://uat.ponta.co.id:7071/alfatrex/balanceinquiry";
        }
        Ponta ponta = new Ponta();

        try {
            String token = getToken();
            Ponta request = new Ponta();
            request.setMode("card");
            request.setId(id);
            request.setIssuer(pontaIssuer);
            request.setToken(token);

            ResponseEntity<Ponta> response = doRequest(pontaInquiryUrl, request);
            Ponta wrapper = response.getBody();
            if (response.getStatusCodeValue() == 200) {
                ponta = wrapper.getData();
                logger.info("Success: connected");
            } else {
                logger.error(wrapper.getMessage());
            }
        } catch (HttpStatusCodeException e) {
            logger.error(e.getResponseBodyAsString());
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

        return ponta;
    }

    public String createChecksum(Ponta param) {
        param.setChecksum(null);
        String json = Json.encode(param);
        logger.info("Creating checksum: "+json);

        return Sha256.encode(json + pontaSecret);
    }

    public Ponta wrapChecksum(Ponta param) {
        param.setChecksum(createChecksum(param));
        return param;
    }

    public String wrapEncodeChecksum(Ponta param) {
        return Json.encode(wrapChecksum(param));
    }

    private RestTemplate rest() {
        RestTemplate rest = new RestTemplate();
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        List<MediaType> mediaTypes = new ArrayList<>();

        mediaTypes.add(MediaType.APPLICATION_JSON_UTF8);
        mediaTypes.add(MediaType.APPLICATION_JSON);
        mediaTypes.add(MediaType.TEXT_HTML);
        mediaTypes.add(MediaType.TEXT_PLAIN);

        converter.setSupportedMediaTypes(mediaTypes);
        rest.getMessageConverters().add(converter);

        return rest;
    }

    private HttpEntity<String> createPayload(Ponta request) {
        String payload = wrapEncodeChecksum(request);
        logger.info(payload);
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

        return new HttpEntity<>(payload, headers);
    }

    private ResponseEntity<Ponta> doRequest(String url, Ponta request) {
        RestTemplate rest = rest();
        return rest.exchange(url, HttpMethod.POST, createPayload(request), Ponta.class);
    }
}
