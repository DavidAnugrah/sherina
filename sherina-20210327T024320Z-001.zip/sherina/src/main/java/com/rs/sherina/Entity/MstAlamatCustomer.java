package com.rs.sherina.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.util.Date;
import java.util.Set;

@Entity
@Table(name = "mst_alamat_customer")
@SuppressWarnings("SpellCheckingInspection")
public class MstAlamatCustomer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "mlcu_mcus_kode")
    @JsonIgnore
    private MstCustomerB2b mstCustomerB2b;

    @OneToOne(mappedBy = "mstAlamatCustomer", fetch = FetchType.EAGER, cascade = {CascadeType.ALL})
    @JsonProperty("pickup")
    private MstAlamatPickup mstAlamatPickup;

    /*@OneToMany(mappedBy = "address", fetch = FetchType.LAZY, cascade = {CascadeType.ALL})
    @JsonIgnore
    private Set<TrsShipment> shipments;*/

    @Column(length = 20)
    private String mlcuKodeAlamat;

    @NotNull(message = "Nama alias tidak boleh kosong")
    @Column(length = 100)
    private String mlcuNamaAlias;

    @NotNull(message = "Nama pengirim tidak boleh kosong")
    @Column(length = 100)
    private String mlcuNamaPengirim;

    @NotNull(message = "Alamat tidak boleh kosong")
    @Column(length = 300)
    private String mlcuAlamat;

    @Column(length = 10)
    private String mlcuMprvKode;

    @Column(length = 10)
    private String mlcuMctyKode;

    @NotNull(message = "Kecamatan dan kota pengirim tidak boleh kosong")
    @Column(length = 10)
    private String mlcuMkcmKode;

    @Column(length = 100)
    private String mlcuMkcmKota;

    @NotNull(message = "No Telepon tidak boleh kosong")
    @Column(length = 30)
    private String mlcuTelpon;

    @NotNull(message = "Kode Pos tidak boleh kosong")
    @Pattern(regexp = "(^[0-9]{0,6})", message = "Kode Pos tidak Valid")
    @Column(length = 10)
    private String mlcuKodePos;

    @JsonIgnore
    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    private Date mlcuCreateDate;

    @JsonIgnore
    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    private Date mlcuUpdateDate;

    @ManyToOne
    @JoinColumn(name = "mlcu_create_user")
    @JsonIgnore
    private MstUser userCreator;

    @ManyToOne
    @JoinColumn(name = "mlcu_update_user")
    @JsonIgnore
    private MstUser userUpdater;

    @Column(name = "mlcu_temp")
    private Boolean isTemp = false;

    public Long getId() {
        return id;
    }

    public MstCustomerB2b getMstCustomerB2b() {
        return mstCustomerB2b;
    }

    public void setMstCustomerB2b(MstCustomerB2b mstCustomerB2b) {
        this.mstCustomerB2b = mstCustomerB2b;
        if (null != mstCustomerB2b) {
            MstUser user = mstCustomerB2b.getUser();
            if (null == this.userCreator) {
                this.userCreator = user;
            }

            this.userUpdater = user;
        }
    }

    public String getMlcuKodeAlamat() {
        return mlcuKodeAlamat;
    }

    public void setMlcuKodeAlamat(String mlcuKodeAlamat) {
        this.mlcuKodeAlamat = mlcuKodeAlamat;
    }

    public String getMlcuNamaAlias() {
        return mlcuNamaAlias;
    }

    public void setMlcuNamaAlias(String mlcuNamaAlias) {
        this.mlcuNamaAlias = mlcuNamaAlias;
    }

    public String getMlcuNamaPengirim() {
        return mlcuNamaPengirim;
    }

    public void setMlcuNamaPengirim(String mlcuNamaPengirim) {
        this.mlcuNamaPengirim = mlcuNamaPengirim;
    }

    public String getMlcuAlamat() {
        return mlcuAlamat;
    }

    public void setMlcuAlamat(String mlcuAlamat) {
        this.mlcuAlamat = mlcuAlamat;
    }

    public String getMlcuMprvKode() {
        return mlcuMprvKode;
    }

    public void setMlcuMprvKode(String mlcuMprvKode) {
        this.mlcuMprvKode = mlcuMprvKode;
    }

    public String getMlcuMctyKode() {
        return mlcuMctyKode;
    }

    public void setMlcuMctyKode(String mlcuMctyKode) {
        this.mlcuMctyKode = mlcuMctyKode;
    }

    public String getMlcuMkcmKode() {
        return mlcuMkcmKode;
    }

    public void setMlcuMkcmKode(String mlcuMkcmKode) {
        this.mlcuMkcmKode = mlcuMkcmKode;
    }

    public String getMlcuTelpon() {
        return mlcuTelpon;
    }

    public void setMlcuTelpon(String mlcuTelpon) {
        this.mlcuTelpon = mlcuTelpon;
    }

    public String getMlcuKodePos() {
        return mlcuKodePos;
    }

    public void setMlcuKodePos(String mlcuKodePos) {
        this.mlcuKodePos = mlcuKodePos;
    }

    public MstAlamatPickup getMstAlamatPickup() {
        return mstAlamatPickup;
    }

    public void setMstAlamatPickup(MstAlamatPickup mstAlamatPickup) {
        if (null != mstAlamatPickup) {
            mstAlamatPickup.setMstAlamatCustomer(this);
            if (null != mstCustomerB2b) {
                mstAlamatPickup.setMstCustomerB2b(mstCustomerB2b);
            }
        }
        this.mstAlamatPickup = mstAlamatPickup;
    }

    public boolean hasPickup() {
        return null == mstAlamatPickup;
    }

    public String getMlcuMkcmKota() {
        return mlcuMkcmKota;
    }

    public void setMlcuMkcmKota(String mlcuMkcmKota) {
        this.mlcuMkcmKota = mlcuMkcmKota;
    }

    public Date getMlcuCreateDate() {
        return mlcuCreateDate;
    }

    public void setMlcuCreateDate(Date mlcuCreateDate) {
        this.mlcuCreateDate = mlcuCreateDate;
    }

    /*public Set<TrsShipment> getShipments() {
        return shipments;
    }

    public void setShipments(Set<TrsShipment> shipments) {
        this.shipments = shipments;
    }*/

    public Date getMlcuUpdateDate() {
        return mlcuUpdateDate;
    }

    public void setMlcuUpdateDate(Date mlcuUpdateDate) {
        this.mlcuUpdateDate = mlcuUpdateDate;
    }

    public Boolean getIsTemp() {
        return isTemp;
    }

    public void setIsTemp(Boolean temp) {
        isTemp = temp;
    }
}
