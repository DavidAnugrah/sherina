package com.rs.sherina.Entity;

import org.springframework.util.StringUtils;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.Date;

@Entity
@Table(name = "mst_store_alfamart")
public class MstStoreAlfamart {
    @Id
    @Column(name = "msa_kode", length = 20)
    private String code;

    @Column(name = "msa_cabang", length = 20)
    private String branch;

    @Column(name = "msa_nama", length = 200)
    private String name;

    @Column(name = "msa_alamat", length = 1000, columnDefinition = "text")
    private String address;

    @Column(name = "msa_kelurahan", length = 100)
    private String kelurahan;

    @Column(name = "msa_kecamatan", length = 100)
    private String kecamatan;

    @Column(name = "msa_kota", length = 100)
    private String city;

    @Column(name = "msa_provinsi", length = 100)
    private String provinsi;

    @Column(name = "msa_route", length = 20)
    private String route;

    @Column(name = "msa_latlong", length = 100)
    private String position;

    @Column(name = "msa_company", length = 3)
    private String company;

    @Column(name = "msa_web", length = 30)
    private String web;

    @Column(name = "msa_mkcm_kode", length = 5)
    private String mkcmKode;

    @Column(name = "msa_mcty_kode", length = 10)
    private String mctyKode;

    @Column(name = "msa_aktif")
    private Integer active;

    @Column(name = "msa_ins_user", length = 20)
    private String insUser;

    @Column(name = "msa_ins_date")
    private Date created;

    @Column(name = "msa_upd_user", length = 20)
    private String updUser;

    @Column(name = "msa_upd_date")
    private Date modified;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getKelurahan() {
        return kelurahan;
    }

    public void setKelurahan(String kelurahan) {
        this.kelurahan = kelurahan;
    }

    public String getKecamatan() {
        return kecamatan;
    }

    public void setKecamatan(String kecamatan) {
        this.kecamatan = kecamatan;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getProvinsi() {
        return provinsi;
    }

    public void setProvinsi(String provinsi) {
        this.provinsi = provinsi;
    }

    public String getRoute() {
        return route;
    }

    public void setRoute(String route) {
        this.route = route;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getWeb() {
        return web;
    }

    public void setWeb(String web) {
        this.web = web;
    }

    public String getMkcmKode() {
        return mkcmKode;
    }

    public void setMkcmKode(String mkcmKode) {
        this.mkcmKode = mkcmKode;
    }

    public String getMctyKode() {
        return mctyKode;
    }

    public void setMctyKode(String mctyKode) {
        this.mctyKode = mctyKode;
    }

    public Integer getActive() {
        return active;
    }

    public void setActive(Integer active) {
        this.active = active;
    }

    public String getInsUser() {
        return insUser;
    }

    public void setInsUser(String insUser) {
        this.insUser = insUser;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public String getUpdUser() {
        return updUser;
    }

    public void setUpdUser(String updUser) {
        this.updUser = updUser;
    }

    public Date getModified() {
        return modified;
    }

    public void setModified(Date modified) {
        this.modified = modified;
    }

    @Transient
    public Double getLatitude() {
        if (StringUtils.isEmpty(position)) {
            return 0.0;
        }

        Double res = 0.0;
        try {
            String rep = position.replaceAll("[^\\d\\.\\,\\-]+", "");
            String[] pos = rep.split(",");
            if (!StringUtils.isEmpty(res) && !rep.equals(",") && pos.length == 2 && !StringUtils.isEmpty(pos[0])) {
                res = Double.valueOf(pos[0]);
            }
        } catch (Exception e) {
            res = 0.0;
        }

        return res;
    }

    @Transient
    public Double getLongitude() {
        if (StringUtils.isEmpty(position)) {
            return 0.0;
        }

        Double res = 0.0;
        try {
            String rep = position.replaceAll("[^\\d\\.\\,\\-]+", "");
            String[] pos = rep.split(",");
            if (!StringUtils.isEmpty(res) && !rep.equals(",") && pos.length == 2 && !StringUtils.isEmpty(pos[1])) {
                res = Double.valueOf(pos[1]);
            }
        } catch (Exception e) {
            res = 0.0;
        }

        return res;
    }
}

