package com.rs.sherina.Model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Invoice {

    private String invoiceNumber;

    private String customerCode;

    private String paymentType;

    private String paymentReferens;

    private String status;

    private String invoiceDate;

    private String dueDateInvoice;

    private Double nilai;

    @JsonProperty("invoiceNumber")
    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    @JsonProperty("invoice_number")
    public void setInvoiceNumber(String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    @JsonProperty("customerCode")
    public String getCustomerCode() {
        return customerCode;
    }

    @JsonProperty("customer_code")
    public void setCustomerCode(String customerCode) {
        this.customerCode = customerCode;
    }

    @JsonProperty("paymentType")
    public String getPaymentType() {
        return paymentType;
    }

    @JsonProperty("payment_type")
    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    @JsonProperty("paymentReferens")
    public String getPaymentReferens() {
        return paymentReferens;
    }

    @JsonProperty("payment_referens")
    public void setPaymentReferens(String paymentReferens) {
        this.paymentReferens = paymentReferens;
    }

    @JsonProperty("status")
    public String getStatus() {
        if (null == status) {
            return "INVOICE";
        }

        return status;
    }

    @JsonProperty("statusnya")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("invoiceDate")
    public String getInvoiceDate() {
        return invoiceDate;
    }

    @JsonProperty("invoice_date")
    public void setInvoiceDate(String invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    @JsonProperty("dueDateInvoice")
    public String getDueDateInvoice() {
        return dueDateInvoice;
    }

    @JsonProperty("due_date_invoice")
    public void setDueDateInvoice(String dueDateInvoice) {
        this.dueDateInvoice = dueDateInvoice;
    }

    @JsonProperty("nilai")
    public Double getNilai() {
        return nilai;
    }

    @JsonProperty("nilai")
    public void setNilai(Double nilai) {
        this.nilai = nilai;
    }
}
