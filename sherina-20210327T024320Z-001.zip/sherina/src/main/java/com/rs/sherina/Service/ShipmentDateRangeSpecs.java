package com.rs.sherina.Service;

import com.rs.sherina.Entity.TrsShipment;
import org.springframework.data.jpa.datatables.mapping.Column;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ShipmentDateRangeSpecs implements Specification<TrsShipment> {

    private String from;

    private String to;

    public ShipmentDateRangeSpecs(DataTablesInput input) {
        Column col = input.getColumn("tshCreated");
        if (null != col) {
            String value = col.getSearch().getValue();
            if (!StringUtils.isEmpty(value)) {
                String[] values = value.split(" ");
                if (values.length == 2) {
                    this.from = values[0];
                    this.to = values[1];
                } else if (values.length == 1) {
                    this.from = values[0];
                }
            }
            col.getSearch().setValue("");
        }
    }

    @Override
    public Predicate toPredicate(Root<TrsShipment> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
        Predicate predicate = null;
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        if (!StringUtils.isEmpty(from) && !StringUtils.isEmpty(to)) {
            try {
                from += " 00:00:00";
                to += " 23:59:59";
                predicate = criteriaBuilder.between(root.get("tshCreated").as(Date.class), format.parse(from), format.parse(to));
            } catch (ParseException e) {
                // ..
            }
        } else if (!StringUtils.isEmpty(from)) {
            to = from + " 23:59:59";
            from += " 00:00:00";

            try {
                predicate = criteriaBuilder.equal(root.get("tshCreated").as(Date.class), format.parse(from));
            } catch (ParseException e) {
                // ..
            }
        }

        return predicate;
    }
}
