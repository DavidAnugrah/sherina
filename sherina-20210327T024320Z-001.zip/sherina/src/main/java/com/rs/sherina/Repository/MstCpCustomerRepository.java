package com.rs.sherina.Repository;

import com.rs.sherina.Entity.MstCpCustomer;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import javax.transaction.Transactional;

public interface MstCpCustomerRepository extends PagingAndSortingRepository<MstCpCustomer, Long> {
    @Modifying
    @Transactional
    @Query(value = "DELETE FROM mst_cp_customer c WHERE c.mcpc_mcus_kode = ?1", nativeQuery = true)
    void forceDeleteByCustomerId(String kodeAkun);

    @Modifying
    @Transactional
    @Query(value = "DELETE FROM mst_cp_customer c WHERE c.id = ?1", nativeQuery = true)
    void deletePICbyId(int id);

    @Modifying
    @Transactional
    @Query(value = "UPDATE mst_cp_customer SET is_deleted = true WHERE id = ?1",nativeQuery = true)
    void updatePICbyId(int email);
}