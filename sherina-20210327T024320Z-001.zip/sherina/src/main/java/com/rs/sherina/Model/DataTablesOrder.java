package com.rs.sherina.Model;

public class DataTablesOrder {
    private Long column = 0L;

    private String dir = "asc";

    public Long getColumn() {
        return column;
    }

    public void setColumn(Long column) {
        this.column = column;
    }

    public String getDir() {
        return dir;
    }

    public void setDir(String dir) {
        this.dir = dir;
    }
}
