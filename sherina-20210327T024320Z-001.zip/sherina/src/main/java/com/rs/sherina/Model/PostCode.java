package com.rs.sherina.Model;

import com.fasterxml.jackson.annotation.JsonProperty;

@SuppressWarnings("SpellCheckingInspection")
public class PostCode {
	
	private String kodepos;


	public String getKodepos() {
		return kodepos;
	}

	public void setKodepos(String kodepos) {
		this.kodepos = kodepos;
	}

}
