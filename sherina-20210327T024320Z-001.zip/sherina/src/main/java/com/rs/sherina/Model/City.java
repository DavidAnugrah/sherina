package com.rs.sherina.Model;

import com.fasterxml.jackson.annotation.JsonProperty;

@SuppressWarnings("SpellCheckingInspection")
public class City {

    private String mkcmKode;

    private String mkcmNama;

    private String mctyKode;

    private String mctyNama;

    private String namaKecamatanKota;

    private String kodeKecamatan;

    private Long districtId;

    @JsonProperty("id")
    public String getId() {
        return mkcmKode + "-" + mctyKode;
    }

    @JsonProperty("mkcmKode")
    public String getMkcmKode() {
        return mkcmKode;
    }

    @JsonProperty("mkcm_kode")
    public void setMkcmKode(String mkcmKode) {
        this.mkcmKode = mkcmKode;
    }

    @JsonProperty("mkcmNama")
    public String getMkcmNama() {
        return mkcmNama;
    }

    @JsonProperty("mkcm_nama")
    public void setMkcmNama(String mkcmNama) {
        this.mkcmNama = mkcmNama;
    }

    @JsonProperty("mctyKode")
    public String getMctyKode() {
        return mctyKode;
    }

    @JsonProperty("mcty_kode")
    public void setMctyKode(String mctyKode) {
        this.mctyKode = mctyKode;
    }

    @JsonProperty("mctyNama")
    public String getMctyNama() {
        return mctyNama;
    }

    @JsonProperty("mcty_nama")
    public void setMctyNama(String mctyNama) {
        this.mctyNama = mctyNama;
    }

    @JsonProperty("namaKecamatanKota")
    public String getNamaKecamatanKota() {
        return namaKecamatanKota;
    }

    @JsonProperty("nama_kecamatan_kota")
    public void setNamaKecamatanKota(String namaKecamatanKota) {
        this.namaKecamatanKota = namaKecamatanKota;
    }

    @JsonProperty("kodeKecamatan")
    public String getKodeKecamatan() {
        return kodeKecamatan;
    }

    @JsonProperty("kode_kecamatan")
    public void setKodeKecamatan(String kodeKecamatan) {
        this.kodeKecamatan = kodeKecamatan;
    }

    @JsonProperty("districtId")
    public Long getDistrictId() {
        return districtId;
    }

    @JsonProperty("sub_district_id")
    public void setDistrictId(Long districtId) {
        this.districtId = districtId;
    }
}
