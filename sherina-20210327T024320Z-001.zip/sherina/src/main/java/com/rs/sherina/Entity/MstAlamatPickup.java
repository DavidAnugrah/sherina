package com.rs.sherina.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.util.Date;
import java.util.Set;

@Entity
@Table(name = "mst_alamat_pickup")
@SuppressWarnings("SpellCheckingInspection")
public class MstAlamatPickup {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "mlpi_mcus_kode")
    @JsonIgnore
    private MstCustomerB2b mstCustomerB2b;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "mlcu_mlpi_id")
    @JsonIgnore
    private MstAlamatCustomer mstAlamatCustomer;

    @JsonProperty("address")
    @OneToMany(mappedBy = "mstAlamatPickup", fetch = FetchType.LAZY, cascade = {CascadeType.ALL})
    @JsonIgnore
    private Set<MstAlamatDelivery> mstAlamatDelivery;

   /* @OneToMany(mappedBy = "pickup", fetch = FetchType.LAZY, cascade = {CascadeType.ALL})
    @JsonIgnore
    private Set<TrsShipment> shipments;*/

    @Column(length = 20)
    private String mlpiKodeAlamat;

    @Column(length = 100)
    @NotNull(message = "Nama Alias tidak boleh kosong")
    private String mlpiNamaAlias;

    @Column(length = 100)
    @NotNull(message = "Nama Pengirim tidak boleh kosong")
    private String mlpiNamaPengirim;

    @Column(length = 300)
    @NotNull(message = "Alamat tidak boleh kosong")
    private String mlpiAlamat;

    private String mlpiMprvKode;

    private String mlpiMctyKode;

    @NotNull(message = "Kota Pengirim tidak boleh kosong")
    private String mlpiMkcmKode;

    private String mlpiMkcmKota;

    @NotNull(message = "No Telepon tidak boleh kosong")
    private String mlpiTelpon;

    @NotNull(message = "Kode Pos tidak boleh kosong")
    @Pattern(regexp = "(^[0-9]{0,6})", message = "Kode Pos tidak Valid")
    private String mlpiKodePos;

    private String mlpiLatLong;

    @JsonIgnore
    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    private Date mlpiCreateDate;

    @JsonIgnore
    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    private Date mlpiUpdateDate;

    @ManyToOne
    @JoinColumn(name = "mlpi_create_user")
    @JsonIgnore
    private MstUser userCreator;

    @ManyToOne
    @JoinColumn(name = "mlpi_update_user")
    @JsonIgnore
    private MstUser userUpdater;

    @Column(name = "mlpi_temp")
    private Boolean isTemp = false;

    public Long getId() {
        return id;
    }

    public String getMlpiNamaAlias() {
        return mlpiNamaAlias;
    }

    public void setMlpiNamaAlias(String mlpiNamaAlias) {
        this.mlpiNamaAlias = mlpiNamaAlias;
    }

    public String getMlpiNamaPengirim() {
        return mlpiNamaPengirim;
    }

    public void setMlpiNamaPengirim(String mlpiNamaPengirim) {
        this.mlpiNamaPengirim = mlpiNamaPengirim;
        if (null != mstCustomerB2b) {
            MstUser user = mstCustomerB2b.getUser();
            if (null == this.userCreator) {
                this.userCreator = user;
            }

            this.userUpdater = user;
        }
    }

    public MstCustomerB2b getMstCustomerB2b() {
        return mstCustomerB2b;
    }

    public void setMstCustomerB2b(MstCustomerB2b mstCustomerB2b) {
        this.mstCustomerB2b = mstCustomerB2b;
    }

    public String getMlpiKodeAlamat() {
        return mlpiKodeAlamat;
    }

    public void setMlpiKodeAlamat(String mlpiKodeAlamat) {
        this.mlpiKodeAlamat = mlpiKodeAlamat;
    }

    public String getMlpiAlamat() {
        return mlpiAlamat;
    }

    public void setMlpiAlamat(String mlpiAlamat) {
        this.mlpiAlamat = mlpiAlamat;
    }

    public String getMlpiMprvKode() {
        return mlpiMprvKode;
    }

    public void setMlpiMprvKode(String mlpiMprvKode) {
        this.mlpiMprvKode = mlpiMprvKode;
    }

    public String getMlpiMctyKode() {
        return mlpiMctyKode;
    }

    public void setMlpiMctyKode(String mlpiMctyKode) {
        this.mlpiMctyKode = mlpiMctyKode;
    }

    public String getMlpiMkcmKode() {
        return mlpiMkcmKode;
    }

    public void setMlpiMkcmKode(String mlpiMkcmKode) {
        this.mlpiMkcmKode = mlpiMkcmKode;
    }

    public String getMlpiTelpon() {
        return mlpiTelpon;
    }

    public void setMlpiTelpon(String mlpiTelpon) {
        this.mlpiTelpon = mlpiTelpon;
    }

    public String getMlpiKodePos() {
        return mlpiKodePos;
    }

    public void setMlpiKodePos(String mlpiKodePos) {
        this.mlpiKodePos = mlpiKodePos;
    }

    public String getMlpiLatLong() {
        return mlpiLatLong;
    }

    public void setMlpiLatLong(String mlpiLatLong) {
        this.mlpiLatLong = mlpiLatLong;
    }

    public boolean hasAddress() {
        return null == mstAlamatCustomer;
    }

    public void setMstAlamatCustomer(MstAlamatCustomer mstAlamatCustomer) {
        this.mstAlamatCustomer = mstAlamatCustomer;
    }

    public void removeAddress() {
        this.mstAlamatCustomer = null;
    }

    public MstAlamatCustomer getMstAlamatCustomer() {
        return mstAlamatCustomer;
    }

    public String getMlpiMkcmKota() {
        return mlpiMkcmKota;
    }

    public void setMlpiMkcmKota(String mlpiMkcmKota) {
        this.mlpiMkcmKota = mlpiMkcmKota;
    }

    /*public Set<TrsShipment> getShipments() {
        return shipments;
    }

    public void setShipments(Set<TrsShipment> shipments) {
        this.shipments = shipments;
    }*/

    @JsonIgnore
    public Set<MstAlamatDelivery> getMstAlamatDelivery() {
        return mstAlamatDelivery;
    }

    @JsonIgnore
    public void setMstAlamatDelivery(Set<MstAlamatDelivery> mstAlamatDelivery) {
        this.mstAlamatDelivery = mstAlamatDelivery;
    }

    public Date getMlpiCreateDate() {
        return mlpiCreateDate;
    }

    public void setMlpiCreateDate(Date mlpiCreateDate) {
        this.mlpiCreateDate = mlpiCreateDate;
    }

    public Date getMlpiUpdateDate() {
        return mlpiUpdateDate;
    }

    public void setMlpiUpdateDate(Date mlpiUpdateDate) {
        this.mlpiUpdateDate = mlpiUpdateDate;
    }

    public Boolean getIsTemp() {
        return isTemp;
    }

    public void setIsTemp(Boolean temp) {
        this.isTemp = temp;
    }
}
