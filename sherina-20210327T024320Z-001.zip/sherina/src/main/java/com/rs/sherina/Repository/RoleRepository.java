package com.rs.sherina.Repository;

import com.rs.sherina.Entity.MstRole;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.Set;

public interface RoleRepository extends PagingAndSortingRepository<MstRole, Long> {
    Set<MstRole> findByNameIn(String[] name);
}
