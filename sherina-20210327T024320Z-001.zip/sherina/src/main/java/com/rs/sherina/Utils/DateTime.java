package com.rs.sherina.Utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateTime {
    public static Date parse(String dateString) {
        if (null == dateString || "".equals(dateString)) {
            return null;
        }

        Date date;
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            date = formatter.parse(dateString);
        } catch (ParseException e) {
            date = null;
        }

        return date;
    }

    public static String format(Date date) {
        if (null == date) {
            return null;
        }

        String result;
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            result = formatter.format(date);
        } catch (Exception e) {
            result = null;
        }

        return result;
    }
}
