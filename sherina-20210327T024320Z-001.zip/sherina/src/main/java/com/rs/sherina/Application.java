package com.rs.sherina;

import com.rs.sherina.Utils.MD5PasswordEncoder;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.data.jpa.datatables.repository.DataTablesRepositoryFactoryBean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.util.StringUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;

//import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
@EnableJpaRepositories(
        repositoryFactoryBeanClass = DataTablesRepositoryFactoryBean.class,
        basePackages = {"com.rs.sherina.Repository", "com.rs.sherina.DataTablesRepository"}
)
public class Application extends SpringBootServletInitializer {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
        PasswordEncoder encoder = new MD5PasswordEncoder();
        String password = encoder.encode("password");

//        String tokenQuery = "INSERT INTO mst_jwt_token (approved," +
//                "authorities," +
//                "client_id," +
//                "grant_types," +
//                "has_scope," +
//                "has_secret," +
//                "redirect_uris," +
//                "scope," +
//                "client_secret," +
//                "expired)\nVALUES (TRUE," +
//                "'ROLE_CLIENT,ROLE_TRUSTED_CLIENT'," +
//                "'my-client-id', " +
//                "'password,authorization_code,refresh_token,implicit'," +
//                "\nTRUE," +
//                "TRUE," +
//                "null," +
//                "'read,write,trust'," +
//                "'" + password + "'," +
//                "3600);";
//
//        String roleQuery = "INSERT INTO mst_role (id, name) VALUES (1, 'ROLE_ADMIN'), (2, 'ROLE_USER');";
//        String customerQuery = "INSERT INTO mst_customer_b2b (mcus_code, mcus_name) VALUES ('C18.0174', 'Admin');";
//
//        String userQuery = "INSERT INTO mst_user (id, nama, " +
//                "username, " +
//                "password, kode_akun)\nVALUES (1, 'admin', 'admin@mail.com', '" + password + "', 'C18.0174');";
//
//        String roleUserQuery = "INSERT INTO mst_user_roles (user_id, role_id) VALUES (1,1), (1,2);";
//
//        System.out.println();
//        System.out.println(String.format("GENERATED PASSWORD: (password = %s)", password));
//        System.out.println("------------------------------------------------------------");
//        System.out.println("Create new JWT Token: ");
//        System.out.println();
//        System.out.println(tokenQuery);
//        System.out.println("------------------------------------------------------------");
//        System.out.println("Create new Roles: ");
//        System.out.println();
//        System.out.println(roleQuery);
//        System.out.println("------------------------------------------------------------");
//        System.out.println("Create new MstCustomerB2b: ");
//        System.out.println();
//        System.out.println(customerQuery);
//        System.out.println();
//        System.out.println("------------------------------------------------------------");
//        System.out.println("Create new MstUser: ");
//        System.out.println();
//        System.out.println(userQuery);
//        System.out.println();
//        System.out.println("------------------------------------------------------------");
//        System.out.println("Apply MstRole to MstUser: ");
//        System.out.println();
//        System.out.println(roleUserQuery);
//        System.out.println();
//        System.out.println("------------------------------------------------------------");
//        System.out.println("Login with username: admin@mail.com, password: password");
//        System.out.println();
    }

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(Application.class);
    }

    public static String getUrl(String path) {
        String baseUrl;

        try {
            if (!StringUtils.isEmpty(path) && path.startsWith("/")) {
                path = path.substring(1);
            }

            ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
            HttpServletRequest request = attr.getRequest();
            baseUrl = request.getScheme() + "://" + request.getServerName();
            int port = request.getServerPort();

            if (port != 80) {
                baseUrl += ":" + port;
            }

            if (!StringUtils.isEmpty(request.getContextPath())) {
                baseUrl += request.getContextPath();
            }

            if (!StringUtils.isEmpty(path)) {
                baseUrl = String.format("%s/%s", baseUrl, path);
            } else if (!baseUrl.endsWith("/")) {
                baseUrl += "/";
            }
        } catch (RuntimeException e) {
            baseUrl = "/";
        }

        return baseUrl;
    }
}
