package com.rs.sherina.Model;

import com.fasterxml.jackson.annotation.JsonProperty;

@SuppressWarnings("SpellCheckingInspection")
public class Service {
    private String code;

    private String name;

    private Double price;

    private Double days;

    @JsonProperty("cons")
    private Double cons;

    private Double minCharge;

    private Double minWeight;

    @JsonProperty("code")
    public String getCode() {
        return code;
    }

    @JsonProperty("service_code")
    public void setCode(String code) {
        this.code = code;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("service_name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("price")
    public Double getPrice() {
        return price;
    }

    @JsonProperty("harga")
    public void setPrice(Double price) {
        this.price = price;
    }

    @JsonProperty("days")
    public Double getDays() {
        return days;
    }

    @JsonProperty("lead_time")
    public void setDays(Double days) {
        this.days = days;
    }

    public Double getCons() {
        return cons;
    }

    public void setCons(Double cons) {
        this.cons = cons;
    }

    @JsonProperty("minCharge")
    public Double getMinCharge() {
        return minCharge;
    }

    @JsonProperty("min_charge")
    public void setMinCharge(Double minCharge) {
        this.minCharge = minCharge;
    }

    @JsonProperty("minWeight")
    public Double getMinWeight() {
        return minWeight;
    }

    @JsonProperty("min_weight")
    public void setMinWeight(Double minWeight) {
        this.minWeight = minWeight;
    }
}
