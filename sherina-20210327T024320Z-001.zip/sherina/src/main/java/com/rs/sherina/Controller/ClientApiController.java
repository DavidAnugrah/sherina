package com.rs.sherina.Controller;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rs.sherina.Entity.MstAlamatCustomer;
import com.rs.sherina.Entity.MstAlamatDelivery;
import com.rs.sherina.Entity.MstAlamatPickup;
import com.rs.sherina.Entity.MstCpCustomer;
import com.rs.sherina.Entity.MstCustomerB2b;
import com.rs.sherina.Entity.MstGroupDelivery;
import com.rs.sherina.Entity.MstRole;
import com.rs.sherina.Entity.MstUiNews;
import com.rs.sherina.Entity.MstUiSlider;
import com.rs.sherina.Entity.MstUser;
import com.rs.sherina.Entity.TrsShipment;
import com.rs.sherina.Extension.annotation.Route;
import com.rs.sherina.Model.ApiUser;
import com.rs.sherina.Model.DeliveryStatus;
import com.rs.sherina.Model.Role;
import com.rs.sherina.Repository.MstAlamatCustomerRepository;
import com.rs.sherina.Repository.MstAlamatDeliveryRepository;
import com.rs.sherina.Repository.MstAlamatPickupRepository;
import com.rs.sherina.Repository.MstCpCustomerRepository;
import com.rs.sherina.Repository.MstCustomerB2bRepository;
import com.rs.sherina.Repository.MstGroupDeliveryRepository;
import com.rs.sherina.Repository.MstUiNewsRepository;
import com.rs.sherina.Repository.MstUiSliderRepository;
import com.rs.sherina.Repository.RoleRepository;
import com.rs.sherina.Repository.TrsShipmentRepository;
import com.rs.sherina.Repository.UserRepository;
import com.rs.sherina.Utils.MD5;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.transaction.Transactional;
import javax.validation.Valid;
import java.io.IOException;
import java.security.Principal;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

@RestController
@Secured(Role.ROLE_BACKDOOR)
@Route("/core")
public class ClientApiController {
    @Autowired
    private TrsShipmentRepository shipmentRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private MstCustomerB2bRepository customerRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private MstAlamatCustomerRepository alamatCustomer;

    @Autowired
    private MstCpCustomerRepository cpCustomer;

    @Autowired
    private MstCustomerB2bRepository mstCustomerb2bRepository;
    
    @Autowired
    private MstAlamatDeliveryRepository deliveryRepository;

    @Autowired
    private MstAlamatPickupRepository pickupRepository;

    @Autowired
    private MstGroupDeliveryRepository groupRepository;

    @Autowired
    private MstUiNewsRepository newsRepository;

    @Autowired
    private MstUiSliderRepository sliderRepository;

    @Autowired
    private MstCpCustomerRepository cpCustomerRepository;

    private final Logger logger = LoggerFactory.getLogger(ClientApiController.class);

    @PostMapping(value = "/shipment/status", produces = {MediaType.APPLICATION_JSON_VALUE})
    @ResponseBody
    @Transactional
    public String updateShipmentStatusAction(@RequestBody DeliveryStatus status, Principal principal) {
        MstUser user = userRepository.findOneByUsername(principal.getName());
        TrsShipment shipment = shipmentRepository.findOneByTshAwb(status.getWaybill());
        if (null == shipment) {
            shipment = shipmentRepository.findOneByTshPk(status.getBookingCode());
        }

        String response = "{\"success\": true}";

        if (null == shipment) {
            response = "{\"success\": false}";
        } else {
            try {
                shipment.setUserUpdater(user);
                shipment.setTshStatus(status.getStatus());
                shipmentRepository.save(shipment);
            } catch (Exception e) {
                logger.error(e.getMessage());
                response = "{\"success\": false}";
            }
        }

        return response;
    }

    @PostMapping("/user")
    @ResponseBody
    @Transactional
    public MstUser createNewUserAction(@Valid @RequestBody ApiUser raw, Principal principal) {
        MstUser creator = userRepository.findOneByUsername(principal.getName());
        Set<MstRole> roles = roleRepository.findByNameIn(new String[] {"ROLE_ADMIN", "ROLE_USER"});
        MstUser user = new MstUser();
        MstCustomerB2b cust = customerRepository.findOneById(raw.getCode()).orElse(null);

        if (null == cust) {
            cust = new MstCustomerB2b(creator);
            cust.setId(raw.getCode());
        } else if (null != cust.getUser()) {
            user = cust.getUser();
        }
        
        cust.setNpwp(raw.getNpwp());
        cust.setNpwpName(raw.getNpwpName());
        cust.setName(raw.getName());
        cust.setEmail(raw.getEmail());
        cust.setAddress(raw.getAddress());
        cust.setPhone(raw.getPhone());
        cust.setFax(raw.getFax());
        cust.setUrl(raw.getUrl());
        mstCustomerb2bRepository.save(cust);

        user.setName(raw.getName());
        user.setPassword(MD5.encode(raw.getPassword()));
        user.setUsername(raw.getEmail());
        user.setMstCustomerB2b(cust);
        user.setRoles(roles);
        user.setRemark(String.format("Generated by %s", creator.getName()));

        if (!StringUtils.isEmpty(raw.getContactName()) && !StringUtils.isEmpty(raw.getContactEmail()) && !StringUtils.isEmpty(raw.getContactPhone())) {
            if (null != cust.getMstCpCustomers()) {
                MstCpCustomer cp = new MstCpCustomer();
                if (cust.getMstCpCustomers().size() > 0) {
                    cp = cust.getMstCpCustomers().iterator().next();
                    if (null != cp) {
                        cp = cpCustomer.findOne(cp.getId());
                    }
                } else {
                    cust.setMstCpCustomers(new HashSet<MstCpCustomer>());
                }

                cp.setMcpcNama(raw.getContactName());
                cp.setMcpcEmail(raw.getContactEmail());
                cp.setMcpcHp(raw.getContactPhone());

                if (null == cp.getId()) {
                    cp.setMstCustomerB2b(cust);
                    cust.getMstCpCustomers().add(cp);
                } else {
                    cpCustomerRepository.save(cp);
                }
            } else {
                try {
                    Set<MstCpCustomer> cps = new HashSet<>();
                    MstCpCustomer cp = new MstCpCustomer();
                    cp.setMcpcNama(raw.getContactName());
                    cp.setMcpcEmail(raw.getContactEmail());
                    cp.setMcpcHp(raw.getContactPhone());
                    cps.add(cp);
                    cust.setMstCpCustomers(cps);

                } catch (NullPointerException e) {
                }

            }
        }

        userRepository.save(user);

        return user;
    }

    @DeleteMapping("/user")
    @ResponseBody
    public String deleteUserAction(@RequestBody String data, Principal principal) {
        String id = getStringId(data);

        MstUser executor = userRepository.findOneByUsername(principal.getName());
        MstCustomerB2b cust = customerRepository.findOneById(id).orElse(null);
        String response = "{\"success\": false, \"message\": \"Customer not found\"}";
        if (null != cust) {
            MstUser user = cust.getUser();
            try {
                for (MstRole role: user.getRoles()) {
                    user.getRoles().remove(role);
                }
                userRepository.save(user);

                for (MstAlamatCustomer addr: cust.getMstAlamatCustomers()) {
                    alamatCustomer.delete(addr);
                }

                for (MstAlamatDelivery delv: cust.getDeliveries()) {
                    deliveryRepository.delete(delv);
                }

                for (MstCpCustomer cp: cust.getMstCpCustomers()) {
                    cpCustomer.delete(cp);
                }

                for (MstAlamatPickup pickup: cust.getMstAlamatPickups()) {
                    pickupRepository.delete(pickup);
                }

                for (MstGroupDelivery group: cust.getMstGroupDeliveries()) {
                    groupRepository.delete(group);
                }

                for (TrsShipment shipment: cust.getTrsShipments()) {
                    shipmentRepository.delete(shipment);
                }

                userRepository.delete(user);
                customerRepository.delete(cust);

                response = "{\"success\": true}";
            } catch (Exception e) {
                response = String.format("{\"success\": false, \"message\": \"%s\"}", e.getMessage()+"");
                logger.error(e.getMessage());
            }
        }

        return response;
    }

    @PostMapping("/ui/slider")
    @Transactional
    @ResponseBody
    public MstUiSlider postSliderAction(@Valid @RequestBody MstUiSlider slider, Principal principal) {
        MstUser user = userRepository.findOneByUsername(principal.getName());

        slider.setUserUpdater(user);
        if (null == slider.getId()) {
            slider.setUserCreator(user);
        }

        sliderRepository.save(slider);

        return slider;
    }

    @DeleteMapping("/ui/slider")
    @ResponseBody
    public String deleteSliderAction(@RequestBody String data, Principal principal) {
        Long id = getLongId(data);
        MstUser executor = userRepository.findOneByUsername(principal.getName());

        sliderRepository.delete(id);

        return "{\"success\": true}";
    }

    @PostMapping("/ui/news")
    @Transactional
    @ResponseBody
    public MstUiNews postNewsAction(@Valid @RequestBody MstUiNews news, Principal principal) {
        MstUser user = userRepository.findOneByUsername(principal.getName());

        news.setUserUpdater(user);
        if (null == news.getId()) {
            news.setUserCreator(user);
        }

        newsRepository.save(news);

        return news;
    }

    @DeleteMapping("/ui/news")
    @ResponseBody
    public String deleteNewsAction(@RequestBody String data, Principal principal) {
        Long id = getLongId(data);
        MstUser executor = userRepository.findOneByUsername(principal.getName());

        newsRepository.delete(id);

        return "{\"success\": true}";
    }

    private String getStringId(String data) {
        TypeReference<HashMap<String, String>> typeRef
                = new TypeReference<HashMap<String, String>>() {};
        ObjectMapper mapper = new ObjectMapper();
        String id = "";
        try {
            Map<String, String> map = mapper.readValue(data, typeRef);
            id = Optional.of(map.get("id")).orElse("");
            logger.info(String.format("Removing customer with id %s", id));
        } catch (JsonParseException e) {
            logger.error(e.getMessage());
        } catch(IOException e) {
            logger.error(e.getMessage());
        }

        return id;
    }

    private Long getLongId(String data) {
        String id = getStringId(data);

        return Long.valueOf(id);
    }

}
