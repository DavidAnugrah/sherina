package com.rs.sherina.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.data.jpa.datatables.mapping.Column;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.Order;
import org.springframework.data.jpa.datatables.mapping.Search;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DataTablesRequest {
    private Long draw = 0L;

    private Long start = 0L;

    private Long length = 0L;

    private DataTablesSearch search = new DataTablesSearch();

    private List<DataTablesColumn> columns = new ArrayList<>();

    private List<DataTablesOrder> order = new ArrayList<>();

    @JsonIgnore
    public DataTablesInput getInput() {
        DataTablesInput input = new DataTablesInput();

        for (DataTablesColumn column : columns) {
            Search s = new Search(column.getSearch().getValue(), column.getSearch().getRegex());
            Column c = new Column(column.getData(), column.getName(), column.isSearchable(), column.isOrderable(), s);

            input.getColumns().add(c);
        }

        for (DataTablesOrder ord : order) {
            DataTablesColumn col = columns.get(ord.getColumn().intValue());
            if (col.isOrderable()) {
                input.addOrder(col.getData(), ord.getDir().equals("asc"));
            }
        }

        input.setSearch(new Search(search.getValue(), search.getRegex()));

        input.setDraw(draw.intValue());
        input.setStart(start.intValue());
        input.setLength(length.intValue());

        return input;
    }

    public Long getDraw() {
        return draw;
    }

    public void setDraw(Long draw) {
        this.draw = draw;
    }

    public List<DataTablesColumn> getColumns() {
        return columns;
    }

    public void setColumns(List<DataTablesColumn> columns) {
        this.columns = columns;
    }

    public void addColumn(DataTablesColumn column) {
        columns.add(column);
    }

    public Long getStart() {
        return start;
    }

    public void setStart(Long start) {
        this.start = start;
    }

    public Long getLength() {
        return length;
    }

    public void setLength(Long length) {
        this.length = length;
    }

    public List<DataTablesOrder> getOrder() {
        return order;
    }

    public void setOrder(List<DataTablesOrder> order) {
        this.order = order;
    }

    public void addOrder(DataTablesOrder order) {
        this.order.add(order);
    }

    public DataTablesSearch getSearch() {
        return search;
    }

    public void setSearch(DataTablesSearch search) {
        this.search = search;
    }

    public static String decodeUrl(String url) {
        if (null == url) {
            return "";
        }
        String result;
        try {
            result = URLDecoder.decode(url, "UTF-8");
        } catch (Exception e) {
            result = "";
        }

        return result;
    }

    @JsonIgnore
    public static DataTablesRequest fromRequest(HttpServletRequest request) {
        try {
            request.setCharacterEncoding("UTF-8");
        } catch (UnsupportedEncodingException e) {
            // ..
        }
        List<Pattern> patterns = new ArrayList<>();
        patterns.add(Pattern.compile("^([^\\[]+)\\[([^\\]]+)\\]\\[([^\\]]+)\\]\\[([^\\]]+)\\]"));
        patterns.add(Pattern.compile("^([^\\[]+)\\[([^\\]]+)\\]\\[([^\\]]+)\\]"));
        patterns.add(Pattern.compile("^([^\\[]+)\\[([^\\]]+)\\]"));
        patterns.add(Pattern.compile("^([^\\[]+)"));
        DataTablesRequest dr = new DataTablesRequest();

        for (Map.Entry<String, String[]> map : request.getParameterMap().entrySet()) {
            String key = decodeUrl(map.getKey());
            String value = decodeUrl(map.getValue()[0]);
            for (Pattern p : patterns) {
                boolean found = false;
                String keyName = key;
                Matcher columns = p.matcher(key);
                while (columns.find()) {
                    keyName = columns.group(1);
                    found = true;
                    switch (keyName) {
                        case "columns":
                            int num = Integer.valueOf(columns.group(2));
                            DataTablesColumn col = new DataTablesColumn();
                            if (dr.getColumns().size() > num) {
                                col = dr.getColumns().get(num);
                            } else {
                                dr.addColumn(col);
                            }
                            switch (columns.group(3)) {
                                case "data":
                                    col.setData(value);
                                    break;
                                case "name":
                                    if ((null == value || value.equals("")) && (null != col.getData() && !col.getData().equals(""))) {
                                        value = col.getData();
                                    }
                                    col.setName(value);
                                    break;
                                case "searchable":
                                    col.setSearchable(value.equals("true"));
                                    break;
                                case "orderable":
                                    col.setOrderable(value.equals("true"));
                                    break;
                                case "search":
                                    if (columns.group(4).equals("regex")) {
                                        col.getSearch().setRegex(value.equals("true"));
                                    } else if (columns.group(4).equals("value")) {
                                        col.getSearch().setValue(value);
                                    }
                                    break;
                            }
                            break;
                        case "order":
                            int onm = Integer.valueOf(columns.group(2));
                            DataTablesOrder order = new DataTablesOrder();
                            if (dr.getOrder().size() > onm) {
                                order = dr.getOrder().get(onm);
                            } else {
                                dr.addOrder(order);
                            }
                            switch (columns.group(3)) {
                                case "column":
                                    order.setColumn(Long.valueOf(value));
                                    break;
                                case "dir":
                                    order.setDir(value.toLowerCase());
                                    break;
                            }
                            break;
                        case "search":
                            if (columns.group(2).equals("regex")) {
                                dr.getSearch().setRegex(value.equals("true"));
                            } else if (columns.group(2).equals("value")) {
                                dr.getSearch().setValue(value);
                            }
                            break;
                        case "draw":
                            dr.setDraw(Long.valueOf(value));
                            break;
                        case "length":
                            dr.setLength(Long.valueOf(value));
                            break;
                        case "start":
                            dr.setStart(Long.valueOf(value));
                            break;
                        default:
                            found = false;
                            break;
                    }
                }

                if (found) {
                    break;
                }
            }
        }

        return dr;
    }
}
