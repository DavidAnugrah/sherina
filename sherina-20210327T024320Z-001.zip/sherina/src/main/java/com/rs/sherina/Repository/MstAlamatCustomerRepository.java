package com.rs.sherina.Repository;

import com.rs.sherina.Entity.MstAlamatCustomer;
import com.rs.sherina.Entity.MstCustomerB2b;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import javax.transaction.Transactional;
import java.util.List;

public interface MstAlamatCustomerRepository extends PagingAndSortingRepository<MstAlamatCustomer, Long> {
    MstAlamatCustomer findOneById(Long id);

    List<MstAlamatCustomer> findByMstCustomerB2bOrderByIdDesc(MstCustomerB2b customer);

    List<MstAlamatCustomer> findByMstCustomerB2bAndIsTempOrderByIdDesc(MstCustomerB2b customer, Boolean isTemp);

    @Modifying
    @Transactional
    @Query("UPDATE MstAlamatCustomer c SET c.isTemp = false WHERE c.isTemp IS NULL")
    void fixingTemporary();
}
