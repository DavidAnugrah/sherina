package com.rs.sherina.Model;

import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

public class ApiUser {

    @NotNull(message = "Kode customer tidak boleh kosong")
    private String code;

    @NotNull(message = "Nama customer tidak boleh kosong")
    private String name;

    @NotNull(message = "Alamat invoice customer tidak boleh kosong")
    private String address;

    @Pattern(regexp = "(^[0-9]{8,17})", message = "Nomor telpon harus terdiri dari 8 sampai 17 karakter")
    private String phone;

    private String fax;

    private String url;

    @NotNull(message = "Email user wajib diisi")
    private String email;

    @NotNull(message = "password harus diisi")
    @Length(min = 8, message = "Minimal jumlah karakter untuk password adalah 8 karakter")
    private String password;

    @NotNull(message = "No npwp customer tidak boleh kosong")
    private String npwp;

    @NotNull(message = "Nama npwp customer tidak boleh kosong")
    private String npwpName;

    private String contactName;

    private String contactEmail;

    private String contactPhone;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNpwp() {
        return npwp;
    }

    public void setNpwp(String npwp) {
        this.npwp = npwp;
    }

    public String getNpwpName() {
        return npwpName;
    }

    public void setNpwpName(String npwpName) {
        this.npwpName = npwpName;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public String getContactPhone() {
        return contactPhone;
    }

    public void setContactPhone(String contactPhone) {
        this.contactPhone = contactPhone;
    }
}
