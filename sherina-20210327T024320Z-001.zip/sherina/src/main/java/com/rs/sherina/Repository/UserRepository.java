package com.rs.sherina.Repository;

import com.rs.sherina.Entity.MstUser;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.Optional;

import javax.transaction.Transactional;

public interface UserRepository extends PagingAndSortingRepository<MstUser, Long> {
    Optional<MstUser> findById(Long id);

    MstUser findOneByUsername(String username);

    Optional<MstUser> findByUsername(String username);

    @Query("SELECT COUNT(u) FROM MstUser u WHERE u.username = ?1 AND u.password = ?2")
    Long findTotalByUsernameAndPassword(String username, String password);

    @Query("SELECT u.name FROM MstUser u WHERE u.username = ?1")
    String getNameByUsername(String username);

    @Query(value = "SELECT u.nama FROM mst_user u WHERE u.username = ?1 LIMIT 1", nativeQuery = true)
    String getNameByUsernameNative(String username);

    @Query(value = "SELECT u.kode_akun FROM mst_user u WHERE u.username = ?1 LIMIT 1", nativeQuery = true)
    String getKodeAkunByUsername(String username);
    
    @Query(value ="select id from mst_user where username=?1 LIMIT 1",nativeQuery=true)
    String checkUser(String username);
    
    @Query(value ="select mcus_sts_aktif from mst_customer wheren mcus_nama=?1 LIMIT 1",nativeQuery= true)
    String getStatusCustomer(String username);
    
    @Modifying
    @Transactional
    @Query(value = "DELETE FROM mst_user c WHERE c.username = ?1", nativeQuery = true)
    void forceDeleteByPicUsername(String username);

    @Modifying
    @Transactional
    @Query(value = "update mst_user set password =?1 where username=?2" , nativeQuery= true )
    int updateUser(String password , String username);
    
}
