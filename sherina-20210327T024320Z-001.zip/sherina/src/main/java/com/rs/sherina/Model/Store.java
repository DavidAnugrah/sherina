package com.rs.sherina.Model;

@SuppressWarnings("SpellCheckingInspection")
public class Store {
    private String storeCode;

    private String storeName;

    private String subDistrictLogId;

    private String address1;

    private String address2;

    private String phoneNumber;

    private Integer postcode;

    private Double latitude;

    private Double longtitude;

    public String getStoreCode() {
        return storeCode;
    }

    public void setStoreCode(String storeCode) {
        this.storeCode = storeCode;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public Integer getPostcode() {
        return postcode;
    }

    public void setPostcode(Integer postcode) {
        this.postcode = postcode;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public Double getLongtitude() {
        return longtitude;
    }

    public void setLongtitude(Double longtitude) {
        this.longtitude = longtitude;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public String getSubDistrictLogId() {
        return subDistrictLogId;
    }

    public void setSubDistrictLogId(String subDistrictLogId) {
        this.subDistrictLogId = subDistrictLogId;
    }
}
