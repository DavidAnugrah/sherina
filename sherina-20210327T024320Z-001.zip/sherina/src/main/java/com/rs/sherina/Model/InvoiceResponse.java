package com.rs.sherina.Model;

import java.util.ArrayList;
import java.util.List;

public class InvoiceResponse {

    private List<Invoice> detail = new ArrayList<>();

    public List<Invoice> getDetail() {
        return detail;
    }

    public void setDetail(List<Invoice> detail) {
        this.detail = detail;
    }
}
