package com.rs.sherina.Model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Set;

public class HistoryResponse {

    @JsonProperty("detail")
    private Set<History> detail;

    public Set<History> getDetail() {
        return detail;
    }

    public void setDetail(Set<History> detail) {
        this.detail = detail;
    }
}
