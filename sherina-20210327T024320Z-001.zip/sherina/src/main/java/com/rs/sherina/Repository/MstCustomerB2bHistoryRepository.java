package com.rs.sherina.Repository;

import com.rs.sherina.Entity.MstCustomerB2bHistory;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface MstCustomerB2bHistoryRepository extends PagingAndSortingRepository<MstCustomerB2bHistory, Long> {
}
