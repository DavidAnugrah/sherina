package com.rs.sherina.Controller;

import com.rs.sherina.Entity.MstCustomerB2b;
import com.rs.sherina.Entity.MstUser;
import com.rs.sherina.Extension.annotation.Route;
import com.rs.sherina.Model.InvoiceDetail;
import com.rs.sherina.Model.InvoiceDetailResponse;
import com.rs.sherina.Model.InvoiceResponse;
import com.rs.sherina.Model.Role;
import com.rs.sherina.Repository.MstCustomerB2bRepository;
import com.rs.sherina.Repository.UserRepository;
import com.rs.sherina.Service.ShipmentBooking;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import javax.servlet.http.HttpServletRequest;
import java.security.Principal;
import java.util.Calendar;

@RestController
@Secured({Role.ROLE_USER, Role.ROLE_ADMIN})
public class InvoiceController {

    private static final Logger logger = LoggerFactory.getLogger(InvoiceController.class);

    @Value("${sherina.api.service}")
    private String serviceUrl;

    @Value("${spring.profiles.active:production}")
    private String environment;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private MstCustomerB2bRepository customerRepository;

    @Route("/invoice")
    @ResponseBody
    public InvoiceResponse getInvoicesAction(HttpServletRequest request, Principal principal) {
        String status;
        try {
            status = request.getParameter("status");
            if (null == status) {
                status = "all";
            }
        } catch (Exception e) {
            status = "all";
        }

        String statusCode = status.toUpperCase();

        MstCustomerB2b customer = customerRepository.findOneByUsername(principal.getName());
        RestTemplate rest = ShipmentBooking.getTemplate();
        InvoiceResponse response;
        int year = Calendar.getInstance().get(Calendar.YEAR);
        int month = Calendar.getInstance().get(Calendar.MONTH);
        String month2 = String.format("%02d", month);
        try {
            if (!environment.equals("production")) {
                month2 = "03";
            }
            MultiValueMap<String, String> payload = new LinkedMultiValueMap<>();
            payload.add("tipe", "e");
            payload.add("response", "json");
            payload.add("sip_kode", customer.getId());
            payload.add("tahun", year + "");
            payload.add("bulan", month2);
            if (!statusCode.equals("ALL")) {
                payload.add("paid_status", status.toUpperCase());
            }

            response = rest.postForObject(serviceUrl, ShipmentBooking.getHttpHeaders(payload), InvoiceResponse.class);
        } catch (Exception e) {
            response = new InvoiceResponse();
            logger.error(e.getMessage());
        }

        return response;
    }

    @Route("/invoice/{id}/detail")
    @ResponseBody
    public InvoiceDetailResponse getInvoiceDetailAction(@PathVariable("id") String id) {
        InvoiceDetailResponse response;

        try {
            MultiValueMap<String, String> payload = new LinkedMultiValueMap<>();
            payload.add("tipe", "f");
            payload.add("response", "json");
            payload.add("invoice", id);

            response = ShipmentBooking.getTemplate().postForObject(
                    serviceUrl,
                    ShipmentBooking.getHttpHeaders(payload),
                    InvoiceDetailResponse.class);

            // add dummy data
            if (response.getDetails().size() < 1 && environment.equals("local")) {
                InvoiceDetail detail = new InvoiceDetail();
                detail.setDate("2018-01-01");
                detail.setReceiver("John doe");
                detail.setShipper("Billy");
                detail.setBiaya(1000000.0);
                detail.setService("RGSDD");
                detail.setWaybill("09182309180239801");
                detail.setWeight(9.0);

                response.getDetails().add(detail);
            }
        } catch (Exception e) {
            response = new InvoiceDetailResponse();
            logger.error(e.getMessage());
        }

        return response;
    }
}
