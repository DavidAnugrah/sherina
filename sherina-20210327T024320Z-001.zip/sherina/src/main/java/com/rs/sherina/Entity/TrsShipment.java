package com.rs.sherina.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonView;
import com.rs.sherina.Model.StatusResponse;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.util.StringUtils;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import java.text.SimpleDateFormat;
import java.util.Date;

@Entity
@Table(name = "trs_shipment")
@SuppressWarnings("SpellCheckingInspection")
public class TrsShipment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonView(DataTablesOutput.View.class)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "tsh_mcus_kode")
    @JsonIgnore
    private MstCustomerB2b mstCustomerB2b;

    @Transient
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "tsh_kode_alamat_kirim")
//    @JsonIgnore
    private MstAlamatCustomer address;

    @Transient
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "tsh_kode_alamat_pickup")
//    @JsonIgnore
    private MstAlamatPickup pickup;

    @Transient
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "tsh_kode_alamat_delivery")
    @JsonView(DataTablesOutput.View.class)
//    @JsonIgnore
    private MstAlamatDelivery delivery;

    @Column(length = 20)
    @JsonView(DataTablesOutput.View.class)
    private String tshPk;

    @JsonView(DataTablesOutput.View.class)
    private String tshAwb;

    @JsonView(DataTablesOutput.View.class)
    private String tshMproKode;

    @JsonView(DataTablesOutput.View.class)
    private String tshOrgType;

    @JsonView(DataTablesOutput.View.class)
    private String tshDestType;

    private String tshAlamatPickup;

    private String tshAlamatDelivery;

    @JsonView(DataTablesOutput.View.class)
    private String tshNamaPengirim;

    @JsonView(DataTablesOutput.View.class)
    private String tshNamaPenerima;

    @JsonView(DataTablesOutput.View.class)
    @Column(name = "tsh_alamat_kirim")
    private String tshAlamatPengirim;

    @JsonView(DataTablesOutput.View.class)
    private String tshAlamatPenerima;

    @JsonView(DataTablesOutput.View.class)
    private String tshGroupPenerima;

    private String tshNamaStore;
    private String tshAlamatStore;
    private String tshKodeStore;
    private String tshTelponStore;
    private String tshKodePosStore;

    private String tshMprvKodePenerima;
    private String tshMctyKodePenerima;

    private String tshMkcmKodePengirim;
    private String tshMkcmKodePenerima;

    private String tshMkcmNamaKotaPengirim;
    private String tshMkcmNamaKotaPenerima;

    private String tshLatLongPengirim;
    private String tshLatLongPenerima;

    private String tshTelponPengirim;
    private String tshTelponPenerima;

    private String tshKodePosPengirim;
    private String tshKodePosPenerima;

    private String tshEmailPengirim;
    private String tshEmailPenerima;

    private Double tshBeratAktual = 0.0;

    private Double tshPanjang = 0.0;

    private Double tshLebar = 0.0;

    private Double tshTinggi = 0.0;

    private Double tshQty = 0.0;

    private Double tshBeratTagih = 0.0;

    private Double tshNilaiBarang = 0.0;

    private Double tshHarga = 0.0;

    private Double tshHargaNet = 0.0;

    private String tshKodeAsuransi;

    private Double tshAsuransiPr = 0.0;

    private Double tshPremi = 0.0;

    private Double tshTotal = 0.0;

    @JsonView(DataTablesOutput.View.class)
    private String tshTransNo;

    private String tshIsiPaket;

    private Double tshCod = 0.0;

    private Boolean tshTemp = true;

    private Long tshLogId;

    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    @JsonView(DataTablesOutput.View.class)
    private Date tshCreated;

    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    private Date tshUpdated;

    @ManyToOne
    @JoinColumn(name = "tsh_create_user")
    @JsonIgnore
    private MstUser userCreator;

    @ManyToOne
    @JoinColumn(name = "tsh_update_user")
    @JsonIgnore
    private MstUser userUpdater;

    @JsonView(DataTablesOutput.View.class)
    private String tshStatus;

    @Transient
    private StatusResponse status;

    public Long getId() {
        return id;
    }

    public MstCustomerB2b getMstCustomerB2b() {
        return mstCustomerB2b;
    }

    public void setMstCustomerB2b(MstCustomerB2b mstCustomerB2b) {
        this.mstCustomerB2b = mstCustomerB2b;
        if (null != mstCustomerB2b) {
            if (null == this.userCreator) {
                this.userCreator = mstCustomerB2b.getUser();
            }

            this.userUpdater = mstCustomerB2b.getUser();
        }
    }

    public String getTshPk() {
        return tshPk;
    }

    public void setTshPk(String tshPk) {
        this.tshPk = tshPk;
    }

    public String getTshAwb() {
        return tshAwb;
    }

    public void setTshAwb(String tshAwb) {
        this.tshAwb = tshAwb;
    }

    public String getTshMproKode() {
        return tshMproKode;
    }

    public void setTshMproKode(String tshMproKode) {
        this.tshMproKode = tshMproKode;
    }

    public String getTshOrgType() {
        return tshOrgType;
    }

    public void setTshOrgType(String tshOrgType) {
        this.tshOrgType = tshOrgType;
    }

    public String getTshDestType() {
        return tshDestType;
    }

    public void setTshDestType(String tshDestType) {
        this.tshDestType = tshDestType;
    }

    public String getTshAlamatPengirim() {
        return tshAlamatPengirim;
    }

    public void setTshAlamatPengirim(String tshAlamatKirim) {
        this.tshAlamatPengirim = tshAlamatKirim;
    }

    public String getTshAlamatPickup() {
        return tshAlamatPickup;
    }

    public void setTshAlamatPickup(String tshAlamatPickup) {
        this.tshAlamatPickup = tshAlamatPickup;
    }

    public String getTshMkcmKodePengirim() {
        return tshMkcmKodePengirim;
    }

    public void setTshMkcmKodePengirim(String tshMkcmKodePengirim) {
        this.tshMkcmKodePengirim = tshMkcmKodePengirim;
    }

    public String getTshMkcmNamaKotaPengirim() {
        return tshMkcmNamaKotaPengirim;
    }

    public void setTshMkcmNamaKotaPengirim(String tshMkcmNamaKotaPengirim) {
        this.tshMkcmNamaKotaPengirim = tshMkcmNamaKotaPengirim;
    }

    public String getTshMkcmNamaKotaPenerima() {
        return tshMkcmNamaKotaPenerima;
    }

    public void setTshMkcmNamaKotaPenerima(String tshMkcmNamaKotaPenerima) {
        this.tshMkcmNamaKotaPenerima = tshMkcmNamaKotaPenerima;
    }

    public String getTshNamaPengirim() {
        return tshNamaPengirim;
    }

    public void setTshNamaPengirim(String tshNamaPengirim) {
        this.tshNamaPengirim = tshNamaPengirim;
    }

    public String getTshTelponPengirim() {
        return tshTelponPengirim;
    }

    public void setTshTelponPengirim(String tshTelponPengirim) {
        this.tshTelponPengirim = tshTelponPengirim;
    }

    public String getTshKodePosPengirim() {
        return tshKodePosPengirim;
    }

    public void setTshKodePosPengirim(String tshKodePosPengirim) {
        this.tshKodePosPengirim = tshKodePosPengirim;
    }

    public String getTshAlamatDelivery() {
        return tshAlamatDelivery;
    }

    public void setTshAlamatDelivery(String tshAlamatDelivery) {
        this.tshAlamatDelivery = tshAlamatDelivery;
    }

    public String getTshNamaPenerima() {
        return tshNamaPenerima;
    }

    public void setTshNamaPenerima(String tshNamaPenerima) {
        this.tshNamaPenerima = tshNamaPenerima;
    }

    public String getTshGroupPenerima() {
        return tshGroupPenerima;
    }

    public void setTshGroupPenerima(String tshGroupPenerima) {
        this.tshGroupPenerima = tshGroupPenerima;
    }

    public String getTshAlamatPenerima() {
        return tshAlamatPenerima;
    }

    public void setTshAlamatPenerima(String tshAlamatPenerima) {
        this.tshAlamatPenerima = tshAlamatPenerima;
    }

    public String getTshMprvKodePenerima() {
        return tshMprvKodePenerima;
    }

    public void setTshMprvKodePenerima(String tshMprvKodePenerima) {
        this.tshMprvKodePenerima = tshMprvKodePenerima;
    }

    public String getTshMctyKodePenerima() {
        return tshMctyKodePenerima;
    }

    public void setTshMctyKodePenerima(String tshMctyKodePenerima) {
        this.tshMctyKodePenerima = tshMctyKodePenerima;
    }

    public String getTshMkcmKodePenerima() {
        return tshMkcmKodePenerima;
    }

    public void setTshMkcmKodePenerima(String tshMkcmKodePenerima) {
        this.tshMkcmKodePenerima = tshMkcmKodePenerima;
    }

    public String getTshLatLongPengirim() {
        return tshLatLongPengirim;
    }

    public void setTshLatLongPengirim(String tshLatLongPengirim) {
        this.tshLatLongPengirim = tshLatLongPengirim;
    }

    public String getTshLatLongPenerima() {
        return tshLatLongPenerima;
    }

    public void setTshLatLongPenerima(String tshLatLongPenerima) {
        this.tshLatLongPenerima = tshLatLongPenerima;
    }

    public String getTshTelponPenerima() {
        return tshTelponPenerima;
    }

    public void setTshTelponPenerima(String tshTelponPenerima) {
        this.tshTelponPenerima = tshTelponPenerima;
    }

    public String getTshKodePosPenerima() {
        return tshKodePosPenerima;
    }

    public void setTshKodePosPenerima(String tshKodePosPenerima) {
        this.tshKodePosPenerima = tshKodePosPenerima;
    }

    public String getTshEmailPenerima() {
        return tshEmailPenerima;
    }

    public void setTshEmailPenerima(String tshEmailPenerima) {
        this.tshEmailPenerima = tshEmailPenerima;
    }

    public String getTshEmailPengirim() {
        return tshEmailPengirim;
    }

    public void setTshEmailPengirim(String tshEmailPengirim) {
        this.tshEmailPengirim = tshEmailPengirim;
    }

    public String getTshNamaStore() {
        return tshNamaStore;
    }

    public void setTshNamaStore(String tshNamaStore) {
        this.tshNamaStore = tshNamaStore;
    }

    public String getTshAlamatStore() {
        return tshAlamatStore;
    }

    public void setTshAlamatStore(String tshAlamatStore) {
        this.tshAlamatStore = tshAlamatStore;
    }

    public String getTshKodePosStore() {
        return tshKodePosStore;
    }

    public void setTshKodePosStore(String tshKodePosStore) {
        this.tshKodePosStore = tshKodePosStore;
    }

    public String getTshKodeStore() {
        return tshKodeStore;
    }

    public void setTshKodeStore(String tshKodeStore) {
        this.tshKodeStore = tshKodeStore;
    }

    public String getTshTelponStore() {
        return tshTelponStore;
    }

    public void setTshTelponStore(String tshTelponStore) {
        this.tshTelponStore = tshTelponStore;
    }

    public Double getTshBeratAktual() {
        return tshBeratAktual;
    }

    public void setTshBeratAktual(Double tshBeratAktual) {
        this.tshBeratAktual = tshBeratAktual;
    }

    public Double getTshPanjang() {
        return tshPanjang;
    }

    public void setTshPanjang(Double tshPanjang) {
        this.tshPanjang = tshPanjang;
    }

    public Double getTshLebar() {
        return tshLebar;
    }

    public void setTshLebar(Double tshLebar) {
        this.tshLebar = tshLebar;
    }

    public Double getTshTinggi() {
        return tshTinggi;
    }

    public void setTshTinggi(Double tshTinggi) {
        this.tshTinggi = tshTinggi;
    }

    public Double getTshQty() {
        return tshQty;
    }

    public void setTshQty(Double tshQty) {
        this.tshQty = tshQty;
    }

    public Double getTshBeratTagih() {
        return tshBeratTagih;
    }

    public void setTshBeratTagih(Double tshBeratTagih) {
        this.tshBeratTagih = tshBeratTagih;
    }

    public Double getTshNilaiBarang() {
        return tshNilaiBarang;
    }

    public void setTshNilaiBarang(Double tshNilaiBarang) {
        this.tshNilaiBarang = tshNilaiBarang;
    }

    public Double getTshHarga() {
        return tshHarga;
    }

    public void setTshHarga(Double tshHarga) {
        this.tshHarga = tshHarga;
    }

    public Double getTshHargaNet() {
        return tshHargaNet;
    }

    public void setTshHargaNet(Double tshHargaNet) {
        this.tshHargaNet = tshHargaNet;
    }

    public String getTshKodeAsuransi() {
        return tshKodeAsuransi;
    }

    public void setTshKodeAsuransi(String tshKodeAsuransi) {
        this.tshKodeAsuransi = tshKodeAsuransi;
    }

    public Double getTshAsuransiPr() {
        return tshAsuransiPr;
    }

    public void setTshAsuransiPr(Double tshAsuransiPr) {
        this.tshAsuransiPr = tshAsuransiPr;
    }

    public Double getTshPremi() {
        return tshPremi;
    }

    public void setTshPremi(Double tshPremi) {
        this.tshPremi = tshPremi;
    }

    public Double getTshTotal() {
        return tshTotal;
    }

    public void setTshTotal(Double tshTotal) {
        this.tshTotal = tshTotal;
    }

    public String getTshTransNo() {
        return tshTransNo;
    }

    public void setTshTransNo(String tshTransNo) {
        this.tshTransNo = tshTransNo;
    }

    public String getTshIsiPaket() {
        return tshIsiPaket;
    }

    public void setTshIsiPaket(String tshIsiPaket) {
        this.tshIsiPaket = tshIsiPaket;
    }

    public Date getTshCreated() {
        return tshCreated;
    }

    public void setTshCreated(Date tshCreated) {
        this.tshCreated = tshCreated;
    }

    public MstAlamatCustomer getAddress() {
        return address;
    }

    public void setAddress(MstAlamatCustomer address) {
        this.address = address;
        if (null != address) {
            if (!StringUtils.isEmpty(address.getMlcuNamaPengirim()))
                setTshNamaPengirim(address.getMlcuNamaPengirim());
            if (!StringUtils.isEmpty(address.getMlcuTelpon()))
                setTshTelponPengirim(address.getMlcuTelpon());
            if (!StringUtils.isEmpty(address.getMlcuKodePos()))
                setTshKodePosPengirim(address.getMlcuKodePos());
            if (!StringUtils.isEmpty(address.getMlcuMkcmKode()))
                setTshMkcmKodePengirim(address.getMlcuMkcmKode());
            if (!StringUtils.isEmpty(address.getMlcuAlamat()))
                setTshAlamatPengirim(address.getMlcuAlamat());
        }
    }

    public MstAlamatPickup getPickup() {
        return pickup;
    }

    public void setPickup(MstAlamatPickup pickup) {
        this.pickup = pickup;

        if (null != pickup) {
            if (!StringUtils.isEmpty(pickup.getMlpiAlamat()))
                setTshAlamatPengirim(pickup.getMlpiAlamat());
            if (!StringUtils.isEmpty(pickup.getMlpiNamaPengirim()))
                setTshNamaPengirim(pickup.getMlpiNamaPengirim());
            if (!StringUtils.isEmpty(pickup.getMlpiTelpon()))
                setTshTelponPengirim(pickup.getMlpiTelpon());
            if (!StringUtils.isEmpty(pickup.getMlpiKodePos()))
                setTshKodePosPengirim(pickup.getMlpiKodePos());
            if (!StringUtils.isEmpty(pickup.getMlpiMkcmKode()))
                setTshMkcmKodePengirim(pickup.getMlpiMkcmKode());
        }
    }

    public MstAlamatDelivery getDelivery() {
        return delivery;
    }

    public void setDelivery(MstAlamatDelivery delivery) {
        this.delivery = delivery;
        if (null != delivery) {
            if (!StringUtils.isEmpty(delivery.getMldeMkcmKode()))
                setTshMkcmKodePenerima(delivery.getMldeMkcmKode());
            if (!StringUtils.isEmpty(delivery.getMldeEmail()))
                setTshEmailPenerima(delivery.getMldeEmail());
            if (!StringUtils.isEmpty(delivery.getMldeAlamat()))
                setTshAlamatPenerima(delivery.getMldeAlamat());
            if (!StringUtils.isEmpty(delivery.getMldeAlamatStore()))
                setTshAlamatPenerima(delivery.getMldeAlamatStore());
            if (!StringUtils.isEmpty(delivery.getMldeKodePos()))
                setTshKodePosPenerima(delivery.getMldeKodePos());
            if (!StringUtils.isEmpty(delivery.getMldeKodePosStore()))
                setTshKodePosPenerima(delivery.getMldeKodePosStore());
            if (!StringUtils.isEmpty(delivery.getMldeNamaPenerima()))
                setTshNamaPenerima(delivery.getMldeNamaPenerima());
            if (!StringUtils.isEmpty(delivery.getMldeNamaPenerimaStore()) && StringUtils.isEmpty(tshNamaPenerima))
                setTshNamaPenerima(delivery.getMldeNamaPenerimaStore());
        }
    }

    @PrePersist
    public void onCreate() {
        this.tshCreated = new Date();
    }

    @Transient
    @JsonProperty("tshCreateFormatted")
    public String getFormattedDate() {
        SimpleDateFormat date = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");

        return date.format(tshCreated);
    }

    public StatusResponse getStatus() {
        return status;
    }

    public void setStatus(StatusResponse status) {
        this.status = status;
    }

    public Double getTshCod() {
        return tshCod;
    }

    public void setTshCod(Double tshCod) {
        this.tshCod = tshCod;
    }

    public Boolean getTshTemp() {
        return tshTemp;
    }

    public void setTshTemp(Boolean tshTemp) {
        this.tshTemp = tshTemp;
    }

    public String getTshStatus() {
        return tshStatus;
    }

    public void setTshStatus(String tshStatus) {
        this.tshStatus = tshStatus;
    }

    public Date getTshUpdated() {
        return tshUpdated;
    }

    public void setTshUpdated(Date tshUpdated) {
        this.tshUpdated = tshUpdated;
    }

    public MstUser getUserCreator() {
        return userCreator;
    }

    public void setUserCreator(MstUser userCreator) {
        this.userCreator = userCreator;
    }

    public MstUser getUserUpdater() {
        return userUpdater;
    }

    public void setUserUpdater(MstUser userUpdater) {
        this.userUpdater = userUpdater;
    }

    public Long getTshLogId() {
        return tshLogId;
    }

    public void setTshLogId(Long tshLogId) {
        this.tshLogId = tshLogId;
    }
}
