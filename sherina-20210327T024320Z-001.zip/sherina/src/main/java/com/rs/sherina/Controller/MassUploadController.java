package com.rs.sherina.Controller;

import com.rs.sherina.Entity.MstAlamatDelivery;
import com.rs.sherina.Entity.MstCustomerB2b;
import com.rs.sherina.Entity.MstGroupDelivery;
import com.rs.sherina.Entity.TrsShipment;
import com.rs.sherina.Extension.annotation.Route;
import com.rs.sherina.Model.DeliveryCSVData;
import com.rs.sherina.Model.Role;
import com.rs.sherina.Model.Store;
import com.rs.sherina.Model.TempShipment;
import com.rs.sherina.Repository.MstAlamatDeliveryRepository;
import com.rs.sherina.Repository.MstCustomerB2bRepository;
import com.rs.sherina.Repository.MstGroupDeliveryRepository;
import com.rs.sherina.Repository.TrsShipmentRepository;
import com.rs.sherina.Repository.UserRepository;
import com.rs.sherina.Service.StoreFinder;
import com.univocity.parsers.common.processor.BeanListProcessor;
import com.univocity.parsers.csv.CsvParser;
import com.univocity.parsers.csv.CsvParserSettings;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jms.JmsProperties.DeliveryMode;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.transaction.Transactional;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

@RestController
@Secured({Role.ROLE_USER})
@Route("/upload")
@SuppressWarnings("all")
public class MassUploadController {
    private static final Logger logger = LoggerFactory.getLogger(MassUploadController.class);

    @Autowired
    private MstAlamatDeliveryRepository mstAlamatDeliveryRepository;

    @Autowired
    private TrsShipmentRepository shipmentRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private MstCustomerB2bRepository customerRepository;
    
    @Autowired
    private MstGroupDeliveryRepository groupDeliveryRepository;

    @Value("${spring.profiles.active}")
    private String profilesActive;

    @Value("${sherina.temp-dir}")
    private String tmpDir;

    @Autowired
    private StoreFinder storeFinder;

    @Route("/delivery")
    @ResponseBody
    @Transactional
    public List<DeliveryCSVData> receiveDeliveryDataAction(@RequestParam("file") MultipartFile upload, Principal principal) {
        MstCustomerB2b customer = customerRepository.findOneByUsername(principal.getName());
        File file = this.multipartToFile(upload, "/upload/delivery");
        List<DeliveryCSVData> data = new ArrayList<>();

        try {
            BeanListProcessor<DeliveryCSVData> processor = new BeanListProcessor<>(DeliveryCSVData.class);

            CsvParserSettings settings = new CsvParserSettings();
            settings.setProcessor(processor);
            settings.setHeaderExtractionEnabled(true);
            CsvParser parser = new CsvParser(settings);
            parser.parse(file);
            data = processor.getBeans();

            for (DeliveryCSVData row : data) {
                MstAlamatDelivery mstAlamatDelivery = new MstAlamatDelivery();
                mstAlamatDelivery.setMldeKodeAlamat(row.getCode());
                mstAlamatDelivery.setMldeAlamat(row.getAddress());
                mstAlamatDelivery.setMldeNamaPenerima(row.getName());
                mstAlamatDelivery.setMldeTelpon(row.getPhone());
                mstAlamatDelivery.setMldeMkcmKota(row.getCity());
                mstAlamatDelivery.setMstCustomerB2b(customer);
                mstAlamatDeliveryRepository.save(mstAlamatDelivery);
            }

            clear(file);
            logger.info("Success: POST|UPLOAD /upload/delivery");
        } catch (Exception e) {
            logger.error("Error: POST|UPLOAD /upload/delivery success but an error occurred while saving data to database", e);
        }

        return data;
    }

    @PostMapping("/delivery2")
    @ResponseBody
    @Transactional
    public List uploadDeliveryAction(@RequestParam("file") MultipartFile upload, Principal principal) throws IOException {
        MstCustomerB2b customer = customerRepository.findOneByUsername(principal.getName());
        List<DeliveryCSVData> data = new ArrayList<>();
          File file = multipartToFile(upload);
		try {
              Workbook excel = WorkbookFactory.create(file);
              Sheet sheet = excel.getSheetAt(1);
              for (Row row : sheet) {
                  if (row.getRowNum() >= 1) {
                	  if (null == row.getCell(0)) {
                          break;
                      }
                       DeliveryCSVData item = new DeliveryCSVData();
                       item.setCode("C."+randomString(6,true));
                       item.setName(getCellValue(row, 0));
                       item.setAddress(getCellValue(row, 1));
                       item.setPhone(getCellValue(row, 2));
//                       item.setPostcode(getCellValue(row, 3));
//                       item.setGroupcode(getCellValue(row, 3));
                       item.setPrvcode(getCellValue(row, 3));
                       item.setCitycode(getCellValue(row, 4));
                       item.setCityname(getCellValue(row, 5));
                       item.setKcmtcode(getCellValue(row, 6));
                       item.setKcmtname(getCellValue(row, 7));
                                              
//                      MstAlamatDelivery mstAlamatDelivery = new MstAlamatDelivery();
//                      mstAlamatDelivery.setMldeKodeAlamat(item.getCode());
//                      mstAlamatDelivery.setMldeNamaPenerima(item.getName());
//                      mstAlamatDelivery.setMldeAlamat(item.getAddress());
//                      mstAlamatDelivery.setMldeTelpon(item.getPhone());
//                      mstAlamatDelivery.setMldeMkcmKode(item.getKcmtcode());
//                      mstAlamatDelivery.setMldeMkcmKota(item.getKcmtname());
////                      mstAlamatDelivery.setMldeKodePos(item.getPostcode());
//                      mstAlamatDelivery.setMldeMctyKode(item.getCitycode());
//                      mstAlamatDelivery.setMldeMprvKode(item.getPrvcode());
//                      mstAlamatDelivery.setMstCustomerB2b(customer);
//                      mstAlamatDeliveryRepository.save(mstAlamatDelivery);
                      data.add(item);
                    
                  }
              }
              excel.close();
              clear(file);
              Collections.emptyList();

              logger.info("Success: POST|UPLOAD /upload/delivery2");
        } catch (Exception e) {
            logger.error("Error: POST|UPLOAD /upload/delivery2 success but an error occurred while saving data to database", e);
        }

         return data;
    }
    
    @PostMapping("/uploadSubmit")
    @ResponseBody
    @Transactional
    public Set<DeliveryCSVData> uploadSubmitDeliveryAction(@RequestBody(required = false)Set<DeliveryCSVData> data, Principal principal) throws IOException {
        MstCustomerB2b customer = customerRepository.findOneByUsername(principal.getName());
      try {
    	  
         for(DeliveryCSVData deliveryCSVData:data) {
        	
        	MstAlamatDelivery mstAlamatDelivery = new MstAlamatDelivery();

  		  mstAlamatDelivery.setMldeKodeAlamat(deliveryCSVData.getCode());
  		  mstAlamatDelivery.setMldeNamaPenerima(deliveryCSVData.getName());
  		  mstAlamatDelivery.setMldeAlamat(deliveryCSVData.getAddress());
  		  mstAlamatDelivery.setMldeTelpon(deliveryCSVData.getPhone());
  		  mstAlamatDelivery.setMldeMkcmKode(deliveryCSVData.getKcmtcode());
  		  mstAlamatDelivery.setMldeMkcmKota(deliveryCSVData.getKcmtname());
  		  mstAlamatDelivery.setMldeMctyKode(deliveryCSVData.getCitycode());
  		  mstAlamatDelivery.setMldeMprvKode(deliveryCSVData.getPrvcode()); 
  	 	  mstAlamatDelivery.setMstCustomerB2b(customer);  
  	 	  mstAlamatDeliveryRepository.save(mstAlamatDelivery);
          
         }
      }catch (Exception e) {
    	  data =Collections.emptySet();
    	    logger.error("Error: POST|UPLOAD /upload/uploadSubmit success but an error occurred while saving data to database", e);
	}
      return data;
    }

    @Route("/shipment")
    @ResponseBody
    @Transactional
    public Set<MstAlamatDelivery> shipmentAction(@RequestParam("file") MultipartFile upload, Principal principal) {
        MstCustomerB2b customer = customerRepository.findOneByUsername(principal.getName());
        File file = this.multipartToFile(upload, "/upload/shipment");
        Set<MstAlamatDelivery> deliveries = new HashSet<>();

        try {
            Workbook excel = WorkbookFactory.create(file);
            Sheet sheet = excel.getSheetAt(0);
            for (Row row : sheet) {
                if (row.getRowNum() >= 1) {
                    if (null == row.getCell(0)) {
                        break;
                    }
                    String name = row.getCell(0).getStringCellValue();
                    String address = row.getCell(1).getStringCellValue();
                    String code = row.getCell(2).getStringCellValue();
                    String postalCode = row.getCell(3).getStringCellValue();
                    String phone = row.getCell(4).getStringCellValue();
                    Double berat = row.getCell(5).getNumericCellValue();
                    Double tinggi = row.getCell(6).getNumericCellValue();
                    Double panjang = row.getCell(7).getNumericCellValue();
                    Double lebar = row.getCell(8).getNumericCellValue();
                    Double nominal = row.getCell(9).getNumericCellValue();
                    String asuransi = row.getCell(10).getStringCellValue();
                    String isi = row.getCell(11).getStringCellValue();

                    TempShipment tempShipment = new TempShipment();
                    tempShipment.setBerat(berat);
                    tempShipment.setTinggi(tinggi);
                    tempShipment.setLebar(lebar);
                    tempShipment.setPanjang(panjang);
                    tempShipment.setNominal(nominal);
                    tempShipment.setAsuransi(asuransi);
                    tempShipment.setIsi(isi);

                    MstAlamatDelivery delivery = new MstAlamatDelivery();
                    delivery.setMldeNamaPenerima(name);
                    delivery.setMldeKodePos(postalCode);
                    delivery.setMldeAlamat(address);
                    delivery.setMldeTelpon(phone);
                    delivery.setMldeMkcmKode(code);
                    delivery.setMldeKodeAlamat("C." + this.randomString(7));
                    delivery.setMstCustomerB2b(customer);

                    deliveries.add(delivery);
                    mstAlamatDeliveryRepository.save(delivery);

                    delivery.setTempShipment(tempShipment);
                }
            }
            excel.close();
            clear(file);

        } catch (InvalidFormatException e) {
            deliveries = Collections.emptySet();
            logger.error("Error: POST|UPLOAD /upload/shipment", e);
        } catch (IOException e) {
            deliveries = Collections.emptySet();
            logger.error("Error: POST|UPLOAD /upload/shipment", e);
        }


        return deliveries;
    }

    @PostMapping("/shipment2")
    @ResponseBody
    @Transactional
    public Set<TrsShipment> uploadShipmentAction(@RequestParam("file") MultipartFile upload,
                                                 @RequestParam(value = "type", required = false) String type,
                                                 Principal principal) {
        storeFinder.validateCache();
        MstCustomerB2b customer = customerRepository.findOneByUsername(principal.getName());

        Set<TrsShipment> shipments = new HashSet<>();
        File file = multipartToFile(upload);
        String transNo = randomString(7, true);

        String orgType = null;
        String destType = null;
        if (!StringUtils.isEmpty(type)) {
            String[] s = type.split("2");
            if (s.length == 2) {
                orgType = "s".equalsIgnoreCase(s[0]) ? "store" : "door";
                destType = "s".equalsIgnoreCase(s[1]) ? "store" : "door";
            }
        }
        try {
            Workbook excel = WorkbookFactory.create(file);
            Sheet sheet = excel.getSheetAt(1);
            for (Row row : sheet) {
                if (row.getRowNum() >= 1) {
                    TrsShipment shipment = new TrsShipment();
                    String first = getCellValue(row, 0);
                    if (null == first || first.equals("")) {
                        continue;
                    }

                    try {
                        Double nilai = row.getCell(19).getNumericCellValue();
                        if (nilai > 0) {
                            shipment.setTshNilaiBarang(nilai);
                            shipment.setTshPremi(0.25);
                            shipment.setTshAsuransiPr(nilai * shipment.getTshPremi() / 100);
                        }
                    } catch (Exception e) {
                        // ..
                    }

                    MstAlamatDelivery delivery = new MstAlamatDelivery();
                    delivery.setMldeKodeAlamat("C." + randomString(6, true));
                    delivery.setMldeNamaPenerima(getCellValue(row, 0));
                    delivery.setMldeAlamat(getCellValue(row, 2));
                    delivery.setMldeTelpon(getCellValue(row, 9));
                    delivery.setMldeMkcmKode(getCellValue(row, 7));
                    delivery.setMldeMkcmKota(getCellValue(row, 8));
                    delivery.setMldeKodePos(getCellValue(row, 3));
                    delivery.setMldeMctyKode(getCellValue(row, 5));
                    delivery.setMldeMprvKode(getCellValue(row, 4));
                    delivery.setMldeKodeStore(getCellValue(row, 20));
                    delivery.setIsTemp(true);
                    delivery.setMstCustomerB2b(customer);
                    if (!StringUtils.isEmpty(delivery.getMldeKodeStore())) {
                        Store store = storeFinder.findByCode(delivery.getMldeKodeStore());
                        if (null != store) {
                            delivery.setMldeAlamatStore(store.getAddress1() + ", " + store.getAddress2());
                            if (null != store.getPostcode()) {
                                delivery.setMldeKodePosStore(Long.toString(store.getPostcode()));
                            } else {
                                delivery.setMldeKodePosStore(delivery.getMldeKodePos());
                            }

                            if (StringUtils.isEmpty(delivery.getMldeKodePosStore())) {
                                delivery.setMldeKodePosStore("00000");
                            }
                        } else {
                            delivery.setMldeAlamatStore(delivery.getMldeAlamat());
                            delivery.setMldeKodePosStore(delivery.getMldeKodePosStore());
                        }
                    }

                    shipment.setDelivery(delivery);

                    shipment.setTshQty(1.0);
                    shipment.setTshIsiPaket(getCellValue(row, 10));
                    shipment.setTshBeratAktual((Double) getCellValue(row, 14, Double.class));
                    shipment.setTshBeratTagih((Double) getCellValue(row, 14, Double.class));
                    shipment.setTshPanjang((Double) getCellValue(row, 15, Double.class));
                    shipment.setTshLebar((Double) getCellValue(row, 16, Double.class));
                    shipment.setTshTinggi((Double) getCellValue(row, 17, Double.class));
                    shipment.setTshCod((Double) getCellValue(row, 18, Double.class));
                    shipment.setMstCustomerB2b(customer);
                    shipment.setTshCreated(new Date());
                    shipment.setTshMkcmKodePenerima(getCellValue(row, 7));
                    shipment.setTshMprvKodePenerima(getCellValue(row, 4));
                    shipment.setTshKodePosPenerima(getCellValue(row, 3));
                    shipment.setTshMctyKodePenerima(getCellValue(row, 5));
                    shipment.setTshNamaPenerima(getCellValue(row, 0));
                    shipment.setTshAlamatPenerima(getCellValue(row, 2));
                    shipment.setTshTelponPenerima(getCellValue(row, 9));
                    shipment.setTshMproKode(getCellValue(row, 11));
                    shipment.setTshTransNo(transNo);
                    shipment.setTshAlamatDelivery(delivery.getMldeAlamat());

                    shipment.setTshOrgType(orgType);
                    shipment.setTshDestType(destType);

                    calculateShipment(shipment);

                    mstAlamatDeliveryRepository.save(delivery);
                    shipmentRepository.save(shipment);

                    shipments.add(shipment);
                }
            }
            excel.close();
            clear(file);

        } catch (InvalidFormatException e) {
            shipments = Collections.emptySet();
            logger.error("Error: POST|UPLOAD /upload/shipment2", e);
        } catch (IOException e) {
            shipments = Collections.emptySet();
            logger.error("Error: POST|UPLOAD /upload/shipment2", e);
        }

        return shipments;
    }

    private void calculateShipment(TrsShipment shipment) {
        Double premi = 0.0025;
        String name = shipment.getTshMproKode();
        Double hargaLayanan = shipment.getTshHarga();
        Double parameterHargaService = 6000.0;
        if (name.equalsIgnoreCase("ECS")) {
            parameterHargaService = 4000.0;
        }

        Double totalBerat = shipment.getTshBeratAktual();
        Double hargaBarang = 0.0;
        if (shipment.getTshAsuransiPr() > 0) {
            hargaBarang = shipment.getTshNilaiBarang();
            if (null == hargaBarang) {
                hargaBarang = 0.0;
            }
        }

        try {
            long beratTagih = Math.round((
                    shipment.getTshPanjang() * shipment.getTshLebar() * shipment.getTshTinggi()
            ) / parameterHargaService);
            Double bt = Double.longBitsToDouble(beratTagih);
            shipment.setTshBeratTagih(bt);
        } catch (Exception e) {
            // ..
        }

        if (null != shipment.getTshBeratTagih() && shipment.getTshBeratTagih() > 0.0) {
            totalBerat = shipment.getTshBeratTagih();
        }

        if (hargaLayanan < 0.0 || totalBerat < 0.0) {
            shipment.setTshTotal(0.0);
            shipment.setTshHargaNet(0.0);
        } else {
            shipment.setTshTotal((totalBerat * hargaLayanan) + (hargaBarang * premi));
        }

        shipment.setTshAsuransiPr((hargaBarang * premi));
        shipment.setTshPremi(premi);
    }

    private String getCellValue(Row row, int index) {
        return (String) getCellValue(row, index, String.class);
    }

    @SuppressWarnings("deprecation")
    private Object getCellValue(Row row, int index, Class className) {
        String value = null;
        DataFormatter formatter = new DataFormatter();
        try {
            Cell cell = row.getCell(index);
            if (cell.getCellType() == Cell.CELL_TYPE_FORMULA && cell.getCachedFormulaResultType() == Cell.CELL_TYPE_STRING) {
                cell.getCachedFormulaResultType();
                value = cell.getStringCellValue();
            } else {
                value = formatter.formatCellValue(cell);
            }
        } catch (Exception e) {
            value = "";
        }

        if (className == String.class) {
            return value;
        } else if (className == Integer.class) {
            return Integer.valueOf(!StringUtils.isEmpty(value) ? value : "0");
        } else if (className == Double.class) {
            return Double.valueOf(!StringUtils.isEmpty(value) ? value : "0.0");
        }

        return value;
    }

    private File multipartToFile(MultipartFile upload, String routeName) {
        String base = "";
        if (profilesActive != null && profilesActive.equals("production")) {
            base = tmpDir;
        }

        logger.info(String.format("Trying upload file: %s", upload.getOriginalFilename()));

        File file = new File(base + upload.getOriginalFilename());

        try {
            logger.info(String.format("Saving uploaded file to: '%s'", file.getAbsolutePath()));
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(upload.getBytes());
            fos.close();
        } catch (IOException e) {
            logger.error(String.format("Error: POST|UPLOAD %s", routeName), e);
        }

        return file;
    }

    private File multipartToFile(MultipartFile upload) {
        return multipartToFile(upload, "/upload");
    }

    private void clear(File file) {
        try {
            Files.deleteIfExists(Paths.get(file.getAbsolutePath()));
            logger.info("Trying clear file: " + file.getAbsolutePath());
        } catch (IOException e) {
            logger.error("Error: Cannot clear the file", e);
        }
    }

    private String randomString(int size) {
        return randomString(size, false);
    }

    private String randomString(int size, boolean numberOnly) {
        String saltChars = "1234567890";
        if (!numberOnly) {
            saltChars += "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        }
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < size) {
            int index = (int) (rnd.nextFloat() * saltChars.length());
            salt.append(saltChars.charAt(index));
        }

        return salt.toString();
    }
}
