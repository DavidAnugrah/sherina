package com.rs.sherina.Controller;
import com.rs.sherina.Extension.annotation.Route;
import com.rs.sherina.Model.CityResponse;
import com.rs.sherina.Model.PostCodeResponse;
import com.rs.sherina.Model.Store;
import com.rs.sherina.Model.StoreDistrictResponse;
import com.rs.sherina.Model.StoreNmsResponse;
import com.rs.sherina.Model.StoreResponse;
import com.rs.sherina.Service.StoreFinder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;

@RestController
public class LocationController {

    private final static Logger logger = LoggerFactory.getLogger(LocationController.class);

    @Value("${spring.profiles.active}")
    private String environment;

    @Value("${sherina.api.cities}")
    private String citiesUrl;

    @Value("${sherina.api.cities2}")
    private String cities2Url;

    @Value("${sherina.api.store-province}")
    private String storeProvinceUrl;

    @Value("${sherina.api.store-city}")
    private String storeCityUrl;

    @Value("${sherina.api.store-district}")
    private String storeDistrictUrl;

    @Value("${sherina.api.store}")
    private String storeUrl;
    
    @Value("${sherina.api.postalcode}")
    private String postalcodeUrl;
    
    @Value("${sherina.auth.store-user}")
    private String storeTokenUser;

    @Value("${sherina.auth.store-pass}")
    private String storeTokenPass;

    @Value("${sherina.auth.store-user-key}")
    private String storeTokenUserKey;

    @Value("${sherina.auth.store-pass-key}")
    private String storeTokenPassKey;

    @Route("/city")
    @ResponseBody
    public CityResponse cityAction(HttpServletRequest request) {
        String penerima = request.getParameter("penerima");
        Boolean receiver = penerima != null && penerima.equals("true");
        String url = citiesUrl;
        if (receiver) {
            url = cities2Url;
        }
        CityResponse response = new CityResponse();
        try {
            response = getTemplate().getForObject(url, CityResponse.class);
            logger.info("Success: GET /city");
        } catch (Exception e) {
            logger.error("Error: GET /city", e);
        }

        return response;
    }
    
    @Route("/postcode")
    @ResponseBody
    public PostCodeResponse getpostAction(@RequestParam(value = "kodepos", required = false) String kodepos) {
        return getpostcodebyCity(kodepos);
    }
    
    private PostCodeResponse getpostcodebyCity(String kodepos) {
    	PostCodeResponse response = new PostCodeResponse();
        String url = String.format(postalcodeUrl,kodepos);
        try {
            ResponseEntity<PostCodeResponse> res = getTemplate().exchange(url, HttpMethod.GET,
                    getHttpHeaders(), PostCodeResponse.class);
            response = res.getBody();
            logger.error("Success : response postcode");
        } catch (Exception e) {
            logger.error("Error : response postcode",e);
        }

        return response;
    }

    

    private RestTemplate getTemplate() {
        RestTemplate rest = new RestTemplate();
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        List<MediaType> mediaTypes = new ArrayList<>();

        mediaTypes.add(MediaType.APPLICATION_JSON_UTF8);
        mediaTypes.add(MediaType.APPLICATION_JSON);
        mediaTypes.add(MediaType.TEXT_HTML);
        mediaTypes.add(MediaType.TEXT_PLAIN);

        converter.setSupportedMediaTypes(mediaTypes);
        rest.getMessageConverters().add(converter);

        return rest;
    }

    private HttpEntity<String> getHttpHeaders() {
        return getHttpHeaders("");
    }

    private HttpEntity<String> getHttpHeaders(String payload) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", "application/json");
        headers.set("Content-Type", "application/json");
        headers.set(storeTokenUserKey, storeTokenUser);
        headers.set(storeTokenPassKey, storeTokenPass);

        return new HttpEntity<>(payload, headers);
    }

    private StoreDistrictResponse getDistrictByCity(Long id) {
        StoreDistrictResponse response = new StoreDistrictResponse();
        String url = String.format(storeDistrictUrl, id);
        try {
            ResponseEntity<StoreDistrictResponse> res = getTemplate().exchange(url, HttpMethod.GET,
                    getHttpHeaders(), StoreDistrictResponse.class);
            response = res.getBody();
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

        return response;
    }

    private StoreResponse getStoresByDistrict(Long id) {
        StoreResponse response = new StoreResponse();
        String url = String.format(storeUrl, id);
        try {
            ResponseEntity<StoreResponse> res = getTemplate().exchange(url, HttpMethod.GET,
                    getHttpHeaders(), StoreResponse.class);
            response = res.getBody();
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

        return response;
    }

    @Route("/store-district/{id}")
    @ResponseBody
    public StoreDistrictResponse getDistrictAction(@PathVariable("id") Long id) {
        return getDistrictByCity(id);
    }

    @Route("/store")
    @ResponseBody
    public StoreResponse getStoreAction(@RequestParam(value = "id", required = false) Long id) {
        return getStoresByDistrict(id);
    }

    @Autowired
    private StoreFinder storeFinder;

    @GetMapping("/store-finder")
    @ResponseBody
    public Store getStoreByCode(@RequestParam(value = "code", required = false) String code) {
        storeFinder.validateCache();
        return storeFinder.findByCode(code);
    }
}
