package com.rs.sherina.Model;

import com.rs.sherina.Entity.MstAlamatCustomer;
import com.rs.sherina.Entity.MstAlamatDelivery;
import com.rs.sherina.Entity.MstAlamatPickup;
import com.univocity.parsers.annotations.Parsed;
import com.univocity.parsers.annotations.Trim;

public class DeliveryCSVData {
    @Trim
    @Parsed(index = 0)
    private String code;

    @Trim
    @Parsed(index = 1)
    private String name;

    @Trim
    @Parsed(index = 2)
    private String address;

    @Trim
    @Parsed(index = 3)
    private String city;

    @Trim
    @Parsed(index = 4)
    private String phone;
    
    @Trim
    @Parsed(index=5)
    private String groupcode;
    
    @Trim
    @Parsed(index=6)
    private String prvcode; 
    
    @Trim
    @Parsed(index=7)
    private String citycode; 
    
    @Trim
    @Parsed(index=8)
    private String cityname; 
    
    @Trim
    @Parsed(index=9)
    private String kcmtcode; 
    
    @Trim
    @Parsed(index=10)
    private String kcmtname; 
    
    private MstAlamatDelivery delivery;

    private MstAlamatPickup pickup;

    private MstAlamatCustomer alamatCustomer;

	public MstAlamatDelivery getDelivery() {
		return delivery;
	}

	public void setDelivery(MstAlamatDelivery delivery) {
		this.delivery = delivery;
	}

	public MstAlamatPickup getPickup() {
		return pickup;
	}

	public void setPickup(MstAlamatPickup pickup) {
		this.pickup = pickup;
	}

	public MstAlamatCustomer getAlamatCustomer() {
		return alamatCustomer;
	}

	public void setAlamatCustomer(MstAlamatCustomer alamatCustomer) {
		this.alamatCustomer = alamatCustomer;
	}

	public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCode() {
        return code;
    }

	public String getGroupcode() {
		return groupcode;
	}

	public void setGroupcode(String groupcode) {
		this.groupcode = groupcode;
	}

	public String getPrvcode() {
		return prvcode;
	}

	public void setPrvcode(String prvcode) {
		this.prvcode = prvcode;
	}

	public String getCitycode() {
		return citycode;
	}

	public void setCitycode(String citycode) {
		this.citycode = citycode;
	}

	public String getCityname() {
		return cityname;
	}

	public void setCityname(String cityname) {
		this.cityname = cityname;
	}

	public String getKcmtcode() {
		return kcmtcode;
	}

	public void setKcmtcode(String kcmtcode) {
		this.kcmtcode = kcmtcode;
	}

	public String getKcmtname() {
		return kcmtname;
	}

	public void setKcmtname(String kcmtname) {
		this.kcmtname = kcmtname;
	}

	public void setCode(String code) {
        this.code = code;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
    
}
