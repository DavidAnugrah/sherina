package com.rs.sherina.Utils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Json {
    public static String encode(Object object) {
        ObjectMapper mapper = new ObjectMapper();
        String result = null;
        try {
            result = mapper.writeValueAsString(object);
        } catch (Exception e) {
            //..
        }

        return result;
    }

    public static Object decode(String encoded, TypeReference<?> c) {
        ObjectMapper mapper = new ObjectMapper();
        Object result = null;
        try {
            result = mapper.readValue(encoded, c);
        } catch (Exception e) {
            // ..
        }

        return result;
    }
}
