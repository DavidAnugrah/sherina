package com.rs.sherina.Model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Set;

public class DeliveryMemberRequest {

    @JsonProperty("ids")
    public Set<Long> ids;

    public Set<Long> getIds() {
        return ids;
    }

    public void setIds(Set<Long> ids) {
        this.ids = ids;
    }
}
