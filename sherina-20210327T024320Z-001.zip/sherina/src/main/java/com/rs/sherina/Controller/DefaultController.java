package com.rs.sherina.Controller;

import com.rs.sherina.Entity.MstUiNews;
import com.rs.sherina.Entity.MstUiSlider;
import com.rs.sherina.Extension.annotation.Route;
import com.rs.sherina.Repository.MstUiNewsRepository;
import com.rs.sherina.Repository.MstUiSliderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class DefaultController {
    @Autowired
    private MstUiNewsRepository newsRepository;

    @Autowired
    private MstUiSliderRepository sliderRepository;

    @Route("/")
    @ResponseBody
    public String indexAction() {
        return "{\"Hello\": \"World\"}";
    }

    @GetMapping("/news")
    @ResponseBody
    public Iterable<MstUiNews> getNewsAction() {
        return newsRepository.findAll();
    }

    @GetMapping("/sliders")
    @ResponseBody
    public Iterable<MstUiSlider> getSliderAction() {
        return sliderRepository.findAll();
    }
}