package com.rs.sherina.Controller;

import com.fasterxml.jackson.annotation.JsonView;
import com.rs.sherina.DataTablesRepository.DataTablesShipmentRepository;
import com.rs.sherina.Entity.*;
import com.rs.sherina.Extension.annotation.Datatables;
import com.rs.sherina.Extension.annotation.Route;
import com.rs.sherina.Model.DataTablesRequest;
import com.rs.sherina.Model.DeliveryStatus;
import com.rs.sherina.Model.HeaderStatusResponse;
import com.rs.sherina.Model.Role;
import com.rs.sherina.Model.ShipmentResponse;
import com.rs.sherina.Model.StatusResponse;
import com.rs.sherina.Repository.MstAlamatCustomerRepository;
import com.rs.sherina.Repository.MstAlamatDeliveryRepository;
import com.rs.sherina.Repository.MstAlamatPickupRepository;
import com.rs.sherina.Repository.MstCustomerB2bRepository;
import com.rs.sherina.Repository.TrsShipmentRepository;
import com.rs.sherina.Repository.UserRepository;
import com.rs.sherina.Service.ShipmentBooking;
import com.rs.sherina.Service.ShipmentDateRangeSpecs;
import com.rs.sherina.Service.ShipmentSpecs;
import com.rs.sherina.Service.ShipmentStatusSpecs;
import com.rs.sherina.Service.ShipmentUserSpecs;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.jpa.datatables.mapping.Column;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.domain.Specifications;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.security.access.annotation.Secured;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;
import java.security.Principal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@RestController
@Secured({Role.ROLE_USER})
@SuppressWarnings("unchecked")
public class ShipmentController {

    private final static Logger logger = Logger.getLogger(ShipmentController.class);

    @PersistenceContext
    private EntityManager em;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private TrsShipmentRepository shipmentRepository;

    @Autowired
    private DataTablesShipmentRepository dataTablesShipmentRepository;

    @Autowired
    private MstAlamatDeliveryRepository deliveryRepository;

    @Autowired
    private MstAlamatPickupRepository pickupRepository;

    @Autowired
    private MstAlamatCustomerRepository addressRepository;

    @Autowired
    private MstCustomerB2bRepository customerRepository;

    @Autowired
    private ShipmentBooking booking;

    @Value("${spring.profiles.active}")
    private String environment;

    @Value("${sherina.api.service}")
    private String serviceUrl;

    @Value("${sherina.attributes.status.pending:PIO,AAA}")
    private List<String> pendingStatus;

    @Value("${sherina.attributes.status.failed:DEX,BBB}")
    private List<String> failedStatus;

    @Value("${sherina.attributes.status.otw:DOS,CCC}")
    private List<String> otwStatus;

    @GetMapping("/shipment")
    @ResponseBody
    public Set<TrsShipment> shipmentAction(Principal principal) {
        MstUser user = userRepository.findOneByUsername(principal.getName());

        return shipmentRepository.findByMstCustomerB2b(user.getMstCustomerB2b());
    }

    @GetMapping("/shipment/{shipment}")
    @ResponseBody
    public TrsShipment shipmentAction(@PathVariable("shipment") TrsShipment shipment) {
        if (shipment == null) {
            return new TrsShipment();
        }

        return shipment;
    }

    @DeleteMapping("/shipment")
    @ResponseBody
    public String shipmentRemoveAction(@RequestBody TrsShipment shipment) {
        shipmentRepository.deleteTrsShipmentById(shipment.getId());

        return "{\"success\": true}";
    }

    @PostMapping("/shipment")
    @Transactional
    @ResponseBody
    public TrsShipment shipmentSaveAction(@RequestBody(required = false) TrsShipment shipment, Principal principal, HttpServletRequest request) {
        MstUser user = userRepository.findOneByUsername(principal.getName());
        MstCustomerB2b customer = user.getMstCustomerB2b();
        shipment.setMstCustomerB2b(customer);
        boolean single = "true".equals(request.getParameter("single"));
        ShipmentResponse response = booking.send(request, shipment, single);

        if (response.getResponseCode() < 1) {
            if (null == shipment.getTshAwb() && null == shipment.getTshPk()) {
                shipment.setTshAwb(response.getWbCode());
                shipment.setTshPk(response.getBookingCode());
            }
//            shipment.setTshAsuransiPr(response.getInsurance());
//            shipment.setTshHarga(response.getPrice());
//            shipment.setTshHargaNet(response.getSubtotal());
//            shipment.setTshTotal(response.getTotal());

            MstAlamatDelivery delivery = shipment.getDelivery();
            MstAlamatPickup pickup = shipment.getPickup();
            MstAlamatCustomer address = shipment.getAddress();

            if (null != pickup) {
                if (null != pickup.getId()) {
                    pickup = pickupRepository.findOneById(pickup.getId());
                }
                shipment.setTshNamaPengirim(pickup.getMlpiNamaPengirim());
                shipment.setTshAlamatPengirim(pickup.getMlpiAlamat());
                shipment.setTshTelponPengirim(pickup.getMlpiTelpon());
                shipment.setTshKodePosPengirim(pickup.getMlpiKodePos());
                shipment.setTshMkcmKodePengirim(pickup.getMlpiMkcmKode());
                shipment.setTshMkcmNamaKotaPengirim(pickup.getMlpiMkcmKota());
                if (pickup.getIsTemp() != null && !pickup.getIsTemp() && null == pickup.getId()) {
                    pickup.setMstCustomerB2b(customer);
                    pickupRepository.save(pickup);
                }
                shipment.setPickup(pickup);
            }

            if (null != delivery) {
                MstGroupDelivery group = null;
                if (null != delivery.getId()) {
                    delivery = deliveryRepository.findOneById(delivery.getId());
                    group = delivery.getGroup();
                }

                shipment.setTshKodeStore(delivery.getMldeKodeStore());
                shipment.setTshNamaStore(delivery.getMldeNamaPenerimaStore());
                shipment.setTshKodePosStore(delivery.getMldeKodePosStore());
                shipment.setTshTelponStore(delivery.getMldeTelponStore());
                shipment.setTshAlamatStore(delivery.getMldeAlamatStore());

                shipment.setTshNamaPenerima(delivery.getMldeNamaPenerima());
                shipment.setTshEmailPenerima(delivery.getMldeEmail());
                shipment.setTshTelponPenerima(delivery.getMldeTelpon());
                shipment.setTshAlamatPenerima(delivery.getMldeAlamat());
                shipment.setTshGroupPenerima(null != group ? group.getMgrdNama() : null);
                shipment.setTshMkcmKodePenerima(delivery.getMldeMkcmKode());
                shipment.setTshLatLongPenerima(delivery.getMldeLatLong());
                shipment.setTshKodePosPenerima(delivery.getMldeKodePos());
                shipment.setTshMctyKodePenerima(delivery.getMldeMctyKode());
                shipment.setTshMprvKodePenerima(delivery.getMldeMprvKode());
                shipment.setTshMkcmNamaKotaPenerima(delivery.getMldeMkcmKota());

                if (null != delivery.getIsTemp() && !delivery.getIsTemp() && null == delivery.getId()) {
                    delivery.setMstCustomerB2b(customer);
                    deliveryRepository.save(delivery);
                }

                shipment.setDelivery(delivery);
            }

            if (null != address) {
                if (null != address.getId()) {
                    address = addressRepository.findOneById(address.getId());
                }

                shipment.setTshNamaPengirim(address.getMlcuNamaPengirim());
                shipment.setTshAlamatPengirim(address.getMlcuAlamat());
                shipment.setTshTelponPengirim(address.getMlcuTelpon());
                shipment.setTshKodePosPengirim(address.getMlcuKodePos());
                shipment.setTshMkcmKodePengirim(address.getMlcuMkcmKode());
                shipment.setTshMkcmNamaKotaPengirim(address.getMlcuMkcmKota());

                if (null != address.getIsTemp() && !address.getIsTemp() && null == address.getId()) {
                    address.setMstCustomerB2b(customer);
                    addressRepository.save(address);
                }

                 shipment.setAddress(address);
            }

            booking.wrap(shipment);
        }

        shipmentRepository.save(shipment);

        return shipment;
    }

    @GetMapping("/shipment/{id}/id")
    @ResponseBody
    public TrsShipment getShipmentByIdAction(@PathVariable("id") Long id) {
        return shipmentRepository.findOneById(id);
    }

    @GetMapping("/shipment/{tshTransNo}/list")
    @ResponseBody
    public Set<TrsShipment> getShipmentByTransAction(@PathVariable("tshTransNo") String tshTransNo) {
        return shipmentRepository.findByTshTransNo(tshTransNo);
    }

    @DeleteMapping("/shipment/{tshTransNo}/clear")
    @ResponseBody
    public String clearAllEmptyServiceAction(@PathVariable("tshTransNo") String tshTransNo, HttpServletRequest request, Principal principal) {
        MstCustomerB2b customer = customerRepository.findOneByUsername(principal.getName());
        if (!"0".equals(tshTransNo)) {
            Set<TrsShipment> shipments = shipmentRepository.findByTshTransNo(tshTransNo);

            for (TrsShipment s : shipments) {
                if (null == s.getTshMproKode()) {
                    shipmentRepository.deleteTrsShipmentById(s.getId());
                } else {
                    shipmentRepository.publishTrsShipment(false, s.getId());
                    ShipmentResponse response = booking.send(request, s, true);
                    if (response.getResponseCode() < 1) {
                        s.setTshTemp(false);
                        if (!StringUtils.isEmpty(response.getWbCode())) {
                            s.setTshAwb(response.getWbCode());
                        }
                        if (!StringUtils.isEmpty(response.getBookingCode())) {
                            s.setTshPk(response.getBookingCode());
                        }
                        shipmentRepository.save(s);
                    }
                }
            }
        }

        // shipmentRepository.deleteTempTrsShipment(true);
        try {
            shipmentRepository.clearAllFailedShipment(customer);
            shipmentRepository.clearAllFailedShipment(tshTransNo);
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

        return "{\"success\": true}";
    }

    @Route("/shipment/datatables-test")
    public DataTablesInput inputDt(@Datatables DataTablesInput input) {
        return input;
    }

    @Route("/shipment/datatables")
    @JsonView({DataTablesOutput.View.class})
    public DataTablesOutput<TrsShipment> datatablesAction(@Datatables DataTablesInput input, Principal principal) {
        MstCustomerB2b customer = customerRepository.findOneByUsername(principal.getName());
        Column col = input.getColumn("tshAwb");
        Specification<TrsShipment> spec0 = new ShipmentUserSpecs(customer);
        Specification<TrsShipment> spec1 = new ShipmentSpecs(col.getSearch().getValue(), "tshAwb");
        Specification<TrsShipment> spec2 = new ShipmentSpecs(col.getSearch().getValue(), "tshPk");
        col.getSearch().setValue("");

        Specifications<TrsShipment> spec3 = Specifications.where(spec1).or(spec2);
        Specifications<TrsShipment> spec4 = Specifications.where(new ShipmentDateRangeSpecs(input));
        Specifications<TrsShipment> spec5 = Specifications.where(spec0).and(spec3).and(spec4);
        Column cType = input.getColumn("type");
        if (null != cType) {
            String multiTypes = cType.getSearch().getValue();
            spec5 = spec5.and(new ShipmentStatusSpecs(multiTypes));
            Column status = input.getColumn("tshStatus");
            if (!StringUtils.isEmpty(multiTypes) && null != status) {
                status.getSearch().setValue("");
                status.setOrderable(false);
            }
        }

        return dataTablesShipmentRepository.findAll(input, spec5, null, new Converter<TrsShipment, TrsShipment>() {
            @Override
            public TrsShipment convert(TrsShipment shipment) {
                String awb = !StringUtils.isEmpty(shipment.getTshAwb()) ? shipment.getTshAwb() : shipment.getTshPk();
                shipment.setTshAwb(awb);

                return shipment;
            }
        });
    }

    @Route("/shipment/all/data")
    @Transactional
    @ResponseBody
    public Set<TrsShipment> getShipmentsAction(@RequestBody(required = false) Long[] ids, Principal principal) {
//        MstUser user = userRepository.findOneByUsername(principal.getName());
        MstCustomerB2b customer = customerRepository.findOneByUsername(principal.getName());
        Set<TrsShipment> shipments = new HashSet<TrsShipment>();
        if (null != ids) {
            for (Long id : ids) {
                TrsShipment shipment = shipmentRepository.findOneById(id);
                if (null != shipment) {
//                    if (shipment.getTshStatus() == null) {
//                        shipment = booking.wrap(shipment);
//                    }
                    if (null != shipment.getAddress() && null != shipment.getAddress().getMstAlamatPickup()) {
                        shipment.getAddress().setMstAlamatPickup(null);
                    }
                    shipments.add(shipment);
                }
            }
        } else if (null != customer && null != customer.getTrsShipments()) {
            shipments = shipmentRepository.findByMstCustomerB2bAndTshTemp(customer, false);
//            Set<TrsShipment> lists = shipmentRepository.findByMstCustomerB2bAndTshTemp(user.getMstCustomerB2b(), false);
//            for (TrsShipment shipment : lists) {
//                StatusResponse status = booking.fetch(shipment);
//                if (status.getResponseCode() < 1) {
//                    shipment.setStatus(status);
//                }
//                shipments.add(shipment);
//            }
        }

        return shipments;
    }

    @Route("/shipment/header/status")
    @ResponseBody
    public HeaderStatusResponse headerStatusAction(Principal principal) {
//        MstCustomerB2b customer = customerRepository.findOneByUsername(principal.getName());
        // Development only
//        String sipCode = "C18.0174";
//        if (!environment.equals("local")) {
//            sipCode = customer.getId();
            String sipCode = userRepository.getKodeAkunByUsername(principal.getName());
            logger.info("Found customer code from header status: "+sipCode);
//        }

        HeaderStatusResponse response = new HeaderStatusResponse();

        try {
            RestTemplate rest = new RestTemplate();
            MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
            List<MediaType> mediaTypes = new ArrayList<>();
            mediaTypes.add(MediaType.APPLICATION_JSON_UTF8);
            mediaTypes.add(MediaType.APPLICATION_JSON);
            mediaTypes.add(MediaType.TEXT_HTML);
            mediaTypes.add(MediaType.TEXT_PLAIN);

            converter.setSupportedMediaTypes(mediaTypes);
            rest.getMessageConverters().add(converter);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

            MultiValueMap<String, String> payload = new LinkedMultiValueMap<>();

            payload.add("tipe", "h");
            payload.add("sip_kode", sipCode);
            payload.add("response", "json");

            HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(payload, headers);

            response = rest.postForObject(serviceUrl, request, HeaderStatusResponse.class);

        } catch (Exception e) {
            logger.error("Error: " + e.getMessage());
        }

        try {
            if (null == response) {
                response = new HeaderStatusResponse();
                response.setUnpaid(0L);
            }
            Long pending = shipmentRepository.countByCustomerB2bAndTshStatus(sipCode, ShipmentStatusSpecs.pendingStatus);
            Long otw = shipmentRepository.countByCustomerB2bAndTshStatus(sipCode, ShipmentStatusSpecs.otwStatus);
            Long failed = shipmentRepository.countByCustomerB2bAndTshStatus(sipCode, ShipmentStatusSpecs.failedStatus);
            response.setFailed(failed);
            response.setOtw(otw);
            response.setPending(pending);
            logger.info(String.format("OTW: %d, PENDING: %d, FAILED: %s", otw, pending, failed));
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

        return response;
    }

    @Route("/shipment/delivery/{trsShipment}/status")
    @ResponseBody
    public List<DeliveryStatus> deliveryStatusAction(@PathVariable("trsShipment") TrsShipment trsShipment) {
        List<DeliveryStatus> statuses = new ArrayList<>();
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        MultiValueMap<String, String> payload = new LinkedMultiValueMap<>();

        payload.add("tipe", "t");
        payload.add("waybill", trsShipment.getTshAwb());
        payload.add("response", "json");

        HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(payload, headers);

        try {

            ResponseEntity<List<DeliveryStatus>> res = getTemplate().exchange(
                    serviceUrl,
                    HttpMethod.POST,
                    request,
                    new ParameterizedTypeReference<List<DeliveryStatus>>() {
                    });

            if (res != null && res.hasBody() && res.getStatusCodeValue() == 200) {
                statuses = res.getBody();

                for (DeliveryStatus stat : statuses) {
                    stat.setBookingCode(trsShipment.getTshPk());
                    stat.setWaybill(trsShipment.getTshAwb());
                }
            }
        } catch (Exception e) {
            logger.error(e.getMessage());
        }

        return statuses;
    }

    private RestTemplate getTemplate() {
        RestTemplate rest = new RestTemplate();
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        List<MediaType> mediaTypes = new ArrayList<>();

        mediaTypes.add(MediaType.APPLICATION_JSON_UTF8);
        mediaTypes.add(MediaType.APPLICATION_JSON);
        mediaTypes.add(MediaType.TEXT_HTML);
        mediaTypes.add(MediaType.TEXT_PLAIN);

        converter.setSupportedMediaTypes(mediaTypes);
        rest.getMessageConverters().add(converter);

        return rest;
    }
}
