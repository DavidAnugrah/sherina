package com.rs.sherina.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonView;
import com.rs.sherina.Model.TempShipment;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import java.util.Date;
import java.util.Set;

@Entity
@Table(name = "mst_alamat_delivery")
@SuppressWarnings("SpellCheckingInspection")
public class MstAlamatDelivery {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "mlde_mcus_kode")
    @JsonIgnore
    private MstCustomerB2b mstCustomerB2b;

    @ManyToOne(cascade = {CascadeType.ALL})
    @JoinColumn(name = "mlde_mgrd_kode")
    @JsonView(DataTablesOutput.View.class)
    private MstGroupDelivery group;

    @ManyToOne(targetEntity = MstAlamatPickup.class)
    @JsonProperty("pickup")
    private MstAlamatPickup mstAlamatPickup;

    /*@OneToMany(mappedBy = "delivery", fetch = FetchType.LAZY, cascade = {CascadeType.ALL})
    @JsonIgnore
    private Set<TrsShipment> shipments;*/

    @Transient
    @JsonProperty("uploaded")
    private TempShipment tempShipment;

    @Column(length = 20)
    private String mldeKodeAlamat;

    private String mldeNamaPenerima;

    @JsonView(DataTablesOutput.View.class)
    private String mldeAlamat;

    private String mldeMprvKode;

    private String mldeMctyKode;

    private String mldeMkcmKode;

    private String mldeMkcmKota;

    @JsonView(DataTablesOutput.View.class)
    private String mldeTelpon;

    private String mldeKodePos;

    private String mldeLatLong;

    private String mldeEmail;

    private String mldeNamaPenerimaStore;

    private String mldeAlamatStore;

    private String mldeMprvKodeStore;

    private String mldeMctyKodeStore;

    private String mldeMkcmKodeStore;

    private String mldeKodeStore;

    private String mldeKodePosStore;

    private String mldeTelponStore;

    private boolean mldeAllowPickup;

    @JsonIgnore
    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    private Date mldeCreateDate;

    @JsonIgnore
    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    private Date mldeUpdateDate;

    @ManyToOne
    @JoinColumn(name = "mlde_create_user")
    @JsonIgnore
    private MstUser userCreator;

    @ManyToOne
    @JoinColumn(name = "mlde_update_user")
    @JsonIgnore
    private MstUser userUpdater;

    private Boolean isTemp = false;

    public Long getId() {
        return id;
    }

    public MstCustomerB2b getMstCustomerB2b() {
        return mstCustomerB2b;
    }

    public void setMstCustomerB2b(MstCustomerB2b mstCustomerB2b) {
        this.mstCustomerB2b = mstCustomerB2b;
        if (null != mstCustomerB2b) {
            if (null == this.userCreator) {
                this.userCreator = mstCustomerB2b.getUser();
            }

            this.userUpdater = mstCustomerB2b.getUser();
        }
    }

    public MstGroupDelivery getGroup() {
        return group;
    }

    public void setGroup(MstGroupDelivery group) {
        this.group = group;
    }

    public String getMldeKodeAlamat() {
        return mldeKodeAlamat;
    }

    public void setMldeKodeAlamat(String mldeKodeAlamat) {
        this.mldeKodeAlamat = mldeKodeAlamat;
    }

    public String getMldeNamaPenerima() {
        return mldeNamaPenerima;
    }

    public void setMldeNamaPenerima(String mldeNamaPenerima) {
        this.mldeNamaPenerima = mldeNamaPenerima;
    }

    public String getMldeAlamat() {
        return mldeAlamat;
    }

    public void setMldeAlamat(String mldeAlamat) {
        this.mldeAlamat = mldeAlamat;
    }

    public String getMldeMprvKode() {
        return mldeMprvKode;
    }

    public void setMldeMprvKode(String mldeMprvKode) {
        this.mldeMprvKode = mldeMprvKode;
    }

    public String getMldeMctyKode() {
        return mldeMctyKode;
    }

    public void setMldeMctyKode(String mldeMctyKode) {
        this.mldeMctyKode = mldeMctyKode;
    }

    public String getMldeMkcmKode() {
        return mldeMkcmKode;
    }

    public void setMldeMkcmKode(String mldeMkcmKode) {
        this.mldeMkcmKode = mldeMkcmKode;
    }

    public String getMldeTelpon() {
        return mldeTelpon;
    }

    public void setMldeTelpon(String mldeTelpon) {
        this.mldeTelpon = mldeTelpon;
    }

    public String getMldeKodePos() {
        return mldeKodePos;
    }

    public void setMldeKodePos(String mldeKodePos) {
        this.mldeKodePos = mldeKodePos;
    }

    public String getMldeLatLong() {
        return mldeLatLong;
    }

    public void setMldeLatLong(String mldeLatLong) {
        this.mldeLatLong = mldeLatLong;
    }

    public String getMldeEmail() {
        return mldeEmail;
    }

    public void setMldeEmail(String mldeEmail) {
        this.mldeEmail = mldeEmail;
    }

    public String getMldeNamaPenerimaStore() {
        return mldeNamaPenerimaStore;
    }

    public void setMldeNamaPenerimaStore(String mldeNamaPenerimaStore) {
        this.mldeNamaPenerimaStore = mldeNamaPenerimaStore;
    }

    public String getMldeAlamatStore() {
        return mldeAlamatStore;
    }

    public void setMldeAlamatStore(String mldeAlamatStore) {
        this.mldeAlamatStore = mldeAlamatStore;
    }

    public String getMldeMprvKodeStore() {
        return mldeMprvKodeStore;
    }

    public void setMldeMprvKodeStore(String mldeMprvKodeStore) {
        this.mldeMprvKodeStore = mldeMprvKodeStore;
    }

    public String getMldeMctyKodeStore() {
        return mldeMctyKodeStore;
    }

    public void setMldeMctyKodeStore(String mldeMctyKodeStore) {
        this.mldeMctyKodeStore = mldeMctyKodeStore;
    }

    public String getMldeMkcmKodeStore() {
        return mldeMkcmKodeStore;
    }

    public void setMldeMkcmKodeStore(String mldeMkcmKodeStore) {
        this.mldeMkcmKodeStore = mldeMkcmKodeStore;
    }

    public String getMldeKodeStore() {
        return mldeKodeStore;
    }

    public void setMldeKodeStore(String mldeKodeStore) {
        if (null != mldeKodeStore) {
            this.mldeKodeStore = mldeKodeStore.toUpperCase();
        }
    }

    public String getMldeKodePosStore() {
        return mldeKodePosStore;
    }

    public void setMldeKodePosStore(String mldeKodePosStore) {
        this.mldeKodePosStore = mldeKodePosStore;
    }

    public String getMldeTelponStore() {
        return mldeTelponStore;
    }

    public void setMldeTelponStore(String mldeTelponStore) {
        this.mldeTelponStore = mldeTelponStore;
    }

    public boolean isMldeAllowPickup() {
        return mldeAllowPickup;
    }

    public void setMldeAllowPickup(boolean mldeAllowPickup) {
        this.mldeAllowPickup = mldeAllowPickup;
    }

    public String getMldeMkcmKota() {
        return mldeMkcmKota;
    }

    public void setMldeMkcmKota(String mldeMkcmKota) {
        this.mldeMkcmKota = mldeMkcmKota;
    }

    public MstAlamatPickup getMstAlamatPickup() {
        return mstAlamatPickup;
    }

    public void setMstAlamatPickup(MstAlamatPickup mstAlamatPickup) {
        this.mstAlamatPickup = mstAlamatPickup;
    }

    public TempShipment getTempShipment() {
        return tempShipment;
    }

    public void setTempShipment(TempShipment tempShipment) {
        this.tempShipment = tempShipment;
    }

    /*public Set<TrsShipment> getShipments() {
        return shipments;
    }

    public void setShipments(Set<TrsShipment> shipments) {
        this.shipments = shipments;
    }*/

    public Date getMldeCreateDate() {
        return mldeCreateDate;
    }

    public void setMldeCreateDate(Date mldeCreateDate) {
        this.mldeCreateDate = mldeCreateDate;
    }

    public Date getMldeUpdateDate() {
        return mldeUpdateDate;
    }

    public void setMldeUpdateDate(Date mldeUpdateDate) {
        this.mldeUpdateDate = mldeUpdateDate;
    }

    public Boolean getIsTemp() {
        return isTemp;
    }

    public void setIsTemp(Boolean temp) {
        isTemp = temp;
    }
}
