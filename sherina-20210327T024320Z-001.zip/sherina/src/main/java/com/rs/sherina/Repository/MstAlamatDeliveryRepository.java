package com.rs.sherina.Repository;

import com.rs.sherina.Entity.MstAlamatDelivery;
import com.rs.sherina.Entity.MstCustomerB2b;
import com.rs.sherina.Entity.MstGroupDelivery;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import javax.transaction.Transactional;
import java.util.List;

public interface MstAlamatDeliveryRepository extends PagingAndSortingRepository<MstAlamatDelivery, Long> {
    List<MstAlamatDelivery> findByGroup(MstGroupDelivery group);

    MstAlamatDelivery findOneById(Long id);

    @Transactional
    @Modifying
    @Query("UPDATE MstAlamatDelivery d SET d.group = NULL WHERE d.id = ?1")
    void removeGroupById(Long id);

    @Transactional
    @Modifying
    @Query("UPDATE MstAlamatDelivery d SET d.group = ?1 WHERE d.id = ?2")
    void applyToGroup(MstGroupDelivery group, Long id);
        
    List<MstAlamatDelivery> findByMstCustomerB2bAndMldeAllowPickupOrderByIdDesc(MstCustomerB2b customer, boolean mldeAllowPickup);

    List<MstAlamatDelivery> findByMstCustomerB2bAndIsTempOrderByIdDesc(MstCustomerB2b customer, Boolean isTemp);

    List<MstAlamatDelivery> findByMstCustomerB2bAndIsTempAndMldeAllowPickupOrderByIdDesc(MstCustomerB2b customer, Boolean isTemp, boolean mldeAllowPickup);

    @Modifying
    @Transactional
    @Query("UPDATE MstAlamatDelivery c SET c.isTemp = false WHERE c.isTemp IS NULL")
    void fixingTemporary();
}
