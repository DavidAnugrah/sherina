package com.rs.sherina.Controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.rs.sherina.Entity.MstCustomerB2b;
import com.rs.sherina.Entity.MstUser;
import com.rs.sherina.Model.ServiceResponse;
import com.rs.sherina.Repository.MstCustomerB2bRepository;
import com.rs.sherina.Repository.UserRepository;

@SuppressWarnings("SpellCheckingInspection")
@RestController
public class ServiceController {

    private final static Logger logger = LoggerFactory.getLogger(ServiceController.class);

    @Value("${sherina.api.service}")
    private String citiesUrl;

    @Value("${spring.profiles.active:production}")
    private String profile;

    @Autowired
    private MstCustomerB2bRepository mstCustomerB2bRepository;
    
    @Autowired
    private UserRepository userRepository;

    @GetMapping("/service")
    @ResponseBody
    @SuppressWarnings("unchecked")
    public ServiceResponse getServiceAction(HttpServletRequest req, Principal principal) {
        ServiceResponse response = new ServiceResponse();
        MstCustomerB2b customer = null;
        if (null != principal && !StringUtils.isEmpty(principal.getName())) {
            customer = mstCustomerB2bRepository.findOneByUsername(principal.getName());
            if (customer.getType() != null && customer.getType().equals("PIC")) {
            	try {
            		MstUser tempUser = userRepository.findOneByUsername(principal.getName());
            		customer = mstCustomerB2bRepository.findOneByUsername(tempUser.getRemark());
            	} catch (Exception e) {
					e.printStackTrace();
				}
            }
        }

        try {
            RestTemplate rest = new RestTemplate();
            String url = citiesUrl;
            MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
            List<MediaType> mediaTypes = new ArrayList<>();
            mediaTypes.add(MediaType.APPLICATION_JSON_UTF8);
            mediaTypes.add(MediaType.APPLICATION_JSON);
            mediaTypes.add(MediaType.TEXT_HTML);
            mediaTypes.add(MediaType.TEXT_PLAIN);
            mediaTypes.add(MediaType.ALL);

            converter.setSupportedMediaTypes(mediaTypes);
            rest.getMessageConverters().add(converter);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

            MultiValueMap<String, String> payload = new LinkedMultiValueMap<>();

            String customerCode = req.getParameter("cust");
            String from = "a";
            String to = "home";
            String kecFrom = req.getParameter("from");
            String kecTo = req.getParameter("to");
            String berat = req.getParameter("B");
            String tinggi = req.getParameter("T");
            String panjang = req.getParameter("P");
            String lebar = req.getParameter("L");
            String asuransi = req.getParameter("as");
            String packing = req.getParameter("p");
            String nilai = req.getParameter("n");
            switch (req.getParameter("type").toLowerCase()) {
                case "d2d":
                    from = "o";
                    to = "home";
                    break;
                case "d2s":
                    from = "o";
                    to = "store";
                    break;
                case "s2d":
                    from = "a";
                    to = "home";
                    break;
                case "s2s":
                    from = "a";
                    to = "store";
                    break;
            }

            if (StringUtils.isEmpty(customerCode) && null != customer) {
                customerCode = customer.getId();
            }

            if (!StringUtils.isEmpty(customerCode)) {
                payload.add("sip_kode", customerCode);
            }

            payload.add("tipe_pickup", from);
            payload.add("tipe_drop", to);
            payload.add("tipe", "l");
            payload.add("sip_kode_kecamatan", kecFrom);
            payload.add("pen_kode_kecamatan", kecTo);
            payload.add("berat", berat);
            payload.add("panjang", panjang);
            payload.add("lebar", lebar);
            payload.add("tinggi", tinggi);
            payload.add("nilai_paket", nilai);
            payload.add("insurance", asuransi);
            payload.add("packing", "0");

            if (profile.equalsIgnoreCase("local")) {
                Iterator<String> it = payload.keySet().iterator();
                while (it.hasNext()) {
                    String k = it.next();
                    String v = payload.getFirst(k);
                    System.out.println(String.format("%s:%s", k, v));
                }
            }

            HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(payload, headers);

            response = rest.postForObject(url, request, ServiceResponse.class);
            logger.info("Success: GET /service");
        } catch (Exception e) {
            logger.error("Error: GET /service : Harga Kosong");
        }

        return response;
    }

    @GetMapping("/check-price")
    @ResponseBody
    @SuppressWarnings("unchecked")
    public List<ServiceResponse> getPriceAction(HttpServletRequest req, Principal principal) {
        List<ServiceResponse> response = new ArrayList<ServiceResponse>();
        MstCustomerB2b customer = null;
        if (null != principal && !StringUtils.isEmpty(principal.getName())) {
            customer = mstCustomerB2bRepository.findOneByUsername(principal.getName());
            if (customer.getType() != null && customer.getType().equals("PIC")) {
            	MstUser tempUser = userRepository.findOneByUsername(principal.getName());
           		MstCustomerB2b parent = mstCustomerB2bRepository.findOneByUsername(tempUser.getRemark());
                customer = parent;
			}
        }

        try {
            RestTemplate rest = new RestTemplate();
            String url = citiesUrl;
            MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
            List<MediaType> mediaTypes = new ArrayList<>();
            mediaTypes.add(MediaType.APPLICATION_JSON_UTF8);
            mediaTypes.add(MediaType.APPLICATION_JSON);
            mediaTypes.add(MediaType.TEXT_HTML);
            mediaTypes.add(MediaType.TEXT_PLAIN);
            mediaTypes.add(MediaType.ALL);

            converter.setSupportedMediaTypes(mediaTypes);
            rest.getMessageConverters().add(converter);

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

            MultiValueMap<String, String> payload = new LinkedMultiValueMap<>();

            String customerCode = req.getParameter("cust");
            String from = "a";
            String to = "home";
            String kecFrom = req.getParameter("from");
            String kecTo = req.getParameter("to");
            String berat = req.getParameter("B");
            String tinggi = req.getParameter("T");
            String panjang = req.getParameter("P");
            String lebar = req.getParameter("L");
            String asuransi = req.getParameter("as");
            String packing = req.getParameter("p");
            String nilai = req.getParameter("n");

            if (StringUtils.isEmpty(customerCode) && null != customer) {
                customerCode = customer.getId();
            }

            if (!StringUtils.isEmpty(customerCode)) {
                payload.add("sip_kode", customerCode);
            }

            payload.add("tipe", "v");
            payload.add("sip_kode_kecamatan", kecFrom);
            payload.add("pen_kode_kecamatan", kecTo);
            payload.add("berat", berat);
            payload.add("panjang", panjang);
            payload.add("lebar", lebar);
            payload.add("tinggi", tinggi);
            payload.add("nilai_paket", nilai);
            payload.add("insurance", asuransi);
            payload.add("packing", "0");

            if (profile.equalsIgnoreCase("local")) {
                Iterator<String> it = payload.keySet().iterator();
                while (it.hasNext()) {
                    String k = it.next();
                    String v = payload.getFirst(k);
                    System.out.println(String.format("%s:%s", k, v));
                }
            }

            HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(payload, headers);

            ResponseEntity<List<ServiceResponse>> res = rest.exchange(url, HttpMethod.POST, request,
                    new ParameterizedTypeReference<List<ServiceResponse>>(){});
            response = res.getBody();
            logger.info("Success: GET /check-price");
        } catch (Exception e) {
            logger.info(e.getMessage());
            logger.error("Error: GET /check-price: Harga Kosong");
        }

        return response;
    }
}
