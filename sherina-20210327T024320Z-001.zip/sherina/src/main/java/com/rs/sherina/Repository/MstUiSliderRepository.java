package com.rs.sherina.Repository;

import com.rs.sherina.Entity.MstUiSlider;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface MstUiSliderRepository extends PagingAndSortingRepository<MstUiSlider, Long> {
    MstUiSlider findOneById(Long id);
}
