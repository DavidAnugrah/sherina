package com.rs.sherina.Repository;

import com.rs.sherina.Entity.MstCustomerB2b;
import com.rs.sherina.Entity.TrsShipment;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Set;

public interface TrsShipmentRepository extends PagingAndSortingRepository<TrsShipment, Long> {
    TrsShipment findOneById(Long id);

    Set<TrsShipment> findByMstCustomerB2b(MstCustomerB2b mstCustomerB2b);

    Set<TrsShipment> findByMstCustomerB2bAndTshTemp(MstCustomerB2b mstCustomerB2b, Boolean tshTemp);

    Set<TrsShipment> findByTshTransNo(String tshTransNo);

    @Query("DELETE FROM TrsShipment t WHERE t.id = ?1")
    @Transactional
    @Modifying
    void deleteTrsShipmentById(Long id);

    @Query("DELETE FROM TrsShipment t WHERE t.tshTemp = ?1 OR t.tshTemp IS NULL")
    @Transactional
    @Modifying
    void deleteTempTrsShipment(Boolean tshTemp);

    @Query("DELETE FROM TrsShipment t WHERE (t.tshTemp = true OR (t.tshPk IS NULL AND t.tshAwb IS NULL))")
    @Transactional
    @Modifying
    void clearAllFailedShipment();

    @Query("DELETE FROM TrsShipment t WHERE (t.tshTemp = true OR (t.tshPk IS NULL AND t.tshAwb IS NULL)) AND t.mstCustomerB2b = ?1")
    @Transactional
    @Modifying
    void clearAllFailedShipment(MstCustomerB2b customer);

    @Query("DELETE FROM TrsShipment t WHERE (t.tshTemp = true OR (t.tshPk IS NULL AND t.tshAwb IS NULL)) AND t.tshTransNo = ?1")
    @Transactional
    @Modifying
    void clearAllFailedShipment(String tshTransNo);

    @Query("UPDATE TrsShipment t SET t.tshTemp = ?1 WHERE t.id = ?2")
    @Transactional
    @Modifying
    void publishTrsShipment(Boolean tshTemp, Long id);

    TrsShipment findOneByTshAwb(String tshAwb);

    TrsShipment findOneByTshPk(String tshPk);

    @Query("SELECT COUNT(t) FROM TrsShipment t WHERE t.mstCustomerB2b = ?1 AND t.tshStatus IN(?2) AND t.tshTemp = false")
    Long countByCustomerB2bAndTshStatus(MstCustomerB2b customer, List<String> statuses);

    @Query("SELECT COUNT(t) FROM TrsShipment t WHERE t.mstCustomerB2b = ?1 AND t.tshStatus = ?2 AND t.tshTemp = false")
    Long countByCustomerB2bAndTshStatus(MstCustomerB2b customer, String status);

    @Query(value = "SELECT COUNT(t.id) FROM trs_shipment t WHERE t.tsh_mcus_kode = ?1 AND t.tsh_status IN(?2) AND t.tsh_temp = false", nativeQuery = true)
    Long countByCustomerB2bAndTshStatus(String code, List<String> statuses);

    @Query(value = "SELECT COUNT(t.id) FROM trs_shipment t WHERE t.tsh_mcus_kode = ?1 AND t.tsh_status = ?2 AND t.tsh_temp = false", nativeQuery = true)
    Long countByCustomerB2bAndTshStatus(String code, String status);
}
