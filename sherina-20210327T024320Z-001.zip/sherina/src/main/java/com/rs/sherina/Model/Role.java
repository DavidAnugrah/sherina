package com.rs.sherina.Model;

public interface Role {
    String ROLE_USER = "ROLE_USER";
    String ROLE_ADMIN = "ROLE_ADMIN";
    String ROLE_API_CLIENT = "ROLE_API_CLIENT";
    String ROLE_BACKDOOR = "ROLE_BACKDOOR";
}
