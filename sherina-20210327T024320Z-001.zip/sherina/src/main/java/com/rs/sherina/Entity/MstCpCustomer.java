package com.rs.sherina.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import java.util.Date;

@Entity
@Table(name = "mst_cp_customer")
@SuppressWarnings("SpellCheckingInspection")
public class MstCpCustomer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "mcpc_mcus_kode")
    @JsonIgnore
    private MstCustomerB2b mstCustomerB2b;

    private String mcpcNama;

    private String mcpcHp;
    
    @Column(name = "is_deleted")
    private Boolean isDeleted;

    @Transient
    private Boolean deleted;
    
    @Transient
    private Boolean isNew;
    
    @Transient
    private Boolean isUpdated;
    

    @Column(length = 45)
    private String mcpcEmail;

    @JsonIgnore
    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    private Date mcpcCreateDate;

    @JsonIgnore
    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    private Date mcpcUpdateDate;

    @ManyToOne
    @JoinColumn(name = "mcpc_create_user")
    @JsonIgnore
    private MstUser userCreator;

    @ManyToOne
    @JoinColumn(name = "mcpc_update_user")
    @JsonIgnore
    private MstUser userUpdater;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public MstCustomerB2b getMstCustomerB2b() {
        return mstCustomerB2b;
    }

    public void setMstCustomerB2b(MstCustomerB2b mstCustomerB2b) {
        this.mstCustomerB2b = mstCustomerB2b;
        if (null != mstCustomerB2b) {
            if (null == this.userCreator) {
                this.userCreator = mstCustomerB2b.getUser();
            }

            this.userUpdater = mstCustomerB2b.getUser();
        }
    }

    public String getMcpcNama() {
        return mcpcNama;
    }

    public void setMcpcNama(String mcpcNama) {
        this.mcpcNama = mcpcNama;
    }

    public String getMcpcHp() {
        return mcpcHp;
    }

    public void setMcpcHp(String mcpcHp) {
        this.mcpcHp = mcpcHp;
    }

    public String getMcpcEmail() {
        return mcpcEmail;
    }

    public void setMcpcEmail(String mcpcEmail) {
        this.mcpcEmail = mcpcEmail;
    }

    public Date getMcpcCreateDate() {
        return mcpcCreateDate;
    }

    public void setMcpcCreateDate(Date mcpcCreateDate) {
        this.mcpcCreateDate = mcpcCreateDate;
    }

    public Date getMcpcUpdateDate() {
        return mcpcUpdateDate;
    }

    public void setMcpcUpdateDate(Date mcpcUpdateDate) {
        this.mcpcUpdateDate = mcpcUpdateDate;
    }
	public boolean getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Boolean getIsNew() {
		return isNew;
	}

	public void setIsNew(boolean isNew) {
		this.isNew = isNew;
	}

	public Boolean getIsUpdated() {
		return isUpdated;
	}

	public void setIsUpdated(boolean isUpdated) {
		this.isUpdated = isUpdated;
	}

	public Boolean getDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}
	
}
