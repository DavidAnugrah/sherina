package com.rs.sherina.DataTablesRepository;

import com.rs.sherina.Entity.MstUser;
import org.springframework.data.jpa.datatables.mapping.DataTablesInput;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;
import org.springframework.data.jpa.datatables.repository.DataTablesRepository;

public interface DataTablesUserRepository extends DataTablesRepository<MstUser, Long> {
    DataTablesOutput<MstUser> findAll(DataTablesInput input);
}
