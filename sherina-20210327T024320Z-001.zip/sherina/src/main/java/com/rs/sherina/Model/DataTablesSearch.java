package com.rs.sherina.Model;

public class DataTablesSearch {
    private String value = "";

    private Boolean regex = false;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public Boolean getRegex() {
        return regex;
    }

    public void setRegex(Boolean regex) {
        this.regex = regex;
    }
}
