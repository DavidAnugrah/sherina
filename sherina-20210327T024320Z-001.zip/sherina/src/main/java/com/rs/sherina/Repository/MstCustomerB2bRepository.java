package com.rs.sherina.Repository;

import java.util.Optional;

import javax.jdo.annotations.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.rs.sherina.Entity.MstCustomerB2b;

public interface MstCustomerB2bRepository extends PagingAndSortingRepository<MstCustomerB2b, Long> {
    Optional<MstCustomerB2b> findOneById(String id);

    @Query("FROM MstCustomerB2b c WHERE c.user.username = ?1")
    MstCustomerB2b findOneByUsername(String username);
    
    @Modifying
    @Transactional
    @Query(value="update mst_customer_b2b set mcus_telp = ?1 , mcus_fax= ?2 , mcus_web= ?3 , mcus_email = ?4 where MCUS_CODE=?5",nativeQuery= true)
    void updateCustomer(String telp, String fax, String web,String email , String mcusCode);
    
    @Query(value="select mcus_code from mst_customer_b2b where mcus_email= ?1 LIMIT 1",nativeQuery = true)
    String codeCustomer(String username);
}
