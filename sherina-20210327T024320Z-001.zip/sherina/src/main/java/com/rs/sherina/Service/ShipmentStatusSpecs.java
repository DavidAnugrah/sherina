package com.rs.sherina.Service;

import com.rs.sherina.Entity.TrsShipment;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.Arrays;
import java.util.List;

public class ShipmentStatusSpecs implements Specification<TrsShipment> {
    private String status;

    public static final List<String> pendingStatus = Arrays.asList("PIO", "EDP", "DOS");

    public static final List<String> otwStatus = Arrays.asList("PUP", "COL", "INI", "ICO", "SIP", "SOP", "VAN", "TRI", "TRO");

    public static final List<String> failedStatus = Arrays.asList("DEX", "ZZZ");

    public ShipmentStatusSpecs(String status) {
        this.status = status;
    }

    @Override
    public Predicate toPredicate(Root<TrsShipment> root, CriteriaQuery<?> criteriaQuery, CriteriaBuilder criteriaBuilder) {
        Predicate predicate = null;
        if (!StringUtils.isEmpty(status)) {
            Expression<String> exp = root.get("tshStatus");
            switch (status.toUpperCase()) {
                case "PENDING":
                    predicate = exp.in(pendingStatus);
                    break;
                case "FAILED":
                    predicate = exp.in(failedStatus);
                    break;
                case "OTW":
                    predicate = exp.in(otwStatus);
                    break;
            }
        }

        return predicate;
    }
}
