package com.rs.sherina.Model;

import com.rs.sherina.Entity.MstGroupDelivery;

import java.util.HashSet;
import java.util.Set;

public class ListGroupDeliveryResponse {
    private Set<GroupDeliveryResponse> groups;

    private boolean allowPickup = false;

    private boolean ignorePickup = false;

    public ListGroupDeliveryResponse(Set<MstGroupDelivery> groups, boolean allowPickup, boolean ignorePickup) {
        this.allowPickup = allowPickup;
        this.ignorePickup = ignorePickup;
        init(groups);
    }

    public ListGroupDeliveryResponse(Set<MstGroupDelivery> groups, boolean allowPickup) {
        this.allowPickup = allowPickup;
        init(groups);
    }

    public ListGroupDeliveryResponse(Set<MstGroupDelivery> groups) {
        init(groups);
    }

    private void init(Set<MstGroupDelivery> groups) {
        this.groups = new HashSet<>();
        if (null != groups) {
            for (MstGroupDelivery group : groups) {
                group.allowCountMembers = this.allowPickup;
                group.ignorePickup = this.ignorePickup;
                this.groups.add(new GroupDeliveryResponse(group));
            }
        }
    }

    public Set<GroupDeliveryResponse> getAllGroups() {
        return groups;
    }
}
