package com.rs.sherina.Model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class StoreProvince {

    private Long provinceId;

    private String provinceName;

    public Long getProvinceId() {
        return provinceId;
    }

    @JsonProperty("proviceId")
    public void setProvinceId(Long provinceId) {
        this.provinceId = provinceId;
    }

    public String getProvinceName() {
        return provinceName;
    }

    @JsonProperty("proviceName")
    public void setProvinceName(String provinceName) {
        this.provinceName = provinceName;
    }
}
