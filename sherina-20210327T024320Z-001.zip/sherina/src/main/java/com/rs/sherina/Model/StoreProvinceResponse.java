package com.rs.sherina.Model;

import java.util.ArrayList;
import java.util.List;

public class StoreProvinceResponse {
    private List<StoreProvince> provinces = new ArrayList<>();

    public List<StoreProvince> getProvinces() {
        return provinces;
    }

    public void setProvinces(List<StoreProvince> provinces) {
        this.provinces = provinces;
    }

    public void merge(StoreProvinceResponse response) {
        provinces.addAll(response.getProvinces());
    }
}
