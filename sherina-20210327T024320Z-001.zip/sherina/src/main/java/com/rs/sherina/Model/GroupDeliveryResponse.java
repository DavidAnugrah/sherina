package com.rs.sherina.Model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.rs.sherina.Entity.MstAlamatDelivery;
import com.rs.sherina.Entity.MstGroupDelivery;

import java.util.Collections;
import java.util.Set;

@SuppressWarnings("all")
public class GroupDeliveryResponse {
    @JsonProperty
    private Long id;

    @JsonProperty
    private String mgrdKode;

    @JsonProperty
    private String mgrdNama;

    @JsonProperty
    private String mgrdStatus;

    @JsonProperty
    private Long totalMembers;

    @JsonProperty
    private Set<MstAlamatDelivery> deliveries;

    public GroupDeliveryResponse(MstGroupDelivery group) {
        if (null != group) {
            this.id = group.getId();
            this.mgrdKode = group.getMgrdKode();
            this.mgrdNama = group.getMgrdNama();
            this.mgrdStatus = group.getMgrdStatus();
            this.totalMembers = group.getTotalMembers();

            if (null != group.getDeliveries()) {
                this.deliveries = group.getDeliveries();
            } else {
                this.deliveries = Collections.emptySet();
            }

            if (!group.ignorePickup) {
                if (group.allowCountMembers) {
                    this.deliveries = group.getPickedUpDeliveries();
                    this.totalMembers = group.getTotalPickedUpMember();
                } else {
                    this.deliveries = group.getUnPickedUpDeliveries();
                    this.totalMembers = group.getTotalUnPickedUpMember();
                }
            }

        }
    }

    public Long getId() {
        return id;
    }

    public String getMgrdKode() {
        return mgrdKode;
    }

    public String getMgrdNama() {
        return mgrdNama;
    }

    public String getMgrdStatus() {
        return mgrdStatus;
    }

    public Long getTotalMembers() {
        return totalMembers;
    }

    public Set<MstAlamatDelivery> getDeliveries() {
        return deliveries;
    }
}
