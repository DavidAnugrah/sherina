package com.rs.sherina.Model;

import java.util.ArrayList;
import java.util.List;

public class StoreNmsResponse {
    private Long expiration = 0L;

    private List<Store> storeNms = new ArrayList<Store>();

    public List<Store> getStoreNms() {
        return storeNms;
    }

    public void setStoreNms(List<Store> storeNms) {
        this.storeNms = storeNms;
    }

    public Long getExpiration() {
        return expiration;
    }

    public void setExpiration(Long expiration) {
        this.expiration = expiration;
    }
}
