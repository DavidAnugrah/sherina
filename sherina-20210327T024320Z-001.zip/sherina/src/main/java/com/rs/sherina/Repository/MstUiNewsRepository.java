package com.rs.sherina.Repository;

import com.rs.sherina.Entity.MstUiNews;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface MstUiNewsRepository extends PagingAndSortingRepository<MstUiNews, Long> {
}
