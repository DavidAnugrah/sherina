package com.rs.sherina.Configuration;

import com.rs.sherina.Repository.MstAlamatCustomerRepository;
import com.rs.sherina.Repository.MstAlamatDeliveryRepository;
import com.rs.sherina.Repository.MstAlamatPickupRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Component
@Configuration
public class DataPrepareConfiguration implements ApplicationRunner {

    private final Logger logger = LoggerFactory.getLogger(DataPrepareConfiguration.class);

    @Autowired
    private MstAlamatDeliveryRepository deliveryRepository;

    @Autowired
    private MstAlamatPickupRepository pickupRepository;

    @Autowired
    private MstAlamatCustomerRepository customerRepository;

    @Override
    public void run(ApplicationArguments applicationArguments) throws Exception {
        try {
            logger.info("Preparing data ...");
            deliveryRepository.fixingTemporary();
            pickupRepository.fixingTemporary();
            customerRepository.fixingTemporary();
        } catch (Exception e) {
            logger.error(e.getMessage());
        }
    }
}
