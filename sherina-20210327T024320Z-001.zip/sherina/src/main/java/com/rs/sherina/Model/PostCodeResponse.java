package com.rs.sherina.Model;

import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PostCodeResponse {
	 private Long code;

	    private String message;

	    private List<PostCode> data= new ArrayList<>();

		public Long getCode() {
			return code;
		}

		public void setCode(Long code) {
			this.code = code;
		}

		public String getMessage() {
			return message;
		}

		public void setMessage(String message) {
			this.message = message;
		}

		
		public List<PostCode> getData() {
			return data;
		}

		public void setData(List<PostCode> data) {
			this.data = data;
		}

		public void merge(PostCodeResponse response) {
			data.addAll(response.getData());
	    }
		
}
