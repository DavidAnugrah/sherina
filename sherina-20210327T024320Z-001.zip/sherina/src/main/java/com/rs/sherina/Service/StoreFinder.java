package com.rs.sherina.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.rs.sherina.Entity.MstStoreAlfamart;
import com.rs.sherina.Model.Store;
import com.rs.sherina.Model.StoreNmsResponse;
import com.rs.sherina.Repository.MstStoreAlfamartRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings({"WeakerAccess", "unused"})
@Component
@EnableCaching
public class StoreFinder {
    private final static Logger logger = LoggerFactory.getLogger(StoreFinder.class);

    @Value("${sherina.auth.store-user}")
    private String storeTokenUser;

    @Value("${sherina.auth.store-user-key}")
    private String storeTokenUserKey;

    @Value("${sherina.auth.store-pass}")
    private String storeTokenPass;

    @Value("${sherina.auth.store-pass-key}")
    private String storeTokenPassKey;

    @Value("${sherina.api.store-finder:}")
    private String storeFinderUrl;

    @Value("${sherina.temp-dir:/tmp}")
    private String TMP_DIR;

    @Value("${sherina.config.store-cache-filename:stores-cache}")
    private String CACHE_FILENAME;

    @Value("${sherina.config.store-cache-filename:7200}")
    private Long CACHE_EXPIRATION;

    @Value("${spring.profiles.active:production}")
    private String ENV;

    @Autowired
    private MstStoreAlfamartRepository storeAlfamartRepository;

    private StoreNmsResponse storedResponse;

    public StoreFinder() {
    }

    public StoreNmsResponse getStoredResponse() {
        return storedResponse;
    }

    public void setStoredResponse(StoreNmsResponse storedResponse) {
        this.storedResponse = storedResponse;
    }

    public StoreNmsResponse findByName(String name) {

        if (StringUtils.isEmpty(storeFinderUrl)) {
            storeFinderUrl = "http://stg.alfatrex.co.id/location/store-nm";
        }
        String url = storeFinderUrl;
        if (!StringUtils.isEmpty(name)) {
            url+= "?name=" + name;
        }
        StoreNmsResponse response = new StoreNmsResponse();

        try {
            ResponseEntity<StoreNmsResponse> res = getTemplate().exchange(url, HttpMethod.GET, getHttpHeaders(""), StoreNmsResponse.class);
            response = res.getBody();
        } catch (Exception e) {
            logger.info(e.getMessage());
        }

        return response;
    }

    public Store findByCode(String code, StoreNmsResponse response) {
        Store store = null;
        if (!StringUtils.isEmpty(code)) {
            for (Store s: response.getStoreNms()) {
                if (s.getStoreCode().equalsIgnoreCase(code)) {
                    store = s;
                    break;
                }
            }
        }

        return store;
    }

    @Cacheable(value = "storeFinder", unless="#result == null")
    public Store findByCode(String code) {
        MstStoreAlfamart store = storeAlfamartRepository.findOneByCode(code);
        Store result = null;
        if (null != store) {
            result = new Store();
            result.setAddress1(store.getAddress());
            result.setAddress2(" ");
//            result.setPostcode(Integer.valueOf(store.get));
        }

        return result;
        /*if (null == storedResponse) {
            storedResponse = findAll();
        }
        logger.info("Get store by code: "+code);
        return findByCode(code, storedResponse);*/
    }

    @CacheEvict(value = "storeFinder", allEntries = true)
    public void clearCodeCache() {

    }

    public StoreNmsResponse findAll() {
        File file = getCacheFile();
        StoreNmsResponse stores = new StoreNmsResponse();
        if (null != file) {
            stores = jsonToStores(file);
        }

        if (stores.getExpiration() < System.currentTimeMillis()) {
            stores = saveAndGetStores();
            logger.info("Get stores from rest api");
        } else {
            logger.info("Get stores from cache");
        }

        return stores;
    }

    public Long getDefaultCacheExpiration() {
        return System.currentTimeMillis() + (CACHE_EXPIRATION * 1000);
    }

    public File getCacheFile() {
        if (StringUtils.isEmpty(TMP_DIR) || StringUtils.isEmpty(CACHE_FILENAME)) {
            return null;
        }

        return new File(TMP_DIR + "/" + CACHE_FILENAME + ".json");
    }

    public StoreNmsResponse saveStores(StoreNmsResponse stores) {
        stores.setExpiration(getDefaultCacheExpiration());
        String json = storesToJson(stores);

        return stores;
    }

    public void validateCache() {
        if (isCacheExpired()) {
            storedResponse = saveAndGetStores();
        }
    }

    public boolean isCacheExpired() {
        return null != storedResponse && storedResponse.getExpiration() < System.currentTimeMillis();
    }

    public StoreNmsResponse saveAndGetStores() {
        StoreNmsResponse stores = findByName(null);
        stores.setExpiration(getDefaultCacheExpiration());
        String json = storesToJson(stores);
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(getCacheFile()));
            bw.write(json);
            bw.close();
        } catch (Exception e) {
            // ..
        }

        return stores;
    }

    public String storesToJson(StoreNmsResponse response) {
        String json = "{\"storeNms\":[], \"expiration\": 0}";
        ObjectMapper om = new ObjectMapper();
        try {
            if (ENV.equalsIgnoreCase("local")) {
                json = om.writerWithDefaultPrettyPrinter().writeValueAsString(response);
            } else {
                json = om.writeValueAsString(response);
            }
        } catch (Exception e) {
            // ..
        }

        return json;
    }

    public StoreNmsResponse jsonToStores(String json) {
        StoreNmsResponse response = new StoreNmsResponse();
        ObjectMapper om = new ObjectMapper();
        try {
            response = om.readValue(json, StoreNmsResponse.class);
        } catch (Exception e) {
            // ..
        }

        return response;
    }

    public StoreNmsResponse jsonToStores(File json) {
        StoreNmsResponse response = new StoreNmsResponse();
        ObjectMapper om = new ObjectMapper();
        try {
            if (json.exists() && json.isFile() && json.canRead()) {
                response = om.readValue(json, StoreNmsResponse.class);
            }
        } catch (Exception e) {
            // ..
        }

        return response;
    }

    private HttpEntity<String> getHttpHeaders(String payload) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Accept", "application/json");
        headers.set("Content-Type", "application/json");
        headers.set(storeTokenUserKey, storeTokenUser);
        headers.set(storeTokenPassKey, storeTokenPass);

        return new HttpEntity<>(payload, headers);
    }

    private RestTemplate getTemplate() {
        RestTemplate rest = new RestTemplate();
        MappingJackson2HttpMessageConverter converter = new MappingJackson2HttpMessageConverter();
        List<MediaType> mediaTypes = new ArrayList<>();

        mediaTypes.add(MediaType.APPLICATION_JSON_UTF8);
        mediaTypes.add(MediaType.APPLICATION_JSON);
        mediaTypes.add(MediaType.TEXT_HTML);
        mediaTypes.add(MediaType.TEXT_PLAIN);

        converter.setSupportedMediaTypes(mediaTypes);
        rest.getMessageConverters().add(converter);

        return rest;
    }
}
