package com.rs.sherina.Controller;

import com.github.mkopylec.recaptcha.validation.RecaptchaValidator;
import com.github.mkopylec.recaptcha.validation.ValidationResult;
import com.rs.sherina.Entity.MstUser;
import com.rs.sherina.Extension.annotation.Route;
import com.rs.sherina.Repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;

@RestController
public class PasswordResetController {

    private final static Logger logger = LoggerFactory.getLogger(PasswordResetController.class);

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private JavaMailSenderImpl mailer;

    @Autowired
    private RecaptchaValidator validator;

    @Route("/reset-password")
    @ResponseBody
    public String resetAction(@RequestBody(required = false) MstUser user, HttpServletRequest request) {
        ValidationResult result = validator.validate(request);
        String success = "false";

        if (result.isSuccess()) {
            return "{\"success\": false, \"message\": \"Invalid Captcha\"}";
        }

        if (null != user && request.getMethod().equals("POST")) {
            MstUser userRepo = userRepository.findOneByUsername(user.getUsername());
            if (null != userRepo) {
                MimeMessage message = mailer.createMimeMessage();
                try {
                    MimeMessageHelper helper = new MimeMessageHelper(message, true);
                    helper.setTo(userRepo.getUsername());
                    helper.setSubject("Forgot Password");
                    helper.setText("Link <a href=\"https://google.co.id\">Forgot Password</a>", true);
                    mailer.send(message);
                    success = "true";
                    logger.info("Success: POST /reset-password");
                } catch (MessagingException e) {
                    logger.error("Error: POST /reset-password", e);
                    success = "false";
                }
            }
        }

        return "{\"success\": " + success + "}";
    }
}
