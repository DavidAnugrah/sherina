package com.rs.sherina.Model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class ServiceResponse {

    private String serviceName;

    @JsonProperty("detail")
    public List<Service> detail;

    public List<Service> getDetail() {
        return detail;
    }

    public void setDetail(List<Service> detail) {
        this.detail = detail;
    }

    @JsonProperty("serviceName")
    public String getServiceName() {
        return serviceName;
    }

    @JsonProperty("service")
    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }
}
