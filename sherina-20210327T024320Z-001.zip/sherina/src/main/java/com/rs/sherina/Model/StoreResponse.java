package com.rs.sherina.Model;

import java.util.ArrayList;
import java.util.List;

public class StoreResponse {

    private List<Store> stores = new ArrayList<>();

    public List<Store> getStores() {
        return stores;
    }

    public void setStores(List<Store> stores) {
        this.stores = stores;
    }

    public void merge(StoreResponse response) {
        stores.addAll(response.getStores());
    }
}
