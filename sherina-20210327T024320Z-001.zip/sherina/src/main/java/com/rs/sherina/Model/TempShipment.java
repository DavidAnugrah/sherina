package com.rs.sherina.Model;

import com.rs.sherina.Entity.MstAlamatCustomer;
import com.rs.sherina.Entity.MstAlamatDelivery;
import com.rs.sherina.Entity.MstAlamatPickup;

@SuppressWarnings("SpellCheckingInspection")
public class TempShipment {
    private Double berat;

    private Double tinggi;

    private Double panjang;

    private Double lebar;

    private Double nominal;

    private Double cod;

    private boolean asuransi;

    private String isi;

    private MstAlamatDelivery delivery;

    private MstAlamatPickup pickup;

    private MstAlamatCustomer alamatCustomer;

    public Double getBerat() {
        return berat;
    }

    public void setBerat(Double berat) {
        this.berat = berat;
    }

    public Double getTinggi() {
        return tinggi;
    }

    public void setTinggi(Double tinggi) {
        this.tinggi = tinggi;
    }

    public Double getPanjang() {
        return panjang;
    }

    public void setPanjang(Double panjang) {
        this.panjang = panjang;
    }

    public Double getLebar() {
        return lebar;
    }

    public void setLebar(Double lebar) {
        this.lebar = lebar;
    }

    public Double getNominal() {
        return nominal;
    }

    public void setNominal(Double nominal) {
        this.nominal = nominal;
    }

    public Boolean getAsuransi() {
        return asuransi;
    }

    public void setAsuransi(boolean asuransi) {
        this.asuransi = asuransi;
    }

    public void setAsuransi(String asuransi) {
        boolean active = false;

        if (asuransi.toLowerCase().equals("ya")) {
            active = true;
        }

        this.asuransi = active;
    }

    public String getIsi() {
        return isi;
    }

    public void setIsi(String isi) {
        this.isi = isi;
    }

    public Double getCod() {
        return cod;
    }

    public void setCod(Double cod) {
        this.cod = cod;
    }

    public MstAlamatDelivery getDelivery() {
        return delivery;
    }

    public void setDelivery(MstAlamatDelivery delivery) {
        this.delivery = delivery;
    }

    public MstAlamatPickup getPickup() {
        return pickup;
    }

    public void setPickup(MstAlamatPickup pickup) {
        this.pickup = pickup;
    }

    public MstAlamatCustomer getAlamatCustomer() {
        return alamatCustomer;
    }

    public void setAlamatCustomer(MstAlamatCustomer alamatCustomer) {
        this.alamatCustomer = alamatCustomer;
    }
}
