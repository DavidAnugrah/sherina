package com.rs.sherina.Utils;

import org.springframework.security.crypto.password.PasswordEncoder;

public class MD5PasswordEncoder implements PasswordEncoder {
    @Override
    public String encode(CharSequence charSequence) {
        String encoded;
        try {
            encoded = MD5.encode(charSequence.toString());
        } catch (RuntimeException e) {
            encoded = "";
        }

        return encoded;
    }

    @Override
    public boolean matches(CharSequence charSequence, String s) {
        return this.encode(charSequence.toString()).equals(s);
    }
}
