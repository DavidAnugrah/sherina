package com.rs.sherina.Repository;

import com.rs.sherina.Entity.MstStoreAlfamart;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface MstStoreAlfamartRepository extends PagingAndSortingRepository<MstStoreAlfamart, Long>,
        JpaSpecificationExecutor<MstStoreAlfamart> {

    @Query("SELECT s FROM MstStoreAlfamart s WHERE s.position IS NOT NULL AND s.position <> '' AND LOWER(s.name || ' ' || s.address || ' ' || s.provinsi || ' ' || s.city || ' ' || s.kecamatan || ' ' || s.kelurahan) LIKE '%' || LOWER(:search) || '%' ")
    List<MstStoreAlfamart> getStoreByKeyword(@Param("search") String search, Pageable page);

    @Query("SELECT s FROM MstStoreAlfamart s WHERE (s.position IS NOT NULL) AND s.position <> ''")
    List<MstStoreAlfamart> findByLatLngIsNotEmpty(Pageable page);

    List<MstStoreAlfamart> findByPositionIsNotNullAndPositionNotAndNameContainingIgnoreCase(String position, String name, Pageable page);

    List<MstStoreAlfamart> findAll();

    MstStoreAlfamart findOneByCode(String code);
}