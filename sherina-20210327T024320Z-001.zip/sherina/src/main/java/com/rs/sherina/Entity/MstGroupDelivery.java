package com.rs.sherina.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonView;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.data.jpa.datatables.mapping.DataTablesOutput;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import java.util.Collections;
import java.util.Date;
import java.util.Set;
import java.util.HashSet;

@Entity
@Table(name = "mst_group_delivery")
@JsonIgnoreProperties(ignoreUnknown = true)
@SuppressWarnings("SpellCheckingInspection")
public class MstGroupDelivery {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 20)
    private String mgrdKode;

    @JsonView(DataTablesOutput.View.class)
    private String mgrdNama;

    private String mgrdStatus;

    @JsonIgnore
    @CreationTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    private Date mgrdCreateDate;

    @JsonIgnore
    @UpdateTimestamp
    @Temporal(TemporalType.TIMESTAMP)
    private Date mgrdUpdateDate;

    @ManyToOne
    @JoinColumn(name = "mgrd_create_user")
    @JsonIgnore
    private MstUser userCreator;

    @ManyToOne
    @JoinColumn(name = "mgrd_update_user")
    @JsonIgnore
    private MstUser userUpdater;

    @ManyToOne
    @JsonIgnore
    @JoinColumn(name = "mgrd_mcus_kode")
    private MstCustomerB2b mstCustomerB2b;

    @OneToMany(mappedBy = "group", fetch = FetchType.LAZY, cascade = {CascadeType.ALL})
    @JsonIgnore
    private Set<MstAlamatDelivery> deliveries;

    public Long getId() {
        return id;
    }

    public String getMgrdKode() {
        return mgrdKode;
    }

    public void setMgrdKode(String mgrdKode) {
        this.mgrdKode = mgrdKode;
    }

    public String getMgrdNama() {
        return mgrdNama;
    }

    public void setMgrdNama(String mgrdNama) {
        this.mgrdNama = mgrdNama;
    }

    public String getMgrdStatus() {
        return mgrdStatus;
    }

    public void setMgrdStatus(String mgrdStatus) {
        this.mgrdStatus = mgrdStatus;
    }

    public Set<MstAlamatDelivery> getDeliveries() {
        return deliveries;
    }

    public void setDeliveries(Set<MstAlamatDelivery> deliveries) {
        for (MstAlamatDelivery mstAlamatDelivery : deliveries) {
            mstAlamatDelivery.setGroup(this);
        }
        this.deliveries = deliveries;
    }

    public MstCustomerB2b getMstCustomerB2b() {
        return mstCustomerB2b;
    }

    public void setMstCustomerB2b(MstCustomerB2b mstCustomerB2b) {
        this.mstCustomerB2b = mstCustomerB2b;
        if (null != mstCustomerB2b) {
            if (null == this.userCreator) {
                this.userCreator = mstCustomerB2b.getUser();
            }

            this.userUpdater = mstCustomerB2b.getUser();
        }
    }

    @JsonProperty("totalMembers")
    @Transient()
    @SuppressWarnings("all")
    public Long getTotalMembers() {
        if (null == deliveries) {
            return 0L;
        }
        return Long.valueOf(deliveries.size());
    }

    @Transient()
    @JsonIgnore
    public boolean allowCountMembers = false;

    @Transient()
    @JsonIgnore
    public boolean ignorePickup = false;

    @JsonProperty("totalPickedUpMember")
    @Transient()
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    @SuppressWarnings("all")
    public Long getTotalPickedUpMember() {
        if (!allowCountMembers || ignorePickup || null == deliveries) {
            return 0L;
        }

        return Long.valueOf(getPickedUpDeliveries().size());
    }

    @JsonProperty("pickedUpDeliveries")
    @Transient()
    //@JsonInclude(JsonInclude.Include.NON_NULL)
    public Set<MstAlamatDelivery> getPickedUpDeliveries() {
        if (!allowCountMembers || ignorePickup || null == deliveries) {
            //return null;
            return Collections.emptySet();
        }
        Set<MstAlamatDelivery> dels = new HashSet<>();
        for (MstAlamatDelivery d: deliveries) {
            if (d.isMldeAllowPickup()) {
                d.setGroup(null);
                dels.add(d);
            }
        }

        return dels;
    }

    @JsonProperty("totalUnPickedUpMember")
    @Transient()
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    @SuppressWarnings("all")
    public Long getTotalUnPickedUpMember() {
        if (allowCountMembers || ignorePickup || null == deliveries) {
            return 0L;
        }

        return Long.valueOf(getUnPickedUpDeliveries().size());
    }

    @JsonProperty("unPickedUpDeliveries")
    @Transient()
    //@JsonInclude(JsonInclude.Include.NON_NULL)
    public Set<MstAlamatDelivery> getUnPickedUpDeliveries() {
        if (!allowCountMembers || ignorePickup|| null == deliveries) {
            //return null;
            return Collections.emptySet();
        }
        Set<MstAlamatDelivery> dels = new HashSet<>();
        for (MstAlamatDelivery d: deliveries) {
            if (!d.isMldeAllowPickup()) {
                d.setGroup(null);
                dels.add(d);
            }
        }

        return dels;
    }

    public Date getMgrdCreateDate() {
        return mgrdCreateDate;
    }

    public void setMgrdCreateDate(Date mgrdCreateDate) {
        this.mgrdCreateDate = mgrdCreateDate;
    }

    public Date getMgrdUpdateDate() {
        return mgrdUpdateDate;
    }

    public void setMgrdUpdateDate(Date mgrdUpdateDate) {
        this.mgrdUpdateDate = mgrdUpdateDate;
    }
}
